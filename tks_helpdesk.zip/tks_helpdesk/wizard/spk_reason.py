from odoo import models, fields, api


class SpkReason(models.TransientModel):
    _name = "spk.reason"
    _description = "Models from Cancel and Revise Reason"

    cdp_spk_id = fields.Many2one("repair.order", string="Repair Order")
    reason = fields.Text("Reason")

    def update_spk_reason(self):
        if self.cdp_spk_id:
            type = self._context.get("button")
            if type == "revised":
                self.cdp_spk_id.revised_reason = self.reason
                self.cdp_spk_id._action_revised()
            elif type == "cancel":
                self.cdp_spk_id.cancel_reason = self.reason
                self.cdp_spk_id._action_cancel()
            else:
                return
