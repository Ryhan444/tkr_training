from odoo import fields, models, _, api
from datetime import timedelta, datetime, time

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    # @api.onchange('tks_im_opl_ci_type_id')
    # def onchange_tks_im_opl_ci_type(self):
    #     for app in self:
    #         app.tks_im_38_change_type = app.tks_im_opl_ci_type_id.name
    

    tks_im_38_change_invoice_delivery_proposal_ids = fields.One2many(
        'opl.change.invoice.delivery.proposal', 
        'request_id', string='OPL - Change Invoice Delivery Proposal'
    )
    tks_im_38_change_invoice_delivery_business_benefit_ids = fields.One2many(
        'opl.change.invoice.delivery.business.benefit', 
        'request_id', string='OPL - Change Invoice Delivery Business Benefit'
    )
    tks_im_38_change_invoice_delivery_risk_mitigation_ids = fields.One2many(
        'opl.change.invoice.delivery.risk.mitigation', 
        'request_id', string='OPL - Change Invoice Delivery Mitigation'
    )
    tks_im_38_change_type = fields.Char(
        # "tks.im.opl.ci.type",
        string="Changing Invoice Type",
        related="tks_im_opl_ci_type_id.name"
    )
    tks_im_38_change_detail_before = fields.Text('Change Details Before')
    tks_im_38_change_detail_after = fields.Text('Change Details After')
    tks_im_38_reason = fields.Text('Reason')
    tks_im_38_lessee_name = fields.Char('Lessee Name')
    tks_im_38_invoice_number = fields.Char('Invoice Number')
    tks_im_38_invoice_period = fields.Char('Invoice Period')
    tks_im_38_invoice_amount_total = fields.Monetary('Invoice Amount Total', currency_field="tks_currency_id")

class OplChangeInvoiceDeliveryProposal(models.Model):
    _name = 'opl.change.invoice.delivery.proposal'
    _description = 'OPL Change Invoice Delivery Proposal'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    items = fields.Selection([
        ('change_type', 'Change Type'),
        ('change_details', 'Change Details (Before - After)'),
        ('Reason', 'Reason'),
        ('lessee_name', 'Lessee Name'),
        ('invoice_number', 'Invoice Number'),
        ('invoice_period', 'Invoice Period'),
        ('invoice_amount', 'Invoice Amount'),
    ], string='Items')
    remarks = fields.Text('Remarks')


class OplChangeInvoiceDeliveryBusinessBenefit(models.Model):
    _name = 'opl.change.invoice.delivery.business.benefit'
    _description = 'OPL Change Invoice Delivery Business Benefit'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')


class OplChangeInvoiceDeliveryRiskMitigation(models.Model):
    _name = 'opl.change.invoice.delivery.risk.mitigation'
    _description = 'OPL Change Invoice Delivery Risk Mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')

    