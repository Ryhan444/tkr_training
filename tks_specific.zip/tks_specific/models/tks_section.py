from odoo import fields, models, _, api


class TksSection(models.Model):
    _name = "tks.section"
    _order = "name"
    _description = "Section"

    active = fields.Boolean(default=True)
    tks_sequence = fields.Integer(default=1)
    name = fields.Char(string=_("Name"))
    tks_section_head_id = fields.Many2one(
        "hr.employee",
        string="Head Section",
        readonly=True,
    )
    tks_department_id = fields.Many2one(
        "hr.department", string="Department", ondelete="cascade"
    )
