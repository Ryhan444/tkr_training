from odoo import fields, models, _, api


class TksImOplCiType(models.Model):
    _name = 'tks.im.opl.ci.type'
    _description = 'Tipe CI'

    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    name = fields.Char(string='Tipe CI', required=True)
    code = fields.Char(string="Code")