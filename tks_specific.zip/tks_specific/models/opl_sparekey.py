from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    @api.depends('tks_im_opl_sparekey_type_id')
    def _get_sparekey_type(self):
        for app in self:
            if app.tks_im_opl_sparekey_type_id.name == 'Borrow Sparekey':
                app.tks_customer_req_24 = 'borrow'
            elif app.tks_im_opl_sparekey_type_id.name == 'Duplicate Sparekey':
                app.tks_customer_req_24 = 'duplicate'
            elif app.tks_im_opl_sparekey_type_id.name == 'Waive Sparekey':
                app.tks_customer_req_24 = 'waive'
    

    tks_opl_sparekey_ids = fields.One2many(
        "opl.sparekey.risk.mitigation", "request_id", string="OPL - Permanent Exchange"
    )
    tks_customer_req_24 = fields.Selection(
        [
            ("borrow", "Borrow Key"),
            ("duplicate", "Duplicate key"),
            ("waive", "Waive key"),
        ],
        string="Customer Request",
        compute="_get_sparekey_type",
        store=True
    )
    tks_spare_key_price_24 = fields.Monetary(
        "Spare Key Price", currency_field="tks_currency_id"
    )
    tks_cost_security_24 = fields.Selection(
        [
            (" "," "),
            ("no", "No"),
            ("yes", "Yes"),
        ],
        string="Cost / Security Deposit",
    )
    amount_24 = fields.Monetary("Amount", currency_field="tks_currency_id")
    tks_date_start_24 = fields.Date("Start Date")
    tks_date_end_24 = fields.Date("End Date")
    tks_paid_date_24 = fields.Date("Paid Date")
    tks_reason_24 = fields.Text("Reason / Explanation")


class OplPermanentExchangeBusinessBenefit(models.Model):
    _name = "opl.sparekey.risk.mitigation"
    _description = "Sparekey Risk Management"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        [
            ("risk", "Risk"),
            ("mitigation", "Mitigation"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
