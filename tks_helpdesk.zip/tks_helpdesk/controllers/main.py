from odoo import http
from odoo.http import request
from ast import literal_eval
import io
import xlsxwriter


class CdpExcelController(http.Controller):

    @http.route("/spk/excel/report/<string:report_ids>", type="http", auth="user")
    def download_spk_excel_report(self, report_ids):
        reports_ids = request.env["overall.report"].browse(literal_eval(report_ids))

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {"in_memory": True})
        sheet = workbook.add_worksheet("Inquiry_SPK_Report")

        # ====== STYLE ======
        header_inq_format = workbook.add_format(
            {
                "bold": True,
                "align": "center",
                "valign": "vcenter",
                "bg_color": "#00B050",  # hijau Inquiry
                "font_color": "white",
                "border": 1,
            }
        )
        header_spk_format = workbook.add_format(
            {
                "bold": True,
                "align": "center",
                "valign": "vcenter",
                "bg_color": "#F4B083",  # oranye SPK
                "border": 1,
            }
        )
        subheader_format = workbook.add_format(
            {
                "bold": True,
                "align": "center",
                "valign": "vcenter",
                "bg_color": "#D9EAD3",
                "border": 1,
            }
        )
        normal_format = workbook.add_format({"border": 1})

        # ====== MERGE HEADER ======
        sheet.merge_range("A1:AE1", "INQUIRY", header_inq_format)
        sheet.merge_range("AF1:BA1", "SPK", header_spk_format)

        # ====== HEADER BARIS 2 ======
        headers = [
            # Inquiry columns (sesuai list view)
            "No",
            "INQ ID",
            "Date of Inquiry",
            "Submit Date",
            "Reject Date",
            "Source of Inquiry",
            "Type of Inquiry",
            "Category Inquiry",
            "Ref Inquiry",
            "Request Non Serv INQ",
            "Status",
            "Aging",
            "Total Aging",
            "Customer Name",
            "PIC Name",
            "PIC No",
            "Plate Number",
            "Brand",
            "Type",
            "Year",
            "Color",
            "KM",
            "Rent Status",
            "Actual Location",
            "Description Service",
            "PIC Name 1",
            "PIC Contact",
            "Relocation Address",
            "Vendor Name",
            "Vendor Address",
            "PIC Call Center",
            # SPK
            "SPK ID",
            "Created On",
            "Service Location",
            "SPK Type",
            "SPK Ref ID",
            "Repair Type",
            "Description",
            "KM (Extend Only)",
            "SPK Status",
            "Aging SPK",
            "Total Aging SPK",
            "Item",
            "Scope",
            "Sub Category",
            "Vendor Proposed",
            "Estimation Cost",
            "Final Approver",
            "Mechanic Name",
            "Schedule Date",
            "Expiry Date",
            "Complete Date",
            "Close Date",
        ]

        for col, name in enumerate(headers):
            sheet.write(1, col, name, subheader_format)
            sheet.set_column(col, col, 18)

        # ====== ISI DATA ======
        row = 2
        for idx, rec in enumerate(reports_ids, 1):
            if rec.cdp_repair_type == "extend":
                cdp_kilometer_val = rec.cdp_kilometer or ""
            else:
                cdp_kilometer_val = ""

            data = [
                idx,
                rec.ticket_id.display_name or "",
                str(rec.cdp_create_date or ""),
                str(rec.date_submit or ""),
                str(rec.cdp_reject_date or ""),
                rec.source_inquiry_id.name or "",
                rec.type_inquiry_id.name or "",
                rec.category_id.name or "",
                rec.cdp_ref_inq or "",
                rec.cdp_req_non_serv_inq_id.display_name or "",
                rec.stage_id.name or "",
                rec.duration_tracking_display or "",
                rec.total_duration_tracking or "",
                rec.partner_id.name or "",
                rec.pic_name or "",
                rec.pic_number or "",
                rec.plate_number or "",
                rec.brand or "",
                rec.type or "",
                rec.year or "",
                rec.color or "",
                rec.kilometer or "",
                rec.rent_status or "",
                rec.actual_location or "",
                rec.description_service or "",
                rec.pic_name_1 or "",
                rec.pic_contact or "",
                rec.relocation_address or "",
                rec.cdp_vendor_names or "",
                rec.cdp_vendor_address or "",
                rec.pic_call_center or "",
                # SPK
                rec.repair_id.display_name or "",
                str(rec.create_date or ""),
                rec.cdp_service_location or "",
                rec.cdp_spk_type or "",
                rec.cdp_spk_ref_id.display_name or "",
                rec.cdp_repair_type or "",
                rec.cdp_description or "",
                cdp_kilometer_val or "",
                rec.state or "",
                rec.state_duration_tracking_display or "",
                rec.state_duration_tracking_display or "",
                rec.product_names or "",
                rec.cdp_scope_names or "",
                rec.cdp_category_names or "",
                rec.cdp_vendor_name or "",
                rec.cdp_estimation_cost or "",
                rec.cdp_final_approver or "",
                rec.cdp_mechanic_name or "",
                str(rec.cdp_schedule_date or ""),
                str(rec.cdp_expired_date or ""),
                str(rec.cdp_complete_date or ""),
                str(rec.date_close or ""),
            ]
            for col, val in enumerate(data):
                sheet.write(row, col, val, normal_format)
            row += 1

        workbook.close()
        output.seek(0)

        # ====== RETURN FILE ======
        file_name = "Inquiry_SPK_Report.xlsx"
        return request.make_response(
            output.getvalue(),
            headers=[
                (
                    "Content-Type",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ),
                ("Content-Disposition", f"attachment; filename={file_name}"),
            ],
        )
