from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_clausal_line_fields = any(
            not line.sequence or not line.revision_type or not line.detail or not line.risk_and_mitigation
            for line in self.tks_opl_changing_clausul_line_ids
        )
        if self.tks_has_tks_im_changing_clausal != 'no' and (
            not self.tks_opl_changing_clausul_line_ids or missing_clausal_line_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Changing Clausal Lines Empty'),
                    'message': _('Changing Clausal Lines must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }

        return super(ApprovalRequest, self).action_confirm()


    tks_number_clausul_changed_27 = fields.Selection(
        [(str(i), str(i)) for i in range(1, 16)], 
        string='Number of Clausul Changed'
    )
    tks_opl_changing_clausul_line_ids = fields.One2many('opl.changing.clausul', 'request_id', string='Lines OPL - Management Consent BPR')
    tks_contract_no_27 = fields.Char('Contract No.')
    tks_addendum_no_27 = fields.Char('Addendum No.')
    
class OplManagementConsentBPR(models.Model):
    _name = 'opl.changing.clausul'
    _description = 'OPL - Changing Clausal'
    _rec_name = 'type'
    
    @api.depends('request_id')
    def _compute_number(self):
        """Function to compute line numbers"""
        for req in self.mapped('request_id'):
            sequence = 1
            if req.tks_opl_changing_clausul_line_ids:
                for lines in req.tks_opl_changing_clausul_line_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ''

    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    sequence = fields.Integer(string="No.", compute="_compute_number")
    type = fields.Selection([
        ('article1', 'Article 1 : Operating Lease'),
        ('article2', 'Article 2 : Operating Lease Fees, Security Deposit, And Other Payment Obligation'),
        ('article3', 'Article 3 : Term Of Payment'),
        ("article4", "Article 4 : The Lessor'S Obligation"),
        ('article5', 'Article 5 : Ownership'),
        ('article6', "Article 6 : The Lessee'S Obligations"),
        ('article7', 'Article 7 : Representation And Warranties'),
        ('article8', 'Article 8 : Delivery And Acceptance'),
        ('article9', 'Article 9 : Cars Inspection'),
        ('article10', 'Article 10 : Tax'),
        ('article11', 'Article 11 : Term And Termination'),
        ('article12', 'Article 12 : Force Majeure'),
        ('article13', 'Article 13 : Dispute Settlement'),
        ('article14', 'Article 14 : Governing Law And Languange'),
        ('article15', 'Article 15 : Notices'),
        ('article16', 'Article 16 : Confidentiality'),
        ('article17', 'Article 17 : Other Provisions'),
        ('schedule1', 'Schedule 1 : Operating Lease Object'),
        ('schedule2', 'Schedule 2 : Et Penalty'),
    ], string='Clausal to be Revised')
    revision_type = fields.Selection([
        ('waive', 'Waive Clausal'),
        ('add', 'Add Clausal'),
        ('change', 'Change Clausal'),
    ], string='Revision')
    detail = fields.Text('Changes Detail')
    risk_and_mitigation = fields.Text(string='Risk & Mitigation')