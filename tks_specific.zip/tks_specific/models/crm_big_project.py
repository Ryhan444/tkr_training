from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_big_project_id = fields.Many2one('tks.big.project', string="Big Project")

class TksTransType(models.Model):
    _name = 'tks.big.project'
    _description = 'Big Project'

    name = fields.Char(string="Big Project")

