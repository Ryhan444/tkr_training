from odoo import api, models, fields, _

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_6_list_document_waived_ids = fields.One2many(
        comodel_name="tks.im.6.list.of.document.waived",
        inverse_name="tks_im_request_id",
        string="List of Document Waived",
    )
    
    def action_confirm(self):
        missing_fields = any(
            not line.tks_contract_no or
            not line.tks_im_6_document_name or
            not line.tks_im_6_reason or
            not line.tks_im_6_risk or
            not line.tks_im_6_mitigation or
            (line.tks_im_6_document_name == 'other' and not line.tks_im_6_other_documents)
            for line in self.tks_im_6_list_document_waived_ids
        )
        
        if self.tks_has_tks_im_waive_kyc_document_fl != 'no' and (
            not self.tks_im_6_list_document_waived_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('List of Document Waived Empty'),
                    'message': _('Please fill in the required fields in the List of Document Waived.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }

        return super(ApprovalRequest, self).action_confirm()



class TksIM6PostponedWaived(models.Model):
    _name = "tks.im.6.list.of.document.waived"
    _description = "IM 6 Document Postponed"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_contract_no = fields.Char(string="Contract No.")
    tks_im_6_document_name = fields.Selection(
        string=_("Document Name"),
        selection=[
            ("pwp_tax", "NPWP / Tax Registration Number"),
            ("ib_business", "NIB / Business Registry Number"),
            ("bl", "Business License"),
            ("ktp_pass", "KTP/KITAS/pasport"),
            ("est_deed", "Establishment deed"),
            ("change_ob", "Change of Bod/Boc"),
            ("change_os", "Change of shareholders"),
            ("change_oc", "Change of Capital"),
            ("other", "Other Documents"),
        ],
    )

    tks_im_6_reason = fields.Text(string=_("Reason"))
    tks_im_6_risk = fields.Text(string=_("Risk"))
    tks_im_6_mitigation = fields.Text(string=_("Mitigation"))
    tks_im_6_other_documents = fields.Text(string="Other Documents")
    tks_im_6_remarks = fields.Text(string="Remarks")
