from odoo import fields, models, _, api
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    

    @api.depends('tks_im_44_waive_late_payment_penalty_amount', 'tks_im_44_waive_late_payment_penalty_waived')
    def _compute_payable_amount(self):
        """Compute the payable amount by subtracting waived amount from the total."""
        for rec in self:
            rec.tks_im_44_waive_late_payment_penalty_payable = (
                rec.tks_im_44_waive_late_payment_penalty_amount - rec.tks_im_44_waive_late_payment_penalty_waived
                if rec.tks_im_44_waive_late_payment_penalty_amount else 0.0
            )
            if rec.tks_im_44_waive_late_payment_penalty_payable > rec.tks_im_44_waive_late_payment_penalty_amount:
                raise ValidationError("Amount Payable exceeding amount before")
            elif rec.tks_im_44_waive_late_payment_penalty_payable < 0:
                raise ValidationError("Cannot enter a negative value for the payable amount")

    @api.depends('tks_im_44_waive_late_payment_penalty_amount', 'tks_im_44_waive_late_payment_penalty_waived')
    def _compute_waived_percentage(self):
        """Compute the waived percentage as a proportion of the total amount."""
        for rec in self:
            if rec.tks_im_44_waive_late_payment_penalty_amount:
                rec.tks_im_44_waived_percentage = (
                    (rec.tks_im_44_waive_late_payment_penalty_waived / rec.tks_im_44_waive_late_payment_penalty_amount) * 100
                    if rec.tks_im_44_waive_late_payment_penalty_waived else 0.0
                )

    @api.depends('tks_im_44_waive_late_payment_penalty_payable', 'tks_im_44_waive_late_payment_penalty_amount')
    def _compute_payable_percentage(self):
        """Compute the payable percentage as a proportion of the total amount."""
        for rec in self:
            if rec.tks_im_44_waive_late_payment_penalty_amount:
                rec.tks_im_44_payable_percentage = (
                    (rec.tks_im_44_waive_late_payment_penalty_payable / rec.tks_im_44_waive_late_payment_penalty_amount) * 100
                    if rec.tks_im_44_waive_late_payment_penalty_payable else 0.0
                )

    
    
    tks_im_44_waive_late_payment_penalty_amount = fields.Monetary(
        string=_("Amount"),
        currency_field="tks_currency_id",
    )

    tks_im_44_waive_late_payment_penalty_waived = fields.Monetary(
        string=_("Waived"),
        currency_field="tks_currency_id",
    )

    tks_im_44_waive_late_payment_penalty_payable = fields.Monetary(
        string=_("Payable"),
        currency_field="tks_currency_id",
        compute='_compute_payable_amount',
        store=True,
    )

    tks_im_44_waived_percentage = fields.Float(
        string=_('Waived Percentage'),
        compute='_compute_waived_percentage',
        store=True,
    )

    tks_im_44_payable_percentage = fields.Float(
        string=_('Payable Percentage'),
        compute='_compute_payable_percentage',
        store=True,
    )

    tks_im_44_waive_late_payment_penalty_contract_no = fields.Char(
        string=_('Contract No')
    )

    tks_im_44_waive_late_payment_penalty_addendum_no = fields.Char(
        string=_('Addendum No')
    )

    tks_im_44_waive_late_payment_penalty_before_overdue_penalty = fields.Selection(
        [
            ('copl', 'Collect Overdue Penalty in Full'),
        ],
        default="copl", required=True,
        string=_('Overdue Penalty Before'),
    )

    tks_im_44_waive_late_payment_penalty_after_overdue_penalty = fields.Selection(
        [
            ('partial', 'Waive Overdue Penalty (Partial)'),
            ('whole', 'Waive Overdue Penalty (Whole)'),
        ],
        default="partial",
        string=_('Overdue Penalty After'),
    )
    
    tks_im_44_waive_late_payment_penalty_before_invoice_no = fields.Char('Invoice No Before')
    tks_im_44_waive_late_payment_penalty_after_invoice_no = fields.Char('Invoice No After')
    tks_im_44_waive_late_payment_penalty_period_from = fields.Date('Period From')
    tks_im_44_waive_late_payment_penalty_period_to = fields.Date('Period To')
    tks_im_44_waive_late_payment_penalty_expected_pay_date = fields.Date('Expected Pay Date')
    tks_im_44_waive_late_payment_penalty_lessee = fields.Text('Lessee:')
    tks_im_44_waive_late_payment_penalty_tks= fields.Text('TKS:')
    tks_im_44_waive_late_payment_penalty_business_consideration = fields.Text('Business Consideration')