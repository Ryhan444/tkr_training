from odoo import fields, models, _, api, tools
from odoo.exceptions import ValidationError
from odoo.tools import _, LazyTranslate
from odoo.osv import expression
from lxml import etree
import json
import re
import stdnum

_lt = LazyTranslate(__name__)

_eu_country_vat = {"GR": "EL"}

_eu_country_vat_inverse = {v: k for k, v in _eu_country_vat.items()}

_ref_vat = {
    "al": "ALJ91402501L",
    "ar": _lt("AR200-5536168-2 or 20055361682"),
    "at": "ATU12345675",
    "au": "83 914 571 673",
    "be": "BE0477472701",
    "bg": "BG1234567892",
    "br": _lt("either 11 digits for CPF or 14 digits for CNPJ"),
    "cr": _lt("3101012009"),
    "cl": "CL76086428-5",
    "co": _lt("CO213123432-1 or CO213.123.432-1"),
    "cy": "CY10259033P",
    "cz": "CZ12345679",
    "de": _lt("DE123456788 or 12/345/67890"),
    "dk": "DK12345674",
    "do": _lt("DO1-01-85004-3 or 101850043"),
    "ec": _lt("1792060346001 or 1792060346"),
    "ee": "EE123456780",
    "es": "ESA12345674",
    "fi": "FI12345671",
    "fr": "FR23334175221",
    "gb": _lt("GB123456782 or XI123456782"),
    "gr": "EL123456783",
    "hu": _lt("HU12345676 or 12345678-1-11 or 8071592153"),
    "hr": "HR01234567896",
    "ie": "IE1234567FA",
    "il": _lt("XXXXXXXXX [9 digits] and it should respect the Luhn algorithm checksum"),
    "in": "12AAAAA1234AAZA",
    "is": "IS062199",
    "it": "IT12345670017",
    "lt": "LT123456715",
    "lu": "LU12345613",
    "lv": "LV41234567891",
    "mc": "FR53000004605",
    "mt": "MT12345634",
    "mx": _lt("MXGODE561231GR8 or GODE561231GR8"),
    "nl": "NL123456782B90",
    "no": "NO123456785",
    "nz": _lt("49-098-576 or 49098576"),
    "pe": _lt(
        "10XXXXXXXXY or 20XXXXXXXXY or 15XXXXXXXXY or 16XXXXXXXXY or 17XXXXXXXXY"
    ),
    "ph": "123-456-789-123",
    "pl": "PL1234567883",
    "pt": "PT123456789",
    "ro": "RO1234567897 or 8001011234567 or 9000123456789",
    "rs": "RS101134702",
    "ru": "RU123456789047",
    "se": "SE123456789701",
    "si": "SI12345679",
    "sk": "SK2022749619",
    "sm": "SM24165",
    "tr": _lt("TR1234567890 (VERGINO) or TR17291716060 (TCKIMLIKNO)"),
    "uy": _lt("'219999830019' (should be 12 digits)"),
    "ve": "V-12345678-1, V123456781, V-12.345.678-1",
    "xi": "XI123456782",
    "sa": _lt('310175397400003 [Fifteen digits, first and last digits should be "3"]'),
}


class ResPartner(models.Model):
    _inherit = "res.partner"

    # Default Value
    def _default_category(self):
        context = self._context
        if context.get("active_model") == "approval.category":
            return
        else:
            return self.env["res.partner.category"].browse(
                self._context.get("category_id")
            )

    def _default_company_type(self):
        context = self._context
        if "default_name" in context or "default_is_company" in context:
            return "company"
        elif "default_is_company" in context and "active_test" in context:
            return "person"

    # Inherit field
    type = fields.Selection(
        selection_add=[
            ("branch_address", "Branch Address"),
            ("npwp_address", "NPWP Address"),
            ("customer_pic", "Customer PIC"),
            ("dealer_pic", "Dealer PIC"),
        ]
    )

    category_id = fields.Many2many(
        "res.partner.category",
        column1="partner_id",
        column2="category_id",
        string="Tags",
        default=_default_category,
    )

    company_type = fields.Selection(
        string="Company Type", default=_default_company_type
    )

    # New Field
    tks_total_holding_unit = fields.Integer(string="Total Holding Unit")
    tks_contact_maker_id = fields.Many2one(
        string="Contact Maker", comodel_name="res.users"
    )
    tks_user_manager_id = fields.Many2one(
        string="User Manager",
        comodel_name="res.users",
        compute="_default_user_manager",
        store=True,
    )
    tks_dealer_name = fields.Char(string="Dealer Name")
    tks_listed_company = fields.Selection(
        string="Listed Company (Tbk)",
        selection=[("yes", "Yes"), ("no", "No")],
        default="yes",
    )
    tks_company_type = fields.Selection(
        string=_("Company Type"),
        selection=[
            ("pt", "PT"),
            ("cv", "CV"),
            ("yayasan", "Yayasan"),
            ("koperasi", "Koperasi"),
            ("other", "Others"),
        ],
        default="pt",
    )

    tks_company_type_remark = fields.Char(string=_("Company Type Remark"))

    tks_company_group_id = fields.Many2one(
        string="Company Group",
        comodel_name="tks.res.partner.company.group",
    )

    tks_classification = fields.Selection(
        string=_("Classification"),
        selection=[
            ("japanese", "Japanese"),
            ("non-japanese", "Non Japanese"),
        ],
    )

    tks_company_size = fields.Selection(
        string=_("Company Size"),
        selection=[
            ("sme", "SME"),
            ("mid", "MID"),
            ("llc", "LLC"),
            ("mnc", "MNC"),
            ("soe", "SOE"),
        ],
        help="1) Classification shall be determined by criteria order (1. Ownership, 2. Annual Revenue, 3. Paid In Capital). 2) In case of a subsidiary of LLC, MNC, or SOE, such subsidiary shall be classified same as parent company. 3) If the information of revenue and/or paid-in capital is not available for determining SME/MID company category, we will use an adjusted 70 percent of the company's authorized capital to determine its classification. 4) If a company can be categorized both as LLC and SOE/MNC, it shall be categorized as SOE/MNC instead of LLC. 5) LLC/MNC Company classification must be discussed with CA during Initial Screening process. 6) Due to the data being continously updated, there is a possibility of slight changes in the near feature.",
    )

    tks_cust_department = fields.Char(string=_("Department"))

    tks_contact_status = fields.Selection(
        string="Status",
        selection=[
            ("unlocked", "Unlocked/Revised"),
            ("submitted", "Submitted"),
            ("verified", "Verified"),
        ],
        default=False,
        tracking=True,
    )

    tks_mhc_rating = fields.Selection(
        string="MHC Rating",
        selection=[
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
            ("6_1", "6-1"),
            ("6_2", "6-2"),
            ("7_1", "7-1"),
            ("7_2", "7-2"),
            ("8_1", "8-1"),
            ("8_2", "8-2"),
            ("8_3", "8-3"),
            ("9", "9"),
            ("10", "10"),
        ],
    )

    tks_is_customer = fields.Boolean(
        string="Is Customer", compute="_get_is_customer", store=True, readonly=False
    )

    # Constrains
    @api.constrains("vat", "country_id")
    def check_vat(self):
        if self.env.context.get("no_vat_validation"):
            return

        for partner in self:
            if not partner.vat or len(partner.vat) == 1:
                continue
            country = partner.commercial_partner_id.country_id
            if partner.same_vat_partner_id:
                raise ValidationError(_("NPWP already registered in the database"))

            if self._run_vat_test(partner.vat, country, partner.is_company) is False:
                partner_label = _("partner [%s]", partner.name)
                msg = partner._build_vat_error_message(
                    country and country.code.lower() or None, partner.vat, partner_label
                )
                raise ValidationError(msg)

    @api.constrains("mobile")
    def check_mobile(self):
        for partner in self:
            if partner.mobile:
                if len(partner.mobile) < 10:
                    raise ValidationError(_("Mobile/Phone cannot less than 10 digits"))

                mobile = partner.mobile

                mobile_region_code = partner.mobile[0]

                if mobile_region_code == "+" and mobile[1:].isdigit():
                    continue

                if mobile_region_code == "+" and not mobile[1:].isdigit():
                    raise ValidationError(_("Mobile number can only contain numbers"))

                if not mobile.isdigit():
                    raise ValidationError(_("Mobile number can only contain numbers"))

    @api.constrains("phone")
    def check_phone(self):
        for partner in self:
            if partner.phone:
                phone = partner.phone

                phone_region_code = phone[0]

                if phone_region_code == "+" and phone[1:].isdigit():
                    continue

                if phone[:1] == "+" and phone[1:].isdigit():
                    continue

                if phone_region_code == "+" and not phone[1:].isdigit():
                    raise ValidationError(_("Phone number can only contain numbers"))

                if not phone.isdigit():
                    raise ValidationError(_("Phone number can only contain numbers"))

    # Compute
    @api.depends("tks_contact_status")
    def _default_user_manager(self):
        for contact in self:
            contact.tks_user_manager_id = False
            user_employee = self.env.user.employee_id
            if user_employee and contact.tks_contact_status == "submitted":
                if user_employee.parent_id:
                    contact.tks_user_manager_id = (
                        user_employee.parent_id.user_id or False
                    )
                else:
                    contact.tks_user_manager_id = False

    def _get_complete_name(self):
        res = super(ResPartner, self)._get_complete_name()
        for partner in self:
            if partner.tks_dealer_name and partner.type == "dealer_pic":
                res = f"{self.name}, {self.tks_dealer_name}"

            if not partner.is_company and partner.parent_id:
                res = f"{self.name}"
        return res

    @api.depends("parent_id", "child_ids", "tks_is_customer")
    def _get_is_customer(self):
        for rec in self:
            if rec.parent_id:
                rec.tks_is_customer = rec.parent_id.tks_is_customer
            elif not rec.parent_id and rec.is_company:
                rec.tks_is_customer = rec.tks_is_customer

            if rec.child_ids:
                for child in rec.child_ids:
                    child.tks_is_customer = child.parent_id.tks_is_customer

    @api.depends('complete_name', 'email', 'vat', 'state_id', 'country_id', 'commercial_company_name', 'type')
    @api.depends_context('show_address', 'partner_show_db_id', 'address_inline', 'show_email', 'show_vat', 'lang')
    def _compute_display_name(self):
        res = super(ResPartner, self)._compute_display_name()
        for partner in self:
            if not partner.tks_dealer_name:
                return res
            
            partner.display_name = f'{partner.tks_dealer_name}, {partner.name}'
        return res

    # CRUD
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name"):
                same_contact_name = self.env['res.partner'].read_group([('name','=', vals.get('name').title())], fields=['name'], groupby=['name'])
                if same_contact_name:
                    raise ValidationError("Contact with same name is already exist")
                
        result = super(ResPartner, self).create(vals_list)
        for vals in vals_list:
            params = self._context.get("params")
            default_name = self._context.get("default_name")

            vat = vals.get("vat")
            for res in result:
                if vals.get("name"):
                    name = vals.get("name")
                    if not name.istitle():
                        res.name = res.name.title()

                if default_name:
                    res.tks_is_customer = True

                if res.vat and params:
                    res.vat = vat

                if "active_test" in self._context:
                    res.company_type = "person"

            return result

    def write(self, vals):
        if vals.get("name"):
            name = vals.get("name")
            if not name.istitle():
                vals["name"] = self.name.title()

        return super(ResPartner, self).write(vals)

    # NPWP Function
    def _split_vat(self, vat):
        if len(vat) > 1 and vat[1].isalpha():
            vat_country, vat_number = vat[:2].lower(), vat[2:].replace(" ", "")
        else:
            vat_country, vat_number = vat[:1].lower(), vat[1:].replace(" ", "")
        return vat_country, vat_number

    @api.model
    def _build_vat_error_message(self, country_code, wrong_vat, record_label):
        if self.env.context.get("company_id"):
            company = self.env["res.company"].browse(self.env.context["company_id"])
        else:
            company = self.env.company

        vat_label = _("VAT")
        if (
            country_code
            and company.country_id
            and country_code == company.country_id.code.lower()
            and company.country_id.vat_label
        ):
            vat_label = company.country_id.vat_label

        expected_format = _ref_vat.get(
            country_code, "'CC##' (CC=Country Code, ##=VAT Number)"
        )

        if "False" not in record_label:
            return "\n" + _(
                "The %(vat_label)s number [%(wrong_vat)s] for %(record_label)s does not seem to be valid. \nNote: the expected format is %(expected_format)s",
                vat_label=vat_label,
                wrong_vat=wrong_vat,
                record_label=record_label,
                expected_format=expected_format,
            )
        else:
            return "\n" + _(
                "The %(vat_label)s number [%(wrong_vat)s] does not seem to be valid. \nNote: the expected format is %(expected_format)s",
                vat_label=vat_label,
                wrong_vat=wrong_vat,
                expected_format=expected_format,
            )

    __check_vat_al_re = re.compile(r"^[JKLM][0-9]{8}[A-Z]$")

    @api.model
    def simple_vat_check(self, country_code, vat_number):
        if not country_code.encode().isalpha():
            return False
        check_func_name = "check_vat_" + country_code
        check_func = getattr(self, check_func_name, None) or getattr(
            stdnum.util.get_cc_module(country_code, "vat"), "is_valid", None
        )

        if not check_func:
            country_code = _eu_country_vat_inverse.get(country_code, country_code)
            return bool(
                self.env["res.country"].search([("code", "=ilike", country_code)])
            )

        if country_code == "id" and len(vat_number) == 16:
            return True

        return check_func(vat_number)

    @api.model
    def _run_vat_test(self, vat_number, default_country, partner_is_company=True):
        check_result = None

        vat_country_code, vat_number_split = self._split_vat(vat_number)

        # If it fails, check with default_country (if it exists)
        if default_country:
            check_result = self.simple_vat_check(
                default_country.code.lower(), vat_number
            )
            if check_result:
                return default_country.code.lower()

        return check_result

    def _create_activity(self, user):
        for partner in self:
            partner.activity_schedule(
                "tks_specific.mail_activity_tks_contact", user_id=user
            )

    # Button
    def tks_action_submit(self):
        for contact in self:
            if contact.tks_contact_status not in ["submitted", "verified"]:
                employees = self.env.user.employee_id
                for employee in employees:
                    if (
                        employee
                        and employee.parent_id
                        and not employee.parent_id.user_id.has_group(
                            "tks_specific.tks_board_of_director"
                        )
                    ):
                        contact._create_activity(employee.parent_id.user_id.id)
                if contact.child_ids:
                    for child in contact.child_ids:
                        child.sudo().tks_contact_status = "submitted"
                contact.sudo().tks_contact_status = "submitted"
                contact.tks_contact_maker_id = self.env.user

    def tks_action_lock(self):
        for contact in self:
            if contact.tks_contact_status not in ["unlocked", "verified"]:
                contact.sudo().tks_contact_status = "verified"
                if contact.child_ids:
                    for child in contact.child_ids:
                        child.sudo().tks_contact_status = "verified"

    def tks_action_unlock(self):
        for contact in self:
            if contact.tks_contact_status == "verified":
                contact.sudo().tks_contact_status = "unlocked"
                if contact.child_ids:
                    for child in contact.child_ids:
                        child.sudo().tks_contact_status = "unlocked"

    def tks_action_revised(self):
        for contact in self:
            if contact.tks_contact_status == "submitted":
                if contact.tks_contact_maker_id:
                    contact._create_activity(contact.tks_contact_maker_id.id)
                    if contact.child_ids:
                        for child in contact.child_ids:
                            child.sudo().tks_contact_status = "unlocked"
                contact.sudo().tks_contact_status = "unlocked"

    def _message_get_suggested_recipients(self):
        recipients = super()._message_get_suggested_recipients()
        for partner in self:
            if partner:
                recipients = []
        return recipients


class ResPartnerIndustry(models.Model):
    _inherit = "res.partner.industry"

    tks_industry_score_id = fields.Many2one(
        "tks.res.partner.industry.score",
        string="S&P Industry Score and Criteria Group (For Benchmarks)",
    )
    tks_cigs = fields.Char(string=_("CIGS"))
    tks_description = fields.Char(string=_("Description"))
