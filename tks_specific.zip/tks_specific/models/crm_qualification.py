from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_qualification_id = fields.Many2one('tks.qualification', string="Qualification")
    tks_disbursement_id = fields.Many2one('tks.big.project', string="Disbursement")
    tks_contract_id = fields.Many2one('tks.big.project', string="Contract")

class TksQualification(models.Model):
    _name = 'tks.qualification'
    _description = 'Qualification'

    name = fields.Char(string="Qualification")