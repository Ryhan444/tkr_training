from odoo import fields, models, _, api
from datetime import timedelta, datetime, time

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    transaction = fields.Selection([
        ('new_transaction', 'New Transaction'),
        ('lease_extension', 'Lease Extension'),
        ('permanent_exchange', 'Permanent Exchange'),
        ('changing_application', 'Changing Application'),
        ('transfer_agreement', 'Transfer Agreement'),
        ('other', 'Other'),
    ], default="new_transaction",string='Transaction')
    change_reason = fields.Text('Change Reason')
    effective_date = fields.Date('Effective Date')
    tks_im_39_changing_client_grade_risk_mitigation_ids = fields.One2many(
        'opl.changing.client.grade.risk.mitigation', 
        'request_id', string='OPL - Changing Client Grade Risk Mitigation'
    )
    tks_im_39_before = fields.Char('Before')
    tks_im_39_after = fields.Char('After')
   

class OplChangingClientGradeRiskMitigation(models.Model):
    _name = 'opl.changing.client.grade.risk.mitigation'
    _description = 'OPL Changing Client Grade Risk Mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')

    