from odoo import models, fields, api


class XlsxWizard(models.Model):
    _name = "cdp.xlsx.wizard"
    _description = "Wizard for generate xlsx report"

    date_submit = fields.Date("Period Date")
    plate_number = fields.Char("Plate Number", index="trigram")
    partner_id = fields.Many2one("res.partner", string="Customer")
    cdp_service_location = fields.Selection(
        string="Service Location",
        selection=[
            ("inhouse", "Inhouse"),
            ("storing", "Storing"),
            ("external", "External"),
        ],
    )
    cdp_vendor_id = fields.Many2one(
        "res.partner",
        "Vendor",
    )
    type_inquiry_id = fields.Many2one("type.inquiry", string="Type Inquiry")
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("in_approval", "In Approval"),
            ("released", "Released"),
            ("complete", "Complete"),
            ("cancel", "Cancelled"),
        ],
        string="SPK Status",
    )

    def action_search_spk(self):
        filters = {
            "date_submit": (">=", self.date_submit),
            "plate_number": ("ilike", self.plate_number),
            "partner_id": ("=", self.partner_id.id if self.partner_id else False),
            "type_inquiry_id": (
                "=",
                self.type_inquiry_id.id if self.type_inquiry_id else False,
            ),
            "cdp_service_location": ("=", self.cdp_service_location),
            "state": ("=", self.state),
            "cdp_vendor_name": (
                "ilike",
                self.cdp_vendor_id.name if self.cdp_vendor_id else False,
            ),
        }

        domain = [(field, op, val) for field, (op, val) in filters.items() if val]

        return {
            "type": "ir.actions.act_window",
            "name": "Inquiry / SPK Report",
            "res_model": "overall.report",
            "view_mode": "list",
            "target": "current",
            "domain": domain,
            "context": {"create": False},
        }
