/** @odoo-module */

import { registry } from "@web/core/registry";
import { formView } from "@web/views/form/form_view";
import { FormController } from '@web/views/form/form_controller';
import { useEffect } from "@odoo/owl";

class CdpRepairForm extends FormController {
    setup() {
        super.setup()
        useEffect(()=>{
            this.disableForm()
        }, ()=>[this.model.root.data.state])

        this.onNotebookPageChange = (notebookId, page) => {
            this.disableForm()
        };
    }

    disableForm(){
        const inputElements = document.querySelectorAll(".o_form_sheet input")
        const fieldWidgets = document.querySelectorAll(".o_form_sheet .o_field_widget")
        const model = this.props.resModel
        const attachmentField = this.model.root.fields.cdp_attachment
        var locked = false

        if (model == 'repair.order') {
            var draft = this.model.root.data.state == 'draft'

            if (!draft) {
                if (inputElements) inputElements.forEach(e => {
                    if (!e.type === 'file') {
                        e.setAttribute("disabled", 1)
                    }
                })
                if (fieldWidgets) fieldWidgets.forEach(e => {
                    e.classList.add("pe-none")
                })
                this.canEdit = false
            } else {
                if (inputElements) inputElements.forEach(e => e.removeAttribute("disabled"))
                if (fieldWidgets) fieldWidgets.forEach(e => e.classList.remove("pe-none"))
                this.canEdit = true
            }
        }
    }

    async beforeLeave() {
        if (this.model.root.data.state == 'released') return
        super.beforeLeave()
    }

    async beforeUnload(ev) {
        if (this.model.root.data.state == 'released') return
        super.beforeUnload(ev)
    }
}

const formViewInherit = {
    ...formView,
    Controller: CdpRepairForm,
}

registry.category("views").add("cdp_repair_form_disable", formViewInherit)
