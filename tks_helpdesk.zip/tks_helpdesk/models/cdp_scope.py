from odoo import models, fields, api


class CdpScope(models.Model):
    _name = "cdp.scope"
    _description = "Scope"

    name = fields.Char(string="Name")


class CdpCategoty(models.Model):
    _name = "cdp.category"
    _description = "Category"

    name = fields.Char(string="Name")
