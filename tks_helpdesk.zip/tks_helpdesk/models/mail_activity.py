from odoo import models


class MailActivity(models.Model):
    _inherit = "mail.activity"

    def action_notify(self):
        if self._context.get("from_spk_inq"):
            return
        else:
            return super(MailActivity, self).action_notify()
