from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_reason_no_29 = fields.Text('Reason / Explanation')
    tks_release_date_29 = fields.Date('Contract Release Date from Cust')
    tks_opl_changing_signer_risk_mitigation_line_ids = fields.One2many('opl.contract.template.customer.risk.mitigation', 'request_id', string='Lines OPL - Using Contract Template By Customer Risk Mitigation')
    
    
class OplContractTemplateCustomerRiskMitigation(models.Model):
    _name = 'opl.contract.template.customer.risk.mitigation'
    _description = 'OPL - Using Contract Template By Customer Risk and Mitigation'
    _rec_name = 'risk_mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')