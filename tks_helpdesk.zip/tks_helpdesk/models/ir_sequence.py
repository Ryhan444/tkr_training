from odoo import models, fields


class IrSequence(models.Model):
    _inherit = "ir.sequence"

    def _cron_reset_sequence(self):
        seq_codes = [
            "helpdesk.service",
            "spk.ext",
            "spk.inh",
            "spk.sto",
            "spk.exp",
            "helpdesk.marketing",
            "helpdesk.asset",
            "helpdesk.pool",
            "helpdesk.finance",
            "helpdesk.service",
            "helpdesk.claim",
        ]
        for code in seq_codes:
            seq = self.search([("code", "ilike", code)], limit=1)
            if seq:
                seq.number_next_actual = 1
