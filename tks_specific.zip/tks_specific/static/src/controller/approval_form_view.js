/** @odoo-module */

import { registry } from "@web/core/registry";
import { formView } from "@web/views/form/form_view";
import { FormController } from '@web/views/form/form_controller';
import { useEffect } from "@odoo/owl";
import { AttachmentList } from "@mail/core/common/attachment_list";
import { patch } from "@web/core/utils/patch";


patch(AttachmentList.prototype, {
    setup() {
        super.setup();
    },

    get showDelete() {
        return this.env.model.root.data.request_status === "new" ? true : false;
    },
});


class TksApprovalFormViewInherit extends FormController {
    setup() {
        super.setup();
        
        useEffect(() => {
            this.disableForm();
        }, () => [this.model.root.data.request_status]);

        this.onNotebookPageChange = (notebookId, page) => {
            this.disableForm();
        };
    }

    disableForm() {
        const inputElements = document.querySelectorAll(".o_form_sheet input");
        const fieldWidgets = document.querySelectorAll(".o_form_sheet .o_field_widget");
        const model = this.props.resModel;
        let locked = false;

        if (model === 'approval.request') {
            locked = !['new'].includes(this.model.root.data.request_status);
            if (locked) {
                if (inputElements) inputElements.forEach(e => e.setAttribute("disabled", 1));
                if (fieldWidgets) {
                    fieldWidgets.forEach((e) => {
                        if (!e.getAttribute("name").includes("_ids")) {
                            e.classList.add("pe-none")
                        }
                    });
                }
                this.canEdit = false;
            } else {
                if (inputElements) inputElements.forEach(e => e.removeAttribute("disabled"));
                if (fieldWidgets) fieldWidgets.forEach(e => e.classList.remove("pe-none"));
                this.canEdit = true;
            }
        }
    }

    async beforeLeave() {
        if (!['new'].includes(this.model.root.data.request_status)) return;
        super.beforeLeave();
    }

    async beforeUnload(ev) {
        if (!['new'].includes(this.model.root.data.request_status)) return;
        super.beforeUnload(ev);
    }
}

const approvalFormViewInherit = {
    ...formView,
    Controller: TksApprovalFormViewInherit,
};

registry.category("views").add("tks_approval_form_disable", approvalFormViewInherit);
