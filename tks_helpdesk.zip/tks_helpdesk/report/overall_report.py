from odoo import fields, models, tools


class OverallReport(models.Model):
    _name = "overall.report"
    _description = "SPK / Inquiry Report"
    _auto = False
    _order = False

    # === Inquiry Fields ===
    inq_title = fields.Char(string="Inquiry", compute="_get_spk_name")
    id = fields.Integer("ID", readonly=True)
    ticket_id = fields.Many2one("helpdesk.ticket", string="Inquiry ID", readonly=True)
    cdp_create_date = fields.Datetime("Date of Inquiry", readonly=True)
    date_close = fields.Datetime(
        "Closed Date", readonly=True, related="ticket_id.date_close"
    )
    date_submit = fields.Datetime(
        "Submit Date", readonly=True, related="ticket_id.date_submit"
    )
    category_id = fields.Many2one(
        "category.type", string="Category Inquiry", related="ticket_id.category_id"
    )
    cdp_reject_date = fields.Datetime(
        "Reject Date", readonly=True, related="ticket_id.cdp_reject_date"
    )
    source_inquiry_id = fields.Many2one(
        "source.inquiry", "Source of Inquiry", readonly=True
    )
    type_inquiry_id = fields.Many2one(
        "type.inquiry", string="Type of Inquiry", related="ticket_id.type_inquiry_id"
    )
    duration_tracking_display = fields.Char(
        string="Inquiry Aging", related="ticket_id.duration_tracking_display"
    )
    total_duration_tracking = fields.Char(
        string="Inquiry Total Aging", related="ticket_id.total_duration_tracking"
    )
    cdp_ref_inq = fields.Char("SPK ID", related="ticket_id.cdp_ref_inq")
    cdp_req_non_serv_inq_id = fields.Many2one(
        "helpdesk.ticket", "Ref Inquiry ID", related="ticket_id.cdp_req_non_serv_inq_id"
    )
    stage_id = fields.Many2one("helpdesk.stage", readonly=True)
    partner_id = fields.Many2one("res.partner", "Customer Name", readonly=True)
    pic_name = fields.Char("PIC Customer", readonly=True)
    pic_number = fields.Char("PIC No.", readonly=True)
    plate_number = fields.Char("Plate Number", readonly=True)
    brand = fields.Char("Brand", readonly=True)
    type = fields.Char("Type", readonly=True)
    year = fields.Char("Year", readonly=True)
    color = fields.Char("Color", readonly=True)
    kilometer = fields.Char("KM", readonly=True)
    rent_status = fields.Char("Rent Status", readonly=True)
    actual_location = fields.Char("Actual Location", readonly=True)
    description_service = fields.Char("Description", readonly=True)
    pic_name_1 = fields.Char("PIC Name", related="ticket_id.pic_name_1")
    pic_contact = fields.Char("PIC Contact", related="ticket_id.pic_contact")
    relocation_address = fields.Char(
        "Relocation Address", related="ticket_id.relocation_address"
    )
    cdp_vendor_names = fields.Char("Vendor Name", related="ticket_id.cdp_vendor_name")
    cdp_vendor_address = fields.Char(
        "Vendor Address", related="ticket_id.cdp_vendor_address"
    )
    pic_call_center = fields.Char("PIC Call Center", readonly=True)

    # === SPK Field ===
    spk_title = fields.Char(string="SPK", compute="_get_spk_name")
    repair_id = fields.Many2one("repair.order", "SPK ID", readonly=True)
    create_date = fields.Datetime("Created On")
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("in_approval", "In Approval"),
            ("released", "Released"),
            ("complete", "Complete"),
            ("cancel", "Cancelled"),
        ],
        string="SPK Status",
    )
    cdp_service_location = fields.Selection(
        string="Serv. Loc.",
        selection=[
            ("inhouse", "Inhouse"),
            ("storing", "Storing"),
            ("external", "External"),
        ],
    )
    cdp_spk_type = fields.Selection(
        string="SPK Type",
        selection=[
            ("inspector", "SPK Inspection"),
            ("repair", "SPK Repair"),
        ],
    )
    cdp_spk_ref_id = fields.Many2one(
        "repair.order",
        string="SPK Ref.",
    )
    cdp_kilometer = fields.Float(string="KM", related="repair_id.cdp_kilometer")
    cdp_scope_names = fields.Char("Scopes", readonly=True)
    cdp_category_names = fields.Char("Sub Category")
    product_names = fields.Char("Item")
    cdp_estimation_cost = fields.Float("Estimation Cost")
    cdp_mechanic_name = fields.Char(
        "Mechanic Name",
        index="trigram",
    )
    cdp_schedule_date = fields.Date(string="Scheduled Date")
    cdp_vendor_name = fields.Char(
        "Vendor",
    )
    cdp_repair_type = fields.Selection(
        selection=[("new", " New"), ("extend", "Extend SPK")],
        string="SPK Purpose",
    )
    cdp_description = fields.Char(
        string="Description", related="repair_id.cdp_description"
    )
    state_duration_tracking_display = fields.Char(
        string="Aging",
        related="repair_id.state_duration_tracking_display",
    )
    total_duration_tracking_display = fields.Char(
        string="Aging",
        related="repair_id.state_duration_tracking_display",
    )
    cdp_final_approver = fields.Char(
        "Final Approver", compute="_get_final_approver_user"
    )
    cdp_expired_date = fields.Datetime(
        string="SPK Expiry Date", related="repair_id.cdp_expired_date"
    )
    cdp_complete_date = fields.Datetime(
        string="Completed On", related="repair_id.cdp_complete_date"
    )

    # === COMPUTES ===
    def _get_final_approver_user(self):
        for rec in self:
            approvers = rec.repair_id.cdp_approval_approvers_ids.filtered(
                lambda x: x.cdp_approver_level_repair == "2"
            )
            names = ", ".join(approvers.mapped("user_id.name"))
            rec.cdp_final_approver = names or False

    def _get_spk_name(self):
        for rec in self:
            rec.spk_title = "SPK"
            rec.inq_title = "Inquiry"

    # === SQL Construction ===
    def _select_inq(self):
        return """
            SELECT
                COALESCE(ro.id, ht.id * -1) AS id,  -- Inquiry tanpa SPK tetap muncul
                ht.id AS ticket_id,
                ro.id AS repair_id,
                ht.create_date AS cdp_create_date,
                ht.stage_id AS stage_id,
                ht.partner_id AS partner_id,
                ht.source_inquiry_id AS source_inquiry_id,
                ht.pic_name AS pic_name,
                ht.pic_number AS pic_number,
                ht.plate_number AS plate_number,
                ht.brand AS brand,
                ht.type_details_service AS type,
                ht.year AS year,
                ht.cdp_color AS color,
                ht.kilometer AS kilometer,
                ht.rent_status AS rent_status,
                ht.actual_location AS actual_location,
                ht.desciption_service AS description_service,
                ht.pic_call_center AS pic_call_center,
                ro.create_date AS create_date,
                ro.state AS state,
                ro.cdp_spk_type AS cdp_spk_type,
                ro.cdp_spk_ref_id AS cdp_spk_ref_id,
                ro.cdp_service_location AS cdp_service_location,
                move_scope.cdp_scope_names AS cdp_scope_names,
                move_scope.cdp_category_names AS cdp_category_names,
                move_scope.product_names AS product_names,
                ro.cdp_estimation_cost AS cdp_estimation_cost,
                ro.cdp_mechanic_name AS cdp_mechanic_name,
                ro.cdp_schedule_date AS cdp_schedule_date,
                alter.cdp_vendor_name AS cdp_vendor_name,
                ro.cdp_repair_type AS cdp_repair_type
        """

    def _from_inq(self):
        return """
            FROM helpdesk_ticket ht
            LEFT JOIN repair_order ro ON ro.ticket_id = ht.id
            LEFT JOIN (
                SELECT
                    sm.repair_id,
                    string_agg(DISTINCT (pt.name->>'en_US'), ', ') AS product_names,
                    string_agg(DISTINCT cs.name::text, ', ') AS cdp_scope_names,
                    string_agg(DISTINCT cc.name::text, ', ') AS cdp_category_names
                FROM stock_move sm
                JOIN product_product pp ON pp.id = sm.product_id
                JOIN product_template pt ON pt.id = pp.product_tmpl_id
                LEFT JOIN cdp_scope cs ON cs.id = pt.cdp_scope_id
                LEFT JOIN cdp_category_product_template_rel rel ON rel.product_template_id = pt.id
                LEFT JOIN cdp_category cc ON cc.id = rel.cdp_category_id
                WHERE sm.repair_id IS NOT NULL
                GROUP BY sm.repair_id
            ) move_scope ON move_scope.repair_id = ro.id
            LEFT JOIN (
                SELECT
                    alt.cdp_repair_id,
                    string_agg(DISTINCT rp.name::text, ', ') AS cdp_vendor_name
                FROM cdp_alternative_vendor alt
                JOIN res_partner rp ON rp.id = alt.cdp_vendor_id
                WHERE alt.cdp_repair_id IS NOT NULL
                GROUP BY alt.cdp_repair_id
            ) alter ON alter.cdp_repair_id = ro.id
        """

    def _where_inq(self):
        return "WHERE TRUE"

    def _group_by(self):
        return """
            GROUP BY
                ro.id, ht.id, ht.create_date, ht.stage_id, ht.partner_id,
                ht.source_inquiry_id, ht.pic_name, ht.pic_number, ht.plate_number,
                ht.brand, ht.type_details_service, ht.year, ht.cdp_color,
                ht.kilometer, ht.rent_status, ht.actual_location,
                ht.desciption_service, ht.pic_call_center,
                ro.create_date, ro.state, ro.cdp_spk_type, ro.cdp_spk_ref_id,
                ro.cdp_service_location, move_scope.cdp_scope_names,
                move_scope.cdp_category_names, move_scope.product_names,
                ro.cdp_estimation_cost, ro.cdp_mechanic_name,
                ro.cdp_schedule_date, ro.cdp_vendor_id, ro.cdp_repair_type,
                alter.cdp_vendor_name
        """

    def _query(self):
        return f"""
            {self._select_inq()}
            {self._from_inq()}
            {self._where_inq()}
            {self._group_by()}
        """

    def init(self):
        """Create SQL view"""
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute(
            f"""
            CREATE OR REPLACE VIEW {self._table} AS (
                {self._query()}
            )
            """
        )

    def button_print_xlsx(self):
        for report in self:
            return {
                "type": "ir.actions.act_url",
                "url": f"/spk/excel/report/{self.env.context.get('active_ids')}",
                "target": "new",
            }
