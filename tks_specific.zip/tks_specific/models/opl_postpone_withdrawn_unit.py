from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    @api.constrains("tks_wl_type_21")
    def check_tks_wl_type_21(self):
        for rec in self:
            if rec.tks_wl_type_21 and not rec.tks_wl_type_21.isdigit():
                raise ValidationError(_("WL Type must be a Number"))
            
    @api.constrains("tks_od_days21")
    def check_tks_od_days21(self):
        for rec in self:
            if rec.tks_od_days21 and not rec.tks_od_days21.isdigit():
                raise ValidationError(_("OD Days must be a Number"))        
    
    
    @api.constrains("tks_last_postpone_days_21")
    def check_tks_last_postpone_days_21(self):
        for rec in self:
            if rec.tks_last_postpone_days_21 and not rec.tks_last_postpone_days_21.isdigit():
                raise ValidationError(_("Last Postpone Days must be a Number"))

    tks_contract_no_21 = fields.Char(string="Contract No.")
    tks_addendum_no_21 = fields.Char("Addendum No.")
    tks_wl_type_21 = fields.Char("WL Type")
    tks_letter_date = fields.Date("Letter Date")
    tks_letter_no = fields.Char("Letter No.")
    tks_ar_outstanding_wl3_21_id = fields.Monetary(
        "AR Outstanding WL3", currency_field="tks_currency_id"
    )
    tks_total_ar_outstanding_21 = fields.Monetary(
        "Total AR Outstanding", currency_field="tks_currency_id"
    )
    tks_od_days21 = fields.Char("OD Days")
    tks_last_postpone_days_21 = fields.Char("Last Postpone Days")
    tks_schedule_payment_21 = fields.Date("Schedule Payment")
    tks_postpone_until_21 = fields.Date("Postpone Until")
    tks_reason_postpone_21 = fields.Text("Reason of Postponement")
    tks_opl_postpone_withdrawn_unit_line_ids = fields.One2many(
        "opl.postpone.withdrawn.unit.risk.mitigation",
        "request_id",
        string="Lines Borrow BPKB Risk and Mitigation",
    )


class OplBorrowBPKBRiskMitigation(models.Model):
    _name = "opl.postpone.withdrawn.unit.risk.mitigation"
    _description = "OPL - Borrow BPKB Risk and Mitigation"
    _rec_name = "risk_mitigation"

    request_id = fields.Many2one(
        "approval.request", string="Approval", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        [
            ("risk", "Risk"),
            ("mitigation", "Mitigation"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
