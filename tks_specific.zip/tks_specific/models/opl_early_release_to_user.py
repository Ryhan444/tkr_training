from odoo import _, api, fields, models
import datetime

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_bpkb_fields = any(
            not line.tks_bpkb_no_19 or not line.tks_bpkb_release_date_19
            for line in self.tks_bpkb_19_ids
        )
        missing_release_fields = any(
            not line.item or not line.reason or not line.risk_mitigation or not line.fullfilment_date
            for line in self.tks_opl_release_to_user_ids
        )
        missing_risk_mitigation = any(
            not line.risk_mitigation or not line.remarks
            for line in self.tks_opl_release_to_user_risk_mitigation_ids
        )
        if self.tks_has_tks_im_early_release_the_bpkb_to_user != 'no':
            if not self.tks_bpkb_19_ids or missing_bpkb_fields:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Proposal Line Empty'),
                        'message': _('Please fill in the required fields in the Proposal Line.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
            if not self.tks_opl_release_to_user_risk_mitigation_ids or missing_risk_mitigation:
                notification = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Risk Mitigation Empty'),
                        'message': _('Risk Mitigation must be filled.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
                return notification  
            if self.list_of_outstanding_19 != 'no' and not self.tks_opl_release_to_user_ids or missing_release_fields:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('List of Outstanding Items Empty'),
                        'message': _('Please fill in the required fields in the List of Outstanding Items.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
        return super(ApprovalRequest, self).action_confirm()

    
    
    tks_opl_release_to_user_ids = fields.One2many('opl.early.release.to.user', 'request_id', string='OPL - Early Release The BPKB to User')
    tks_opl_release_to_user_risk_mitigation_ids = fields.One2many('opl.early.release.to.user.risk.mitigation', 'request_id', string='OPL - Early Release The BPKB to User Risk Mitigation')
    tks_bpkb_19_ids = fields.One2many('opl.early.release.to.user.bpkb', 'request_id', string='BPKB')
    list_of_outstanding_19 = fields.Selection([
        ('no', 'No'),
        ('yes', 'Yes'),
    ], default='no', string='List of Outstanding Items')

class OplEarlyReleaseToUser(models.Model):
    _name = 'opl.early.release.to.user.bpkb'
    _description = 'OPL - Early Release The BPKB to User BPKB'
    
    tks_bpkb_no_19 = fields.Char('BPKB No.')
    tks_bpkb_release_date_19 = fields.Date('BPKB Release Date')
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
        

class OplEarlyReleaseToUser(models.Model):
    _name = 'opl.early.release.to.user'
    _description = 'OPL - Early Release The BPKB to User'
    _rec_name = 'item'
    
    @api.depends('request_id.tks_opl_release_to_user_ids')
    def _compute_sequence(self):
        for line in self:
            if line.request_id:
                tks_opl_release_to_user_idss = line.request_id.tks_opl_release_to_user_ids.sorted(lambda l: l.create_date if l.create_date else datetime.datetime.max)
                for index, tks_opl_release_to_user_ids in enumerate(tks_opl_release_to_user_idss, start=1):
                    tks_opl_release_to_user_ids.sequence = index
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    sequence = fields.Integer('No.', compute='_compute_sequence', store=True)
    item = fields.Char(string='Item')
    reason = fields.Text('Reason / Amount')
    risk_mitigation = fields.Text('Risk & Mitigation')
    fullfilment_date = fields.Date('Fulfillment Date')
    
class OplEarlyReleaseToUserRiskMitigation(models.Model):
    _name = 'opl.early.release.to.user.risk.mitigation'
    _description = 'OPL - Borrow BPKB Risk and Mitigation'
    _rec_name = 'risk_mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')