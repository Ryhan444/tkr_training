from odoo import models, fields


class StockMove(models.Model):
    _inherit = "stock.move"

    cdp_category = fields.Many2one(
        "product.category", string="Scope", related="product_id.categ_id"
    )

    cdp_scope_id = fields.Many2one(
        "cdp.scope", string="Scope", related="product_id.cdp_scope_id"
    )

    cdp_sub_category = fields.Many2one(
        "product.tag",
        string="Category",
    )

    cdp_related_categ = fields.Many2many(
        "product.tag", related="product_id.product_tag_ids"
    )

    cdp_category_ids = fields.Many2one("cdp.category", string="Category")
    cdp_related_categ_ids = fields.Many2many(
        "cdp.category", related="product_id.cdp_category_ids"
    )
    cdp_part_description = fields.Char("Description", store=True)
