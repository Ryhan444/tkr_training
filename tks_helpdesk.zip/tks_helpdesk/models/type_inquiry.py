from odoo import models, fields, api, _
from ast import literal_eval
from dateutil.relativedelta import relativedelta

class TypeInquiry(models.Model):
    _name = 'type.inquiry'

    name = fields.Char(string="Type of Inquiry")