from odoo import api, fields, models, _

from odoo.exceptions import UserError
class TksEditorReviewer(models.TransientModel):
    _name = 'tks.editor.reviewer'
    _description = 'Editor Reviewer'

    def _get_default_im(self):
        context = self._context
        active_id = context.get('active_id')
        if active_id:
            related_im = self.env['approval.request'].browse(active_id)
            return related_im

    tks_im_id = fields.Many2one("approval.request", "Internal Memo", default=_get_default_im)
    tks_can_edit_all_approvers = fields.Boolean("Can edit all level", related="tks_im_id.tks_can_edit_all_approvers")
    tks_approver_level_1 = fields.Selection(string="Approver Level", selection=[('level_1', 'Reviewer')], default="level_1", readonly=True)
    tks_approver_all_level = fields.Selection(string="Approver Level", selection=[('level_1', "Reviewer"),('level_2', "Acknowledger"),('level_3', "Approver"),('level_4', "Final Approver")])
    tks_user_level_1_id = fields.Many2one("res.users", string="User")
    tks_user_all_level_id = fields.Many2one("res.users", string="User")

    def action_save_editor(self):
        if self.tks_im_id and self.tks_im_id.request_status == 'new':
            approver_obj = self.env['approval.approver']

            if self.tks_approver_level_1 and self.tks_user_level_1_id:
                approver_obj.create({
                    'tks_approvers_level': self.tks_approver_level_1,
                    'user_id': self.tks_user_level_1_id.id,
                    'request_id': self.tks_im_id.id,
                })

            if self.tks_approver_all_level and self.tks_user_all_level_id:
                approver_obj.create({
                    'tks_approvers_level': self.tks_approver_all_level,
                    'user_id': self.tks_user_all_level_id.id,
                    'request_id': self.tks_im_id.id,
                })
        elif self.tks_im_id and self.tks_im_id.request_status != 'new':
            approver_obj = self.env['approval.approver']
            create_activity = False
            cannot_add_appover = False
            if self.tks_approver_all_level and self.tks_user_all_level_id:

                print('request status', self.tks_im_id.request_status)
                if self.tks_im_id.request_status == 'pending':
                    if self.tks_approver_all_level == 'level_1':
                        status = "pending"
                        create_activity = True
                    else:
                        status = "waiting"

                elif self.tks_im_id.request_status == 'reviewed':
                    if self.tks_approver_all_level == 'level_1':
                        cannot_add_appover = True
                    if self.tks_approver_all_level == 'level_2':
                        status = "pending"
                        create_activity = True
                    else:
                        status = "waiting"

                elif self.tks_im_id.request_status == 'ready_approve':
                    if self.tks_approver_all_level in ['level_3', 'level_2']:
                        cannot_add_appover = True
                    if self.tks_approver_all_level == 'level_3':
                        status = "pending"
                        create_activity = True
                    else:
                        status = "waiting"
                if cannot_add_appover:
                    raise UserError(
                        "Cannot add approver for %s because already in state %s" % (self.tks_approver_all_level,
                                                                                    self.tks_im_id.request_status))

                approver_id = approver_obj.create({
                    'tks_approvers_level': self.tks_approver_all_level,
                    'user_id': self.tks_user_all_level_id.id,
                    'request_id': self.tks_im_id.id,
                    'status': status
                })
                if create_activity:
                    approver_id._create_activity()
