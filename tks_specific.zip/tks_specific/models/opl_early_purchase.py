from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_14_business_benefit_ids = fields.One2many(
        "tks.im.14.business.benefit",
        "request_id",
        string="OPL - Business Benefit",
    )

    tks_im_14_contract_number = fields.Char(string="Contract No.")
    tks_im_14_addendum_number = fields.Char(string="Addendum No.")
    tks_im_14_client_grade = fields.Char(string="Client Grade")
    tks_im_14_early_purchase_date_ori_start = fields.Date(
        string=_("Early Purchase Date Original"),
    )
    tks_im_14_early_purchase_date_ori_end = fields.Date(
        string=_("Early Purchase Date Original"),
    )
    tks_im_14_early_purchase_date_ep_start = fields.Date(
        string=_("Early Purchase Date EP Condition"),
    )
    tks_im_14_early_purchase_date_ep_end = fields.Date(
        string=_("Early Purchase Date EP Condition"),
    )
    tks_im_14_lease_term_ori = fields.Char(string="Lease Term Original")
    tks_im_14_lease_term_ep = fields.Char(string="Lease Term EP Condition")
    tks_im_14_purchase_price = fields.Monetary(
        string="Purchase Price", currency_field="tks_currency_id"
    )
    tks_im_14_purchase_price_ep = fields.Monetary(
        string="Purchase Price", currency_field="tks_currency_id"
    )
    tks_im_14_old_calculation_irr = fields.Float(string="Old Calculation IRR")
    tks_im_14_new_calculation_irr = fields.Float(string="New Calculation IRR")
    tks_im_14_old_calculation_irr_ep = fields.Float(string="Old Calculation IRR EP")
    tks_im_14_new_calculation_irr_ep = fields.Float(string="New Calculation IRR EP")
    tks_im_14_old_calculation_net_spread = fields.Float(
        string="Old Calculation Net Spread"
    )
    tks_im_14_new_calculation_net_spread = fields.Float(
        string="New Calculation Net Spread"
    )
    tks_im_14_new_calculation_net_spread_ep = fields.Float(
        string="New Calculation Net Spread EP"
    )
    tks_im_14_old_calculation_net_spread_ep = fields.Float(
        string="Old Calculation Net Spread EP"
    )
    tks_im_14_old_calculation_npv = fields.Monetary(
    string="Old Calculation NPV",
    currency_field="tks_currency_id",
    )
    tks_im_14_new_calculation_npv = fields.Monetary(
        string="New Calculation NPV",
        currency_field="tks_currency_id",
    )
    tks_im_14_new_calculation_npv_ep = fields.Monetary(
        string="New Calculation NPV EP",
        currency_field="tks_currency_id",
    )
    tks_im_14_old_calculation_npv_ep = fields.Monetary(
        string="Old Calculation NPV EP",
        currency_field="tks_currency_id",
    )

    def format_amount_in_millions(self, amount):
        if not isinstance(amount, (int, float)):
            raise ValueError("Amount must be an integer or a float.")

        calculated_amount = amount / 10**6
        if len(str(amount)) > 6:
            amount_in_millions = round(calculated_amount, 2)
            return f"{self.tks_currency_id.symbol} {amount_in_millions}"
        else:
            amount
            return f"{self.tks_currency_id.symbol} {amount}"

class TksIm13BusinessBenefit(models.Model):
    _name = "tks.im.14.business.benefit"
    _description = "Business Benefit"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("bc", "Business Consideration"),
            ("calculation", "Calculation (if any)"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
