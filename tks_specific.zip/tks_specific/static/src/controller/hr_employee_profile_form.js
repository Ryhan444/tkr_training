/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { EmployeeProfileController } from "@hr/views/profile_form_view";
import { useEffect } from "@odoo/owl";
import { onWillStart } from "@odoo/owl";
import { user } from "@web/core/user";

// function setupContactAccess(controller) {
//     onWillStart(async () => {
//         controller.adminAccess = await user.hasGroup("sales_team.group_sale_manager");
//     });
// }

patch(EmployeeProfileController.prototype, {
    setup() {
        super.setup();

        // setupContactAccess(this);

        useEffect(()=>{
            this.disableForm()
        }, ()=>[])

        this.onNotebookPageChange = (notebookId, page) => {
            this.disableForm()
        };
    },
    disableForm(){
        const inputElements = document.querySelectorAll(".o_form_sheet input")
        const fieldWidgets = document.querySelectorAll(".o_form_sheet .o_field_widget")
        const model = this.props.resModel

        if (model == 'res.users') {
            if (inputElements) inputElements.forEach(e => e.setAttribute("disabled", 1))
            if (fieldWidgets) fieldWidgets.forEach(e => e.classList.add("pe-none"))
            this.canEdit = false
        }
    },

    async beforeLeave() {
        return
    },

    async beforeUnload(ev) {
        return
    }
});