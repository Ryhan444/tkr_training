from odoo import fields, models, _, api
from datetime import timedelta, datetime, time
from odoo.exceptions import ValidationError


class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_document_fields = any(
            not line.before or not line.after
            for line in self.tks_im_36_dispatcher_request_spread_change_ids
        )
        if self.tks_has_tks_im_dispatcher_request != 'no' and (
            not self.tks_im_36_dispatcher_request_spread_change_ids or missing_document_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Spread Change Empty'),
                    'message': _('Spread Change must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()
    
    @api.constrains("tks_im_36_dispatcher_request_number_dispatchero")
    def check_tks_im_36_dispatcher_request_number_dispatchero(self):
        for rec in self:
            if rec.tks_im_36_dispatcher_request_number_dispatchero and not rec.tks_im_36_dispatcher_request_number_dispatchero.isdigit():
                raise ValidationError(_("Number of Dispatcher must be a Number"))

    tks_im_36_dispatcher_request_contract_no = fields.Char('Contract No')
    tks_im_36_dispatcher_request_addendum_no = fields.Char('Addendum No')
    tks_im_36_dispatcher_request_number_dispatchero = fields.Char('Number of Dispatcher')
    tks_im_36_dispatcher_request_start_date = fields.Date('Start - End Date')
    tks_im_36_dispatcher_request_end_date = fields.Date('End Date')
    tks_im_36_dispatcher_request_verified = fields.Boolean('Verified')
    tks_im_36_dispatcher_request_dispatcher_location = fields.Char('Dispatcher Location')
    tks_im_36_dispatcher_request_total_cost = fields.Monetary(
        string=_("Total Cost"),
        currency_field="tks_currency_id",
    )
    tks_im_36_dispatcher_request_reason = fields.Text('Reason')
    tks_im_36_dispatcher_request_spread_change_ids = fields.One2many(
        'opl.dispatcher.request.spread.change', 
        'request_id', string='Spread Change'
    )
    tks_im_36_dispatcher_request_business_benefit_ids = fields.One2many(
        'opl.dispatcher.request.business.benefit', 
        'request_id', string='OPL - Dispatcher Request Business Benefit'
    )
    tks_im_36_dispatcher_request_risk_mitigation_ids = fields.One2many(
        'opl.dispatcher.request.risk.mitigation', 
        'request_id', string='OPL - Dispatcher Request Risk Mitigation'
    )

class OplDispatcherRequestBusinessBenefit(models.Model):
    _name = 'opl.dispatcher.request.business.benefit'
    _description = 'OPL Dispatcher Request Business Benefit'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item =  fields.Selection([
        ('bc', 'Business Consideration'), 
        ('calculation', 'Calculation (if any)'),], 
        string='Item')
    remarks = fields.Text('Remarks')


class OplDispatcherRequestRiskMitigation(models.Model):
    _name = 'opl.dispatcher.request.risk.mitigation'
    _description = 'OPL Dispatcher Request Risk Mitigation'

    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation =  fields.Selection([
        ('risk', 'Risk'), 
        ('mitigation', 'Mitigation'),], 
        string='Item')
    remarks= fields.Text('Remarks')

class OplDispatcherRequestSpreadChange(models.Model):
    _name = 'opl.dispatcher.request.spread.change'
    _description = 'OPL Dispatcher Request Spread Change'

    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    before= fields.Text('Before')
    after= fields.Text('After')
