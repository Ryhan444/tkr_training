from odoo import fields, models, _, api, Command
from datetime import datetime
from odoo.exceptions import UserError, ValidationError
import logging

from markupsafe import Markup

_logger = logging.getLogger(__name__)


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_user_approve_ids = fields.Many2many('res.users', string='User Not Yet Approved', compute='_compute_user_approve',store=True)

    # Added Fields
    tks_can_edit_all_approvers = fields.Boolean(string="Can edit all level", related="category_id.tks_can_edit_all_approvers")
    tks_approver_reviewer_ids = fields.One2many('approval.approver', 'request_id', string="Approvers Reviewer", check_company=True,
        compute='_compute_approver_reviewer_ids', readonly=False)
    tks_already_submit = fields.Boolean(string="Already Submitted", default=False)
    tks_in_level = fields.Boolean(string="In Current Level", compute="_get_approver_state")
    tks_already_approve = fields.Boolean(string="Already Approved", compute="_get_approver_state")
    tks_user_level_1 = fields.Many2many(
        "res.users",
        string="User Level 1",
        store=True,
        compute="_get_user_level_1",
        relation="approval_request_user_level_1_rel"
    )
    tks_user_level_2 = fields.Many2many(
        "res.users",
        string="User Level 2",
        store=True,
        compute="_get_user_level_2",
        relation="approval_request_user_level_2_rel"
    )
    tks_user_level_3 = fields.Many2many(
        "res.users",
        string="User Level 3",
        store=True,
        compute="_get_user_level_3",
        relation="approval_request_user_level_3_rel"
    )
    tks_user_level_4 = fields.Many2many(
        "res.users",
        string="User Level 4",
        store=True,
        compute="_get_user_level_4",
        relation="approval_request_user_level_4_rel"
    )

    tks_user_activity_ids = fields.Many2many(
        "res.users",
        string="User Activity",
        store=True,
        compute="_get_user_activity",
        relation="tks_im_user_activity_rel"
        )

    tks_stored_user_activity_ids = fields.Many2many("res.users", string="Stored User Activity", help="Keeps users even after activity is removed", relation="tks_im_user_activity_rel_1")

    tks_is_data_complete = fields.Boolean(
        string="Is Data Complete",
        default=False,
        store=True,
    )

    tks_user_approver_ids = fields.Many2many("res.users", string="User Approver Level", store=True, compute="_get_user_approver_ids", relation="user_approver_rel")

    tks_approval_is_submited = fields.Boolean(
        string="Is Submitted",
        default=False,
        store=True,
        compute="_compute_tks_approval_is_submited",
    )
    tks_all_level_approved = fields.Boolean(
        string="All Level Approved", default=False
    )
    tks_approved_date = fields.Datetime(string="Approved Date", readonly=True)
    tks_submitted_date = fields.Date(string="Submitted Date", readonly=True)
    tks_im_employee_department = fields.Many2one(
        "hr.department",
        string="Department",
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",  
        store=True,
    )
    tks_im_department_related_id = fields.Many2one(
        "hr.department",
        related="request_owner_id.department_id",
    )
    tks_im_company_group_related_id = fields.Many2one(
        "tks.res.partner.company.group",
        related="tks_im_customer_id.tks_company_group_id",
    )
    tks_im_industry_related_id = fields.Many2one(
        "res.partner.industry",
        related="tks_im_customer_id.industry_id",
    )
    tks_im_mhc_rating_related_id = fields.Selection(
        related="tks_im_customer_id.tks_mhc_rating",
    )
    tks_im_attachment_underlying = fields.Selection(
        string="Have Supporting Docs?",
        selection=[("yes", "Yes"), ("no", "No")],
        default="no",
    )

    tks_first_approve = fields.Boolean(
        string="First Approve",
    )

    tks_last_approve = fields.Boolean(
        string="Last Approve",
    )

    tks_use_approval_level = fields.Boolean(
        string="Use Approval Level",
        related="category_id.tks_use_approver_level",
    )

    request_status = fields.Selection(
        [
            ("new", "To Submit"),
            ("pending", "Ready to Verify"),
            ("reviewed", "Verified"),
            ("ready_approve", "Ready to Approve"),
            ("approved", "Approved"),
            ("refused", "Rejected"),
            ("cancel", "Canceled"),
            ("revised", "Revised"),
        ],
        default="new",
        compute="_compute_request_status",
        store=True,
        index=True,
        tracking=True,
        group_expand=True,
    )

    # FL Basic Fields
    tks_im_fl_special_case_category = fields.Char(string="Special Case Name")
    tks_im_fl_tks_program = fields.Selection(
        string="TKS Program Type",
        selection=[
            ("incentive", "Incentive"),
            ("non_fs", "Non FS"),
            ("no", "Others"),
        ],
    )
    tks_im_fl_type = fields.Selection(string="Type", selection=[("permanent","Permanent"),("tempo","Temporary")], default="permanent")

    # OPL Basic Fields
    tks_im_opl_special_case_category = fields.Char(string="Special Case Name")
    tks_im_opl_ci_type = fields.Selection(
        string="Changing Invoice Type",
        selection=[
            ("cancel_invoice", "Cancel Invoice"),
            ("waive_invoice", "Waive Invoice"),
            ("prorate_invoice", "Prorate Invoice"),
            ("reprint_invoice", "Reprint Invoice"),
            ("revise_invoice", "Revise Invoice"),
            ("change_invoice_delivery", "Change Invoice Delivery"),
            ("invoice_settelement", "Invoice Settlement"),
        ],
    )
    tks_im_opl_ci_type_id = fields.Many2one(
        "tks.im.opl.ci.type",
        string="Changing Invoice Type",
    )
    tks_im_opl_management_consent = fields.Selection(
        string="Management Consent",
        selection=[
            ("risk_compliance", "Risk & Compliance (Dow Jones/SIPP-PN/DTTOT)"),
            ("credit_bureau", "Credit Bureau Collectability 2 or Worse"),
        ],
        default="credit_bureau"
    )
    tks_im_opl_sparekey_type = fields.Selection(
        string="Sparekey Type",
        selection=[
            ("borrow_sparekey", "Borrow Sparekey"),
            ("duplicate_sparekey", "Duplicate Sparekey"),
            ("waive_sparekey", "Waive Sparekey"),
        ],
    )
    tks_im_opl_sparekey_type_id = fields.Many2one(
        "tks.opl.sparekey.type",
        string="Sparekey Type",
        # default=lambda self: self.env['tks.opl.sparekey.type'].browse(1)
    )
    tks_im_opl_waive_category = fields.Selection(
        string="Waive Category",
        selection=[
            ("waive_kyc_document", "Waive KYC Document"),
            ("waive_reimbursement_documents", "Waive Reimbursement Documents"),
            ("waive_insurance_policy", "Waive Insurance Policy"),
            ("no", "None"),
        ],
        default="no",
    )

    # Basic Fields
    tks_im_category = fields.Char(string="Category")
    tks_im_sub_category = fields.Char(string="Sub Category")
    tks_im_changing_clause = fields.Char(string="Changing Clause")
    tks_currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        default=lambda self: self.env.user.company_id.currency_id,
    )

    # Related: FL Basic Fields
    tks_has_tks_im_fl_special_case_category = fields.Selection(
        related="category_id.tks_has_tks_im_fl_special_case_category"
    )
    tks_has_tks_im_fl_type = fields.Selection(
        related="category_id.tks_has_tks_im_fl_type"
    )
    tks_has_tks_im_fl_tks_program = fields.Selection(
        related="category_id.tks_has_tks_im_fl_tks_program"
    )
    # Related: OPL Basic Fields
    tks_has_tks_im_opl_special_case_category = fields.Selection(
        related="category_id.tks_has_tks_im_opl_special_case_category"
    )
    tks_has_tks_im_opl_ci_type = fields.Selection(
        related="category_id.tks_has_tks_im_opl_ci_type"
    )
    tks_has_tks_im_opl_management_consent = fields.Selection(
        related="category_id.tks_has_tks_im_opl_management_consent"
    )
    tks_has_tks_im_opl_sparekey_type = fields.Selection(
        related="category_id.tks_has_tks_im_opl_sparekey_type"
    )
    tks_has_tks_im_opl_waive_category = fields.Selection(
        related="category_id.tks_has_tks_im_opl_waive_category"
    )
    # Related: Basic Fields
    tks_has_tks_im_category = fields.Selection(
        related="category_id.tks_has_tks_im_category"
    )
    tks_has_tks_im_sub_category = fields.Selection(
        related="category_id.tks_has_tks_im_sub_category"
    )
    tks_has_tks_im_changing_clause = fields.Selection(
        related="category_id.tks_has_tks_im_changing_clause"
    )
    tks_has_tks_currency = fields.Selection(related="category_id.tks_has_tks_currency")
    tks_has_tks_im_waive_insurance_policy_fl = fields.Selection(related='category_id.tks_has_tks_im_waive_insurance_policy_fl')

    # New Fields Proposal Option
    tks_im_plate_number_ba_before = fields.Integer(string=_("Before"))
    tks_im_plate_number_ba_after = fields.Integer(string=_("After"))
    tks_im_bpkb_number_before = fields.Integer(string=_("Before"))
    tks_im_bpkb_number_after = fields.Integer(string=_("After"))
    tks_im_type_unit_before = fields.Char(string=_("Before"))
    tks_im_type_unit_after = fields.Char(string=_("After"))
    tks_im_chasis_number_before = fields.Integer(string=_("Before"))
    tks_im_chasis_number_after = fields.Integer(string=_("After"))
    tks_im_engine_number_before = fields.Integer(string=_("Before"))
    tks_im_engine_number_after = fields.Integer(string=_("After"))
    tks_im_os_principal_before = fields.Monetary(
        string=_("Before"),
        currency_field="tks_currency_id",
    )
    tks_im_os_principal_after = fields.Monetary(
        string=_("After"),
        currency_field="tks_currency_id",
    )
    tks_im_estimated_rv_before = fields.Monetary(
        string=_("Before"), currency_field="tks_currency_id"
    )
    tks_im_estimated_rv_after = fields.Monetary(
        string=_("After"), currency_field="tks_currency_id"
    )
    tks_im_pdc_cleraring_date_before = fields.Date(string=_("Before"))
    tks_im_pdc_cleraring_date_after = fields.Date(string=_("After"))
    tks_im_explanation_before = fields.Text(string=_("Before"))
    tks_im_explanation_after = fields.Text(string=_("After"))
    tks_im_risk_and_mitigation_before = fields.Char(string=_("Before"))
    tks_im_risk_and_mitigation_before = fields.Char(string=_("After"))
    tks_im_items_before = fields.Selection(
        string=_("Before"),
        selection=[
            ("lt", "Lease Term"),
            ("lr", "Lease Rent"),
            ("cost", "Cost"),
            ("scheme", "Scheme"),
            ("ut", "Unit Type"),
            ("other", "Other"),
        ],
    )
    tks_im_items_after = fields.Selection(
        string=_("After"),
        selection=[
            ("lt", "Lease Term"),
            ("lr", "Lease Rent"),
            ("cost", "Cost"),
            ("scheme", "Scheme"),
            ("ut", "Unit Type"),
            ("other", "Other"),
        ],
    )
    tks_im_business_consideration_before = fields.Char(string=_("Before"))
    tks_im_business_consideration_after = fields.Char(string=_("After"))
    tks_im_effective_date_before = fields.Date(string=_("Before"))
    tks_im_effective_date_after = fields.Date(string=_("After"))
    tks_im_change_reason_before = fields.Char(string=_("Before"))
    tks_im_change_reason_after = fields.Char(string=_("After"))
    tks_im_transaction_before = fields.Selection(
        string=_("Before"),
        selection=[
            ("nt", "New Transaction"),
            ("lt", "Lease Transaction"),
            ("pe", "Permanent Excanges"),
            ("ca", "Changing Application"),
            ("ta", "Transfer Aggrement"),
            ("other", "Other"),
        ],
    )
    tks_im_transaction_after = fields.Selection(
        string=_("After"),
        selection=[
            ("nt", "New Transaction"),
            ("lt", "Lease Transaction"),
            ("pe", "Permanent Excanges"),
            ("ca", "Changing Application"),
            ("ta", "Transfer Aggrement"),
            ("other", "Other"),
        ],
    )
    tks_im_client_grade_before = fields.Char(string=_("Before"))
    tks_im_client_grade_after = fields.Char(string=_("After"))
    tks_im_spread_change_before = fields.Char(string=_("Before"))
    tks_im_spread_change_after = fields.Char(string=_("After"))
    # tks_im_list_of_signers_changes_ids = fields.Many2many(
    #     "tks.list.of.signer.changes", string=_("List of Signer's Changes")
    # )
    tks_im_location_before = fields.Char(string=_("Before"))
    tks_im_location_after = fields.Char(string=_("After"))
    tks_im_vehicle_before = fields.Char(string=_("Before"))
    tks_im_vehicle_after = fields.Char(string=_("After"))
    tks_im_year_before = fields.Integer(string="Before")
    tks_im_year_after = fields.Integer(string="After")
    tks_im_lease_rent_before = fields.Monetary(
        string=_("Before"), currency_field="tks_currency_id"
    )
    tks_im_lease_rent_after = fields.Monetary(
        string=_("After"), currency_field="tks_currency_id"
    )
    tks_im_lease_term_before = fields.Integer(string=_("Before"))
    tks_im_lease_term_after = fields.Integer(string=_("After"))
    tks_im_net_spread_before = fields.Float(string=_("Before"))
    tks_im_net_spread_after = fields.Float(string=_("After"))
    tks_im_irr_before = fields.Float(string=_("Before"))
    tks_im_irr_after = fields.Float(string=_("After"))
    tks_im_change_effective_date_before = fields.Date(string=_("Before"))
    tks_im_change_effective_date_after = fields.Date(string=_("After"))
    tks_im_items_changed_before = fields.Selection(
        string=_("Before"),
        selection=[
            ("lt", "Lease Term"),
            ("lr", "Lease Rent"),
            ("cost", "Cost"),
            ("scheme", "Scheme"),
            ("ut", "Unit Type"),
            ("other", "Other"),
        ],
    )
    tks_im_customer_name_before_id = fields.Many2one("res.partner", string=_("Before"))
    tks_im_customer_name_after_id = fields.Many2one("res.partner", string=_("After"))
    # tks_im_customer_rating_before = fields.
    tks_im_company_group_before_id = fields.Many2one(
        "tks.res.partner.company.group",
        string=_("Before"),
        related="tks_im_customer_name_before_id.tks_company_group_id",
    )
    tks_im_company_group_after_id = fields.Many2one(
        "tks.res.partner.company.group",
        string=_("After"),
        related="tks_im_customer_name_after_id.tks_company_group_id",
    )
    tks_im_lease_principal_before = fields.Monetary(
        string=_("Before"),
        currency_field="tks_currency_id",
    )
    tks_im_lease_principal_after = fields.Monetary(
        string=_("After"),
        currency_field="tks_currency_id",
    )
    tks_im_invoice_no_before = fields.Integer(string=_("Before"))
    tks_im_invoice_no_after = fields.Integer(string=_("After"))
    tks_im_lease_period_before_start = fields.Date(string=_("Before"))
    tks_im_lease_period_before_end = fields.Date(string=_("Before"))
    tks_im_lease_period_after_start = fields.Date(string=_("After"))
    tks_im_lease_period_after_end = fields.Date(string=_("After"))

    # Related fields for general information
    tks_has_tks_im_customer = fields.Selection(
        string="Customer", related="category_id.tks_has_tks_im_customer"
    )
    tks_has_tks_im_customer_status = fields.Selection(
        string="Customer Status", related="category_id.tks_has_tks_im_customer_status"
    )
    tks_has_tks_im_customer_since = fields.Selection(
        string="Customer Since", related="category_id.tks_has_tks_im_customer_since"
    )
    tks_has_tks_im_contract_no = fields.Selection(
        string="Contract No.", related="category_id.tks_has_tks_im_contract_no"
    )
    tks_has_tks_im_current_os_balance = fields.Selection(
        string="Current O/S Balance",
        related="category_id.tks_has_tks_im_current_os_balance",
    )
    tks_has_tks_im_mhc_rating = fields.Selection(
        string="MHC Rating",
        related="category_id.tks_has_tks_im_mhc_rating",
    )
    tks_has_tks_im_company_group = fields.Selection(
        string="Company Group",
        related="category_id.tks_has_tks_im_company_group",
    )
    tks_has_tks_im_industry = fields.Selection(
        string="Line of Business",
        related="category_id.tks_has_tks_im_industry",
    )

    tks_has_tks_im_remaining_installment = fields.Selection(
        string="Remaining Installment",
        related="category_id.tks_has_tks_im_remaining_installment",
    )

    tks_has_tks_im_trans_type_fl = fields.Selection(
        string="Transaction Type (FL)",
        related="category_id.tks_has_tks_im_trans_type_fl",
    )

    tks_has_tks_im_trans_type_opl = fields.Selection(
        string="Transaction Type (OPL)",
        related="category_id.tks_has_tks_im_trans_type_opl",
    )

    tks_has_tks_im_coverage_type = fields.Selection(
        string="Coverage Type",
        related="category_id.tks_has_tks_im_coverage_type",
    )

    tks_has_tks_im_total_holding_unit = fields.Selection(
        string="Total Holding Unit (THU)",
        related="category_id.tks_has_tks_im_total_holding_unit",
    )

    tks_has_tks_im_unit_in_takari = fields.Selection(
        string="Unit in Takari (UIT)",
        related="category_id.tks_has_tks_im_unit_in_takari",
    )

    tks_has_tks_im_car_description = fields.Selection(
        string="Car Description",
        related="category_id.tks_has_tks_im_car_description",
    )

    tks_has_tks_im_location = fields.Selection(
        string="Location",
        related="category_id.tks_has_tks_im_location",
    )

    tks_has_tks_im_no_palte = fields.Selection(
        string="Plate No.",
        related="category_id.tks_has_tks_im_no_palte",
    )

    tks_has_tks_im_remaining_term = fields.Selection(
        string="Remaining Term",
        related="category_id.tks_has_tks_im_remaining_term",
    )

    tks_has_tks_im_total_term = fields.Selection(
        string="Total Term",
        related="category_id.tks_has_tks_im_total_term",
    )

    tks_has_tks_im_policy = fields.Selection(
        string="Policy",
        related="category_id.tks_has_tks_im_policy",
    )

    # New fields general information
    tks_im_customer_id = fields.Many2one(
        "res.partner",
        domain=[('tks_company_type','!=',False),("is_company", "=", True), ('tks_is_customer','=',True)],
        string=_("Customer"),
    )
    tks_im_customer_status = fields.Selection(
        string=_("Customer Status"),
        selection=[
            ("new", "New"),
            ("existing", "Existing"),
        ], default='new',
    )
    tks_im_customer_since = fields.Date(string=_("Customer Since"))
    tks_im_contract_no = fields.Char(string=_("Contract No."))
    tks_im_current_os_balance = fields.Monetary(
        string=_("Current O/S Balance"),
        currency_field="tks_currency_id",
    )
    tks_im_mhc_rating = fields.Selection(
        string=_("MHC Rating"),
        selection=[
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
            ("6_1", "6-1"),
            ("6_2", "6-2"),
            ("7_1", "7-1"),
            ("7_2", "7-2"),
            ("8_1", "8-1"),
            ("8_2", "8-2"),
            ("8_3", "8-3"),
            ("9", "9"),
            ("10", "10"),
        ],
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",  
        store=True,
    )

    tks_im_company_group_id = fields.Many2one(
        "tks.res.partner.company.group",
        string=_("Company Group"),
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )

    tks_im_industry_id = fields.Many2one(
        "res.partner.industry",
        string=_("Line of Business"),
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )

    tks_im_remaining_installment = fields.Monetary(
        string=_("Remaining Installment"),
        currency_field="tks_currency_id",
    )

    tks_im_trans_type_fl_id = fields.Many2one(
        comodel_name="tks.trans.type.fl",
        string="Transaction Type",
        default=lambda self: self.env["tks.trans.type.fl"].search([('name','=','Direct Lease')]),
    )

    tks_im_trans_type_opl = fields.Selection(
        string="Transaction Type",
        selection=[
            ("opl", "OPL"),
            ("oplp", "OPL+"),
            ("opl_lp", "OPL + LP"),
            ("opl_slb", "OPL + SLB"),
            ("cop", "COP"),
        ], default="opl",
    )

    tks_im_coverage_type = fields.Selection(
        string=_("Coverage Type"),
        selection=[
            ("full_coverage", "Full Coverage"),
            ("non_coverage", "Non Coverage"),
            ("partial_cocerage", "Partial Coverage"),
        ],
        default="full_coverage"
    )

    tks_im_total_holding_unit = fields.Integer(string="Total Holding Unit(s)")
    tks_im_unit_in_takari = fields.Integer(string="Unit(s) in Takari")
    tks_im_car_description = fields.Char(string="Car Description")

    tks_im_location = fields.Char(string="Location")

    tks_im_no_plate = fields.Char(string="Plate No.")
    tks_im_remaining_term = fields.Integer(
        string=_("Remaining Term"),
    )
    tks_im_total_term = fields.Integer(
        string=_("Total Term"),
    )
    tks_im_policy = fields.Html(string="Description")

    # related fields for details

    tks_has_tks_im_bpkb_release_etc = fields.Selection(
        string="BPKB Release for Early Termination Condition",
        related="category_id.tks_has_tks_im_bpkb_release_etc",
    )

    tks_has_tks_im_temporary_changing_collateral_bpkb = fields.Selection(
        string="Temporary Changing Collateral BPKB",
        related="category_id.tks_has_tks_im_temporary_changing_collateral_bpkb",
    )
    tks_has_tks_im_contract_adjustment = fields.Selection(
        string="Contract Adjustment",
        related="category_id.tks_has_tks_im_contract_adjustment",
    )
    tks_has_tks_im_reprint_contract = fields.Selection(
        string="Reprint Contract", related="category_id.tks_has_tks_im_reprint_contract"
    )
    tks_has_tks_im_postpone_kyc_document_fl = fields.Selection(
        string="Postpone KYC Document",
        related="category_id.tks_has_tks_im_postpone_kyc_document_fl",
    )
    tks_has_tks_im_waive_kyc_document_fl = fields.Selection(
        string="Waive KYC Document",
        related="category_id.tks_has_tks_im_waive_kyc_document_fl",
    )
    tks_has_tks_im_hold_pdc_process = fields.Selection(
        string="Hold PDC Process", related="category_id.tks_has_tks_im_hold_pdc_process"
    )
    tks_has_tks_im_waive_overdue_penalty = fields.Selection(
        string="Waive Overdue Penalty",
        related="category_id.tks_has_tks_im_waive_overdue_penalty",
    )
    tks_has_tks_im_special_case_fl = fields.Selection(
        string="Special Case", related="category_id.tks_has_tks_im_special_case_fl"
    )
    tks_has_tks_im_tks_program = fields.Selection(
        string="TKS Program", related="category_id.tks_has_tks_im_tks_program"
    )

    tks_has_tks_im_waive_duty_stamp_fee_for_customer_fl = fields.Selection(
        string="Waive Duty Stamp Fee For Customer",
        related="category_id.tks_has_tks_im_waive_duty_stamp_fee_for_customer_fl",
    )

    # Operation Lease
    tks_has_tks_im_transfer_agreement = fields.Selection(
        string="Transfer Agreement",
        related="category_id.tks_has_tks_im_transfer_agreement",
    )
    tks_has_tks_im_below_min_spread_transaction = fields.Selection(
        string="Below Minimum Spread Transaction",
        related="category_id.tks_has_tks_im_below_min_spread_transaction",
    )
    tks_has_tks_im_changing_application = fields.Selection(
        string="Changing Application",
        related="category_id.tks_has_tks_im_changing_application",
    )
    tks_has_tks_im_early_purchase = fields.Selection(
        string="Early Purchase", related="category_id.tks_has_tks_im_early_purchase"
    )
    tks_has_tks_im_permanent_exchange = fields.Selection(
        string="Permanent Exchange",
        related="category_id.tks_has_tks_im_permanent_exchange",
    )
    tks_has_tks_im_borrow_bpkb = fields.Selection(
        string="Borrow BPKB", related="category_id.tks_has_tks_im_borrow_bpkb"
    )
    tks_has_tks_im_changing_plate_number = fields.Selection(
        string="Changing Plate Number",
        related="category_id.tks_has_tks_im_changing_plate_number",
    )
    tks_has_tks_im_early_vehicle_disposal = fields.Selection(
        string="Early Vehicle Disposal",
        related="category_id.tks_has_tks_im_early_vehicle_disposal",
    )
    tks_has_tks_im_early_release_the_bpkb_to_user = fields.Selection(
        string="Early Release The BPKB to User",
        related="category_id.tks_has_tks_im_early_release_the_bpkb_to_user",
    )
    tks_has_tks_im_extend_booking_unit = fields.Selection(
        string="Extend Booking Unit",
        related="category_id.tks_has_tks_im_extend_booking_unit",
    )
    tks_has_tks_im_postpone_withdrawn_unit = fields.Selection(
        string="Postpone Withdrawn Unit",
        related="category_id.tks_has_tks_im_postpone_withdrawn_unit",
    )
    tks_has_tks_im_unit_relocation = fields.Selection(
        string="Unit Relocation", related="category_id.tks_has_tks_im_unit_relocation"
    )

    tks_has_tks_im_sparekey = fields.Selection(
        string="Sparekey", related="category_id.tks_has_tks_im_sparekey"
    )

    tks_has_tks_im_total_loss = fields.Selection(
        string="Total Loss", related="category_id.tks_has_tks_im_total_loss"
    )

    tks_has_tks_im_management_consent = fields.Selection(
        string="Management Consent",
        related="category_id.tks_has_tks_im_management_consent",
    )

    tks_has_tks_im_changing_clausal = fields.Selection(
        string="Changing Clausal", related="category_id.tks_has_tks_im_changing_clausal"
    )

    tks_has_tks_im_changing_signer = fields.Selection(
        string="Changing The Signer",
        related="category_id.tks_has_tks_im_changing_signer",
    )

    tks_has_tks_im_using_contract_template_by_customer = fields.Selection(
        string="Using Contract Template By Customer",
        related="category_id.tks_has_tks_im_using_contract_template_by_customer",
    )

    tks_has_tks_im_reprint_master_agreement = fields.Selection(
        string="Reprint Master Agreement / Addendum",
        related="category_id.tks_has_tks_im_reprint_master_agreement",
    )

    tks_has_tks_im_waive_master_agreement = fields.Selection(
        string="Waive Master Agreement / Addendum / PPJB",
        related="category_id.tks_has_tks_im_waive_master_agreement",
    )

    tks_has_tks_im_waive_insurance_policy = fields.Selection(
        string="Waive Insurance Policy",
        related="category_id.tks_has_tks_im_waive_insurance_policy",
    )

    tks_has_tks_im_waive_kyc_document_opl = fields.Selection(
        string="Waive KYC Document",
        related="category_id.tks_has_tks_im_waive_kyc_document_opl",
    )

    tks_has_tks_im_postpone_kyc_document_opl = fields.Selection(
        string="Postpone KYC Document",
        related="category_id.tks_has_tks_im_postpone_kyc_document_opl",
    )

    tks_has_tks_im_delivery_before_sign_contract = fields.Selection(
        string="Delivery Before Sign Contract",
        related="category_id.tks_has_tks_im_delivery_before_sign_contract",
    )

    tks_has_tks_im_dispatcher_request = fields.Selection(
        string="Dispatcher Request",
        related="category_id.tks_has_tks_im_dispatcher_request",
    )

    tks_has_tks_im_safekeep_running_contract_vehicle = fields.Selection(
        string="Dispatcher Request",
        related="category_id.tks_has_tks_im_safekeep_running_contract_vehicle",
    )

    tks_has_tks_im_safety_driving_training = fields.Selection(
        string="Safety Driving Training",
        related="category_id.tks_has_tks_im_safety_driving_training",
    )

    tks_has_tks_im_changing_invoice = fields.Selection(
        string="Changing Invoice", related="category_id.tks_has_tks_im_changing_invoice"
    )

    tks_has_tks_im_changing_finance_grade = fields.Selection(
        string="Changing Finance Grade",
        related="category_id.tks_has_tks_im_changing_finance_grade",
    )

    tks_has_tks_im_waive_duty_stamp_fee_for_customer = fields.Selection(
        string="Waive Duty Stamp Fee For Customer",
        related="category_id.tks_has_tks_im_waive_duty_stamp_fee_for_customer",
    )

    tks_has_tks_im_overpayment_refund_to_customer = fields.Selection(
        string="Overpayment Refund to Customer",
        related="category_id.tks_has_tks_im_overpayment_refund_to_customer",
    )

    tks_has_tks_im_waive_reimbursement_documents = fields.Selection(
        string="Waive Reimbursement Documents",
        related="category_id.tks_has_tks_im_waive_reimbursement_documents",
    )

    tks_has_tks_im_suspend_warning_letter = fields.Selection(
        string="Suspend Warning Letter",
        related="category_id.tks_has_tks_im_suspend_warning_letter",
    )

    tks_has_tks_im_waive_late_payment_penalty = fields.Selection(
        string="Waive Late Payment Penalty",
        related="category_id.tks_has_tks_im_waive_late_payment_penalty",
    )

    tks_has_tks_im_waive_own_risk = fields.Selection(
        string="Waive Own Risk", related="category_id.tks_has_tks_im_waive_own_risk"
    )

    tks_has_tks_im_special_case_opl = fields.Selection(
        string="Special Case", related="category_id.tks_has_tks_im_special_case_opl"
    )
    is_approver_editor = fields.Boolean("Is Approver Editor", compute='_compute_is_approver_editor')

    tks_category_name = fields.Char(
        string="Category",
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )
    tks_user_name = fields.Char(
        string="Prepared By",
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )

    tks_currency_name = fields.Char(
        string="Currency",
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )

    tks_customer_name = fields.Char(
        string="Customer",
        compute="_compute_fields_internal_memo",
        inverse="_inverse_internal_memo_fields",
        store=True,
    )

    # new field due date from ticket_41362, the cdp due date uses onchange
    cdp_show_due_date = fields.Boolean("Show Due Date", compute="get_approval_category_to_show")
    cdp_due_date = fields.Date("Due Date", compute="onchange_dates",readonly=True)
    # Task: 41379
    @api.depends(
        "request_status",
        "tks_im_customer_id",
        "request_owner_id.employee_id",
    )
    def _compute_fields_internal_memo(self):
        for rec in self:
            # Update otomatis hanya saat status 'new'
            if rec.request_status == 'new' or rec.tks_im_customer_id:
                rec.tks_im_company_group_id = rec.tks_im_customer_id.tks_company_group_id
                rec.tks_im_industry_id = rec.tks_im_customer_id.industry_id
                rec.tks_im_mhc_rating = rec.tks_im_customer_id.tks_mhc_rating
                rec.tks_im_employee_department = rec.request_owner_id.employee_id.department_id

                if rec.tks_category_name != rec.category_id.name:
                    rec.tks_category_name = rec.category_id.name
                else:
                    rec.tks_category_name = ""

                if rec.tks_user_name != rec.request_owner_id.name:
                    rec.tks_user_name = rec.request_owner_id.name
                else:
                    rec.tks_user_name = False

                if rec.tks_currency_name != rec.tks_currency_id.name:
                    rec.tks_currency_name = rec.tks_currency_id.name
                else:
                    rec.tks_currency_name = False

                if rec.tks_customer_name != rec.tks_im_customer_id.name:
                    rec.tks_customer_name = rec.tks_im_customer_id.name
                else:
                    rec.tks_customer_name = False

    def _inverse_internal_memo_fields(self):
        """
        Pastikan ketika request_status != 'new', nilai yang ada tidak hilang
        dan tetap tersimpan di database.
        """
        for rec in self:
            if rec.request_status != 'new':
                rec.tks_im_company_group_id = rec.tks_im_company_group_id
                rec.tks_im_industry_id = rec.tks_im_industry_id
                rec.tks_im_mhc_rating = rec.tks_im_mhc_rating
                rec.tks_im_employee_department = rec.tks_im_employee_department
                rec.tks_category_name = rec.tks_category_name
                rec.tks_user_name = rec.tks_user_name
                rec.tks_currency_name = rec.tks_currency_name
                rec.tks_customer_name = rec.tks_customer_name

    def action_refuse(self, approver=None):
        res = super(ApprovalRequest, self).action_refuse(approver)

        # Update tks_approved_date dengan tanggal sekarang
        self.write({
            'tks_approved_date': fields.Datetime.now(),
        })
        return res


    # Constrains
    # override
    @api.constrains('approver_ids')
    def _check_approver_ids(self):
        for request in self:
            seen_combinations = set()

            for approver in request.approver_ids:
                user_id = approver.user_id.id  # Ambil user_id
                tks_approvers_level = approver.tks_approvers_level  # Ambil tks_approvers_level
                combination = (user_id, tks_approvers_level)
                # Jika kombinasi sudah ada sebelumnya, artinya duplikasi ditemukan
                # if combination in seen_combinations:
                #     raise UserError(_("You cannot assign the same approver and level approver multiple times on the same request."))
                # Jika tidak, tambahkan kombinasi ke set
                seen_combinations.add(combination)

    # Compute
    def _compute_approver_reviewer_ids(self):
        for approval in self:
            if approval.approver_ids:
                level_1 = approval.approver_ids.filtered(lambda x: x.tks_approvers_level == "level_1").mapped('id')
                approval.tks_approver_reviewer_ids = [(6, 0, level_1)]

    @api.depends_context("uid")
    @api.depends("approver_ids.status")
    def _compute_user_status(self):
        for approval in self:
            approval.user_status = "new"
            if approval.tks_use_approval_level:
                approver = approval.approver_ids.filtered(
                    lambda x: x.tks_approvers_level == "level_4"
                )
                if approver:
                    for approve in approver:
                        approval.user_status = approve.status
            else:
                return super(ApprovalRequest, self)._compute_user_status()

    # Field for Domain Internal Memo to Review
    @api.depends('approver_ids','approver_ids.status')
    def _compute_user_approve(self):
        for approval in self:
            approval.tks_user_approve_ids = approval.approver_ids.filtered(lambda x: x.status == 'pending').mapped('user_id')

    @api.depends_context("uid")
    @api.depends('approver_ids.status', 'approver_ids')
    def _get_approver_state(self):
        current_user_id = self._context.get('uid')
        for record in self:
            record.tks_already_approve = record.tks_already_approve
            record.tks_in_level = record.tks_in_level

            current_level = record.approver_ids.filtered(lambda x: x.status == 'pending').mapped("tks_approvers_level")
            approvers = record.approver_ids.filtered(lambda x: x.user_id.id == current_user_id and x.tks_approvers_level in current_level)
            last_level = record.approver_ids.filtered(lambda x: x.tks_level_sequence == 4 and x.tks_approvers_level == "level_4")

            if last_level and all(last.status == "approved" for last in last_level):
                record.tks_in_level = True
                record.tks_already_approve = True

            if not approvers:
                continue

            # approver = approver[0]
            for approver in approvers.filtered(lambda x: x.status != "approved"):
                prev_levels = record.approver_ids.filtered(lambda x: x.tks_level_sequence < approver.tks_level_sequence)

                if approver.status == 'approved':
                    record.tks_already_approve = True

                if not prev_levels and approver.user_id.id == current_user_id:
                    record.tks_in_level = True

                if prev_levels and all(prev.status == "approved" for prev in prev_levels):
                    record.tks_in_level = True

    def _compute_is_approver_editor(self):
        for record in self:
            user = self.env.user
            val_set = self.env['res.users'].search([('id', '=', user.id)])
            record.is_approver_editor = val_set.is_approver_editor

    @api.depends('category_id', 'request_owner_id')
    def _compute_approver_ids(self):
        for request in self:
            if request.tks_use_approval_level:
                users_to_approver = {}
                for approver in request.approver_ids:
                    users_to_approver[approver.user_id.id] = approver

                users_to_category_approver = {}
                for approver in request.category_id.approver_ids:
                    if approver.user_id.id not in users_to_category_approver:
                        users_to_category_approver[approver.user_id.id] = []
                    users_to_category_approver[approver.user_id.id].append(approver)

                approver_id_vals = []
                if request.category_id.manager_approval:
                    employee = self.env['hr.employee'].search([('user_id', '=', request.request_owner_id.id)], limit=1)
                    if employee.parent_id.user_id:
                        manager_user_id = employee.parent_id.user_id.id
                        manager_required = request.category_id.manager_approval == 'required'
                        self._create_or_update_approver(manager_user_id, users_to_approver, approver_id_vals, manager_required, 9)
                        if manager_user_id in users_to_category_approver.keys():
                            users_to_category_approver.pop(manager_user_id)

                for user_id, approver_list in users_to_category_approver.items():
                    for approver in approver_list:
                        self._create_or_update_approver(user_id, users_to_approver, approver_id_vals,
                                                        approver.required, approver.sequence, approver.tks_approvers_level)

                for current_approver in users_to_approver.values():
                    self._update_approver_vals(approver_id_vals, current_approver, False, 1000)

                request.update({'approver_ids': approver_id_vals})
            else:
                return super(ApprovalRequest, self)._compute_approver_ids()

    @api.depends('approver_ids.status', 'approver_ids.required')
    def _compute_request_status(self):
        for request in self:
            if request.category_id.tks_use_approver_level:
                status_lst = request.mapped('approver_ids.status')
                required_approved = all(a.status == 'approved' for a in request.approver_ids.filtered('required'))
                # minimal_approver = request.approval_minimum if len(status_lst) >= request.approval_minimum else len(status_lst)

                if status_lst:
                    if status_lst.count('cancel'):
                        status = 'cancel'
                    elif status_lst.count('refused'):
                        status = 'refused'
                    elif status_lst.count('revised') :
                        status = 'revised'
                    elif all(approver.status == 'approved' for approver in request.approver_ids):
                        status = 'approved'
                    elif all(level.status == 'approved' for level in request.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_2')) and request.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_2'):
                        status = 'ready_approve'
                    elif all(level.status == 'approved' for level in request.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_1')) and request.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_1'):
                        status = 'reviewed'
                    elif status_lst.count('new') :
                        status = 'new'
                    else:
                        status = 'pending'
                else:
                    status = 'new'
                request.request_status = status

                self.filtered_domain([('request_status', 'in', ['refused', 'cancel'])])._cancel_activities()
            else:
                super(ApprovalRequest, self)._compute_request_status()

    @api.depends("request_status")
    def _compute_tks_approval_is_submited(self):
        for approval in self:
            approval.tks_approval_is_submited = False
            if approval.request_status == "pending":
                approval.tks_approval_is_submited = True

    @api.depends("approver_ids","approver_ids.user_id","approver_ids.tks_approvers_level")
    def _get_user_level_1(self):
        for approval in self:
            approval.tks_user_level_1 = False
            user_level_1 = approval.approver_ids.filtered(
                lambda x: x.tks_approvers_level == "level_1"
            ).mapped("user_id").ids
            if user_level_1:
                approval.tks_user_level_1 = [(6, 0, user_level_1)]

    @api.depends("approver_ids","approver_ids.user_id","approver_ids.tks_approvers_level")
    def _get_user_level_2(self):
        for approval in self:
            approval.tks_user_level_2 = False
            user_level_2 = approval.approver_ids.filtered(
                lambda x: x.tks_approvers_level == "level_2"
            ).mapped("user_id").ids
            if user_level_2:
                approval.tks_user_level_2 = [(6, 0, user_level_2)]

    @api.depends("approver_ids","approver_ids.user_id","approver_ids.tks_approvers_level")
    def _get_user_level_3(self):
        for approval in self:
            approval.tks_user_level_3 = False
            user_level_3 = approval.approver_ids.filtered(
                lambda x: x.tks_approvers_level == "level_3"
            ).mapped("user_id").ids
            if user_level_3:
                approval.tks_user_level_3 = [(6, 0, user_level_3)]

    @api.depends("approver_ids","approver_ids.user_id","approver_ids.tks_approvers_level")
    def _get_user_level_4(self):
        for approval in self:
            approval.tks_user_level_4 = False
            user_level_4 = approval.approver_ids.filtered(
                lambda x: x.tks_approvers_level == "level_4"
            ).mapped("user_id").ids
            if user_level_4:
                approval.tks_user_level_4 = [(6, 0, user_level_4)]

    @api.depends(
        "approver_ids",
        "approver_ids.user_id",
        "activity_ids",
        "activity_ids.user_id",
        "message_follower_ids",
    )
    def _get_user_activity(self):
        for approval in self:
            approver_user = approval.approver_ids.mapped("user_id").ids
            approval.tks_user_activity_ids = [(6, 0, approver_user)]
            active_users = (
                approval.activity_ids.filtered(
                    lambda x: x.user_id
                    and x.user_id not in approval.approver_ids.mapped("user_id")
                )
                .mapped("user_id")
                .ids
            )
            stored_users = set(approval.tks_stored_user_activity_ids.ids)

            stored_users.update(active_users)

            followers_partner = approval.message_follower_ids.mapped("partner_id").ids
            followers_users = self.env["res.users"].search(
                [("partner_id", "in", followers_partner)]
            )
            if followers_users:
                stored_users.update(
                    followers_users.filtered(
                        lambda x: x.id != approval.request_owner_id.id
                    ).ids
                )
            approval.tks_stored_user_activity_ids = [(6, 0, list(stored_users))]

    @api.depends("approver_ids","approver_ids.user_id","approver_ids.tks_approvers_level")
    def _get_user_approver_ids(self):
        for approval in self:
            approval.tks_user_approver_ids = False
            user_approver_ids = approval.approver_ids.mapped("user_id").ids
            if user_approver_ids:
                approval.tks_user_approver_ids = [(6, 0, user_approver_ids)]

    # specific cancel activity
    def _cancel_activities_specific(self, user_old):
        approval_activity = self.env.ref('approvals.mail_activity_data_approval')
        activities = self.activity_ids.filtered(lambda a: a.activity_type_id == approval_activity and a.user_id == user_old)

        activities.unlink()

    # CRUD
    @api.model
    def _create_or_update_approver(self, user_id ,users_to_approver, approver_id_vals, required, sequence, level=None):
        if user_id not in users_to_approver.keys():
            approver_id_vals.append(Command.create({
                'user_id': user_id,
                'status': 'new',
                'tks_approvers_level': level,
                'required': required,
                'sequence': sequence,
            }))
        else:
            current_approver = users_to_approver.pop(user_id)
            self._update_approver_vals(approver_id_vals, current_approver, required, sequence)

    def write(self, vals):
        res = super(ApprovalRequest, self.sudo()).write(vals)
        for request in self:
            if 'approver_ids' in vals:
                all_level = ['level_1','level_2','level_3','level_4']
                approvers = request.approver_ids.mapped('tks_approvers_level')
                approvers = list(set(approvers))
                if False not in approvers:
                    approvers.sort()

                if all_level == approvers:
                    continue
                else:
                    raise ValidationError("Minimum approvers level is not met. Please add approvers level")
        return res

    def unlink(self):
        if not self.env.user.has_group('tks_specific.tks_create_internal_memo'):
            raise ValidationError("You don't have access to delete This Record")
        return super(ApprovalRequest, self).unlink()

    def _update_next_approvers(self, new_status, approver, only_next_approver, cancel_activities=False):
        """
        Update the next approvers after an approval/refusal.

        :param new_status: The new status of the approvers.
        :param approver: The approver which has been approved/refused.
        :param only_next_approver: If True, only the next approver will be updated.
        :param cancel_activities: If True, all activities will be canceled.
        """
        # Get all the approvers which have to be updated
        if self.tks_use_approval_level:
            approvers_updated = self.env['approval.approver']
            for approval in self.filtered('tks_use_approval_level'):
                current_approver = approver
                # Get the approvers which have to be updated
                approvers_to_update = approval.approver_ids.filtered(
                    lambda a: a.status not in ['approved', 'refused'] and
                    (a.tks_level_sequence > current_approver[0].tks_level_sequence or
                    (a.tks_level_sequence == current_approver[0].tks_level_sequence and a.id > current_approver[0].id)) and a.tks_approvers_level != current_approver[0].tks_approvers_level
                )
                # If only the next approver has to be updated, take the first one
                level_order = ['level_1', 'level_2', 'level_3', 'level_4']

                current_level_index = level_order.index(current_approver[0].tks_approvers_level)

                # Filter hanya untuk level berikutnya
                approvers_to_update = approvers_to_update.filtered(
                    lambda x: level_order.index(x.tks_approvers_level) == current_level_index + 1
                )

                if only_next_approver and approvers_to_update:
                    # approvers_to_update = approvers_to_update.filtered(lambda x: x.tks_approvers_level == current_approver.tks_approvers_level)
                    approvers_to_update = approvers_to_update.filtered(
                        lambda x: level_order.index(x.tks_approvers_level) == current_level_index + 1
                    )
                # Add the approvers to the list of updated approvers
                approvers_updated = approvers_to_update

            last_current_level = self.approver_ids.filtered(lambda x: x.tks_approvers_level == current_approver[0].tks_approvers_level)
            # Update the status of the approvers
            if all(approver.status == 'approved' for approver in last_current_level):
                approvers_updated.sudo().write({'status': new_status})

            approvers_activity = approvers_updated.filtered(lambda x: not x.tks_same_user_level)
            # If the new status is 'pending', create an activity
            if new_status == 'pending' and all(approver.status == 'approved' for approver in last_current_level):
                if approvers_activity:
                    approvers_activity._create_activity()
                else:
                    approvers_updated._create_activity()

            # If the activities have to be canceled, cancel them
            if cancel_activities:
                approvers_updated.request_id._cancel_activities()
        else:
            return super(ApprovalRequest, self)._update_next_approvers(new_status, approver, only_next_approver, cancel_activities)

    def action_confirm(self):
        risk_mitigation_fields = [
            self.tks_im_2_risk_mitigation_ids,
            self.tks_im_4_risk_mitigation_ids,
            self.tks_im_7_risk_mitigation_ids,
            self.tks_im_8_risk_mitigation_ids,
            self.tks_im_9_risk_mitigation_ids,
            self.tks_opl_borrow_bpkb_line_ids,
            self.tks_plate_number_risk_mitigation_ids,
            self.tks_opl_release_to_user_risk_mitigation_ids,
            self.tks_opl_extend_booking_unit_risk_mitigation_ids,
            self.tks_opl_postpone_withdrawn_unit_line_ids,
            self.tks_safekeep_running_contract_vehicle_risk_mitigation_ids,
            self.tks_opl_sparekey_ids,
            self.tks_opl_total_loss_ids,
            self.tks_opl_changing_signer_risk_mitigation_line_ids,
            self.tks_opl_reprint_agreement_bpr_risk_mitigation_line_ids,
            self.tks_im_31_risk_mitigation_waive_aggrement_ids,
            self.tks_im_35_delivery_before_sign_contract_ids,
            self.tks_im_36_dispatcher_request_risk_mitigation_ids,
            self.tks_im_38_change_invoice_delivery_risk_mitigation_ids,
            self.tks_im_39_changing_client_grade_risk_mitigation_ids,
            self.tks_im_41_overpayment_refund_customer_risk_mitigation_ids,
            self.tks_im_43_suspend_warning_letter_ids,
            self.tks_im_46_special_case_risk_mitigation_ids,
        ]
        business_fields = [
            self.tks_im_9_bussiness_benefit_ids,
            self.tks_im_11_business_benefit_ids,
            self.tks_im_40_waive_duty_stamp_fee_for_customer_ids,
            self.tks_im_48_waive_duty_stamp_fee_for_customer_ids,
            self.tks_im_12_business_benefit_ids,
            self.tks_im_13_business_benefit_ids,
            self.tks_im_14_business_benefit_ids,
            self.tks_opl_permanent_exchange_bb_ids,
            self.tks_opl_early_vehicle_business_benefit_ids,
            self.tks_im_36_dispatcher_request_business_benefit_ids,
            self.tks_im_37_safety_driving_training_ids,
            self.tks_im_38_change_invoice_delivery_business_benefit_ids,
            self.tks_im_46_special_case_business_benefit_ids,
        ]
        bb_item = [
            any(not line.item or not line.remarks for line in field.filtered(lambda x: x))
            for field in business_fields if field
        ]
        rr_item = [
            any(not line.risk_mitigation or not line.remarks for line in field.filtered(lambda x: x))
            for field in risk_mitigation_fields if field
        ]

        risk_mitigation_required = [
            self.tks_has_tks_im_temporary_changing_collateral_bpkb != 'no',
            self.tks_has_tks_im_reprint_contract != 'no',
            self.tks_has_tks_im_hold_pdc_process != 'no',
            self.tks_has_tks_im_waive_overdue_penalty != 'no',
            self.tks_has_tks_im_special_case_fl != 'no',
            self.tks_has_tks_im_borrow_bpkb != 'no',
            self.tks_has_tks_im_changing_plate_number != 'no',
            self.tks_has_tks_im_extend_booking_unit != 'no',
            self.tks_has_tks_im_postpone_withdrawn_unit != 'no',
            self.tks_has_tks_im_safekeep_running_contract_vehicle != 'no',
            self.tks_has_tks_im_sparekey != 'no',
            self.tks_has_tks_im_total_loss != 'no',
            self.tks_has_tks_im_changing_signer != 'no',
            self.tks_has_tks_im_using_contract_template_by_customer != 'no',
            self.tks_has_tks_im_reprint_master_agreement != 'no',
            self.tks_has_tks_im_waive_master_agreement != 'no',
            self.tks_has_tks_im_delivery_before_sign_contract != 'no',
            self.tks_has_tks_im_dispatcher_request != 'no',
            self.tks_has_tks_im_changing_invoice != 'no',
            self.tks_has_tks_im_changing_finance_grade != 'no',
            self.tks_has_tks_im_overpayment_refund_to_customer != 'no',
            self.tks_has_tks_im_suspend_warning_letter != 'no',
            self.tks_has_tks_im_special_case_opl != 'no'
        ]

        bb_required = [
            self.tks_has_tks_im_special_case_fl != 'no',
            self.tks_has_tks_im_waive_duty_stamp_fee_for_customer != 'no',
            self.tks_has_tks_im_waive_duty_stamp_fee_for_customer_fl != 'no',
            self.tks_has_tks_im_transfer_agreement != 'no',
            self.tks_has_tks_im_below_min_spread_transaction != 'no',
            self.tks_has_tks_im_changing_application != 'no',
            self.tks_has_tks_im_early_purchase != 'no',
            self.tks_has_tks_im_permanent_exchange != 'no',
            self.tks_has_tks_im_early_vehicle_disposal != 'no',
            self.tks_has_tks_im_dispatcher_request != 'no',
            self.tks_has_tks_im_safety_driving_training != 'no',
            self.tks_has_tks_im_changing_invoice != 'no',
            self.tks_has_tks_im_special_case_opl != 'no',
        ]
        if any(risk_mitigation_required) and not any(risk_mitigation_fields):
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Risk Mitigation Empty'),
                    'message': _('Risk Mitigation must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
            return notification
        if any(bb_required) and not any(business_fields):
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Business Benefit Empty'),
                    'message': _('Business Benefit must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
            return notification
        if any(rr_item):
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Missing Remarks'),
                    'message': _('Please fill in all required remarks for the provided Risk Mitigation.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
            return notification
        if any(bb_item):
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Missing Remarks'),
                    'message': _('Please fill in all required remarks for the item Business Consideration.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
            return notification
        # if self.tks_has_tks_im_sparekey and self.tks_cost_security_24 == 'yes' and not self.amount_24:
        #     notification = {
        #         'type': 'ir.actions.client',
        #         'tag': 'display_notification',
        #         'params': {
        #             'title': _('Missing Amount'),
        #             'message': _('Please fill Amount if Use Cost / Security Deposit.'),
        #             'sticky': False,
        #             'type': 'warning',
        #         },
        #     }
        #     return notification

        if self.tks_im_attachment_underlying == 'yes' and not self.attachment_ids.filtered(lambda x: x.description == 'attach documents'):
            raise UserError(_("You have to attach at least one document."))

        if self.tks_use_approval_level:
            if not self.tks_is_data_complete:
                raise ValidationError("Please ensure all data has been completed before submitting.")
            else:
                self.ensure_one()
                if self.category_id.manager_approval == 'required':
                    employee = self.env['hr.employee'].search([('user_id', '=', self.request_owner_id.id)], limit=1)
                    if employee:
                        if not employee.parent_id:
                            raise UserError(_('This request needs to be approved by your manager. There is no manager linked to your employee profile.'))

                        if not employee.parent_id.user_id:
                            raise UserError(_('This request needs to be approved by your manager. There is no user linked to your manager.'))

                        if not self.approver_ids.filtered(lambda a: a.user_id.id == employee.parent_id.user_id.id):
                            raise UserError(_('This request needs to be approved by your manager. Your manager is not in the approvers list.'))

            approvers = self.approver_ids
            if self.approver_sequence or self.tks_use_approval_level:
                approvers = approvers.filtered(lambda a: a.status in ['new', 'revised', 'pending', 'waiting'])

                approvers[1:].sudo().write({'status': 'waiting'})

                approvers = approvers.filtered(lambda a: a.tks_approvers_level == 'level_1')
            else:
                approvers = approvers.filtered(lambda a: a.status == 'new')

            approvers._create_activity()
            approvers.sudo().write({'status': 'pending'})

            # Update the date confirmed and submitted date fields
            self.sudo().write({'date_confirmed': fields.Datetime.now()})
            self.tks_submitted_date = fields.Date.today()
            self.tks_already_submit = True

            for approver in self.approver_ids:
                current_employee = approver.user_id.employee_id
                if approver.tks_approvers_level not in current_employee.tks_approver_level_ids.mapped("code"):
                    raise ValidationError(_("There is an approver that does not match their level, please adjust the approver according to their level."))

        return super(ApprovalRequest, self).action_confirm()

    # feature editor approval
    def view_editor_approval_approver(self):
        return {
            'name': _('Editor Approval'),
            'type': 'ir.actions.act_window',
            'res_id': self.id,
            'view_mode': 'form',
            'res_model': 'approval.request',
            'view_id': self.env.ref('tks_specific.approval_request_form_editor').id,
            "target": "new",
            # "domain" : [('request_id', '=', self.id)]
        }

    def view_editor_approval_reviewer(self):
        return {
            "name": _("Editor Approvers"),
            'res_id': self.id,
            "view_mode": "form",
            "res_model": "approval.request",
            "view_id": self.env.ref('tks_specific.approval_request_form_editor_reviewer').id,
            "type": "ir.actions.act_window",
            "target": "current",
        }

    def add_data(self):
        return {
            'name': _('Editor Approver'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'tks.editor.reviewer',
            "target": "new",
        }

    def action_done_1(self, approver=None):
        approvers_level_1 = self.approver_ids.filtered(
            lambda x: x.tks_approvers_level == "level_1" and x.user_id == self.env.user
        )

        if self.env.user != approvers_level_1.user_id:
            raise UserError("You are not allowed to approve this request.")
        return {
            'name': _('Remarks/Comment'),
            'type': 'ir.actions.act_window',
            'res_model': 'tks.verify.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_tks_im_id': self.id,
            }
        }

    def _action_done_1(self, approver=None, remark=None):
        self.ensure_one()
        self._ensure_can_approve()

        if not isinstance(approver, models.BaseModel):
            approver = self.mapped('approver_ids').filtered(
                lambda a: a.user_id == self.env.user and a.tks_approvers_level == "level_1"
            )

        if not approver:
            raise UserError(_("You are not allowed to approve this request."))

        if not remark:
            raise UserError(_("Remark/Comment is required."))

        approver.write({
            'status': 'approved',
            'tks_remark': remark,
        })


        # Send approval accepted message
        for approval in self:
            if approval.request_owner_id.partner_id:
                body = _("The request created on %(create_date)s by %(request_owner)s has been accepted.",
                        create_date=approval.create_date.date(),
                        request_owner=approval.request_owner_id.name)
                subject = _("The request %(request_name)s for %(request_owner)s has been accepted",
                            request_name=approval.name,
                            request_owner=approval.request_owner_id.name)
                approval.message_notify(
                    body=body,
                    subject=subject,
                    partner_ids=approval.request_owner_id.partner_id.ids,
                )
                status_msg = Markup("""
                    <div>
                        <span>Approval Status Change</span><br/>
                        <span class="text-muted">Ready to Verify</span> &#8594; <span class="text-primary">Verified</span><br/>
                        <span>Remarks/Comment: %s</span>
                    </div>
                """) % remark

                approval.message_post(
                    body=status_msg,
                    subtype_xmlid="mail.mt_note",
                    message_type="notification",
                )
        self.sudo()._update_next_approvers('pending', approver, only_next_approver=True)
        self.sudo()._get_user_approval_activities(
            user=self.env.user
        ).action_feedback()

    def action_done_2(self, approver=None):
        approvers_level_2 = self.approver_ids.filtered(
            lambda x: x.tks_approvers_level == "level_2" and x.user_id == self.env.user
        )

        if self.env.user != approvers_level_2.user_id:
            raise UserError("You are not allowed to approve this request.")
        else:
            self._ensure_can_approve()
            if not isinstance(approver, models.BaseModel):
                approver = self.mapped('approver_ids').filtered(
                    lambda approver: approver.user_id == self.env.user
                    and approver.tks_approvers_level == "level_2"
                )

            approver.write({'status': 'approved'})

            # Send approval accepted message
            for approval in self:
                if approval.request_owner_id.partner_id:
                    body = _("The request created on %(create_date)s by %(request_owner)s has been accepted.",
                            create_date=approval.create_date.date(),
                            request_owner=approval.request_owner_id.name)
                    subject = _("The request %(request_name)s for %(request_owner)s has been accepted",
                                request_name=approval.name,
                                request_owner=approval.request_owner_id.name)
                    approval.message_notify(
                        body=body,
                        subject=subject,
                        partner_ids=approval.request_owner_id.partner_id.ids,
                    )

            self.sudo()._update_next_approvers('pending', approver, only_next_approver=True)
            self.sudo()._get_user_approval_activities(user=self.env.user).action_feedback()

            all_level_2 = self.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_2')
            if all(level_2.status == 'approved' for level_2 in all_level_2):
                self.tks_first_approve = True

    def action_done_3(self, approver=None):
        approvers_level_3 = self.approver_ids.filtered(
            lambda x: x.tks_approvers_level == "level_3" and x.user_id == self.env.user
        )

        if self.env.user != approvers_level_3.user_id:
            raise UserError("You are not allowed to approve this request.")
        else:
            self._ensure_can_approve()
            if not isinstance(approver, models.BaseModel):
                approver = self.mapped('approver_ids').filtered(
                    lambda approver: approver.user_id == self.env.user
                    and approver.tks_approvers_level == "level_3"
                    and approver.request_id.tks_last_approve == False
                )

            approver.write({'status': 'approved'})

            # Send approval accepted message
            for approval in self:
                if approval.request_owner_id.partner_id:
                    body = _("The request created on %(create_date)s by %(request_owner)s has been accepted.",
                            create_date=approval.create_date.date(),
                            request_owner=approval.request_owner_id.name)
                    subject = _("The request %(request_name)s for %(request_owner)s has been accepted",
                                request_name=approval.name,
                                request_owner=approval.request_owner_id.name)
                    approval.message_notify(
                        body=body,
                        subject=subject,
                        partner_ids=approval.request_owner_id.partner_id.ids,
                    )

            self.sudo()._update_next_approvers('pending', approver, only_next_approver=True)
            self.sudo()._get_user_approval_activities(user=self.env.user).action_feedback()

            all_level_3 = self.approver_ids.filtered(lambda x: x.tks_approvers_level == 'level_3')
            if all(level_3.status == 'approved' for level_3 in all_level_3):
                self.tks_last_approve = True

    def action_done_4(self, approver=None):
        approvers_level_4 = self.approver_ids.filtered(
            lambda x: x.tks_approvers_level == "level_4" and x.user_id == self.env.user
        )

        if self.env.user != approvers_level_4.user_id:
            raise UserError("You are not allowed to approve this request.")
        else:
            self._ensure_can_approve()
            if not isinstance(approver, models.BaseModel):
                approver = self.mapped('approver_ids').filtered(
                    lambda approver: approver.user_id == self.env.user
                    and approver.tks_approvers_level == "level_4"
                    and approver.request_id.tks_last_approve == True
                )

            approver.write({'status': 'approved'})

            # Send approval accepted message
            for approval in self:
                if approval.request_owner_id.partner_id:
                    body = _("The request created on %(create_date)s by %(request_owner)s has been accepted.",
                            create_date=approval.create_date.date(),
                            request_owner=approval.request_owner_id.name)
                    subject = _("The request %(request_name)s for %(request_owner)s has been accepted",
                                request_name=approval.name,
                                request_owner=approval.request_owner_id.name)
                    approval.message_notify(
                        body=body,
                        subject=subject,
                        partner_ids=approval.request_owner_id.partner_id.ids,
                    )

            self.sudo()._update_next_approvers('pending', approver, only_next_approver=True)
            self.sudo()._get_user_approval_activities(user=self.env.user).action_feedback()
            self.tks_all_level_approved = True
            self.tks_approved_date = fields.Datetime.now()

    def action_cancel(self):
        res = super(ApprovalRequest, self).action_cancel()
        self.tks_first_approve = False
        self.tks_last_approve = False
        self.tks_all_level_approved = False
        self.tks_approved_date = False
        return res

    def action_cancel_1(self):
        self.sudo()._get_user_approval_activities(user=self.env.user).unlink()
        self.mapped('approver_ids').sudo().write({'status': 'cancel'})
        self.tks_first_approve = False
        self.tks_last_approve = False
        self.tks_all_level_approved = False
        self.tks_approved_date = False

    def action_draft(self):
        if self.tks_use_approval_level:
            self.mapped('approver_ids').sudo().write({'status': 'new'})
            if self.tks_is_data_complete:
                self.tks_is_data_complete = False
            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
            }
        else:
            return super(ApprovalRequest, self).action_draft()

    def action_revised(self):
        approvers_level_1 = self.approver_ids.filtered(
            lambda x: x.tks_approvers_level == "level_1" and x.user_id == self.env.user
        )
        approvers_level_1.write({'status': 'revised'})

        self.sudo()._get_user_approval_activities(user=self.env.user).unlink()
        status_msg = Markup("""
            <div>
                <b>Need To Revise</b><br/>
                <span class="text-muted">Ready to Verify</span> &#8594; <span class="text-primary">To Submit</span><br/>
            </div>
        """)
        self.message_post(
            body=status_msg,
            subtype_xmlid="mail.mt_note",
            message_type="notification",
        )




    def action_withdraw(self, approver=None):
        res = super(ApprovalRequest, self).action_withdraw(approver)
        if self.tks_use_approval_level:
            approver = self.mapped("approver_ids").filtered(
                lambda approver: approver.tks_approvers_level == "level_4"
            )
            self.sudo()._update_next_approvers(
                "waiting", approver, only_next_approver=False, cancel_activities=True
            )
            approver.write({"status": "pending"})
            self.tks_first_approve = False
            self.tks_last_approve = False
            self.tks_all_level_approved = False
        return res

    #additional compute to show field based on category(currently based on category name)
    @api.depends("category_id","tks_im_fl_type","tks_im_opl_sparekey_type_id")
    def get_approval_category_to_show(self):
        for approval in self:
            if approval.category_id.name =="Delivery Before Sign Contract" or\
                approval.category_id.name == "Postpone Withdrawn Unit" or \
                approval.category_id.name == "Safekeep Running Contract Vehicle" or \
                approval.category_id.name == "Borrow BPKB" or \
                (approval.category_id.name == "Sparekey" and approval.tks_im_opl_sparekey_type_id.id == 1) or \
                (approval.category_id.name == "Changing Collateral BPKB" and approval.tks_im_fl_type == "tempo"):
                approval.cdp_show_due_date = True
            else:
                approval.cdp_show_due_date = False

    @api.depends(
                'tks_im_35_delivery_before_sign_contract_expected_return_date',#ok
                'tks_postpone_until_21', #ok
                # 'tks_im_34_postpone_kyc_document_ids','tks_im_34_postpone_kyc_document_ids.fulfillment_date'
                'tks_date_end_24', #ok
                'tks_im_2_temporary_change_end_date',#ok (tbd is this the desired field)
                # 'tks_im_5_list_document_postponed_ids','tks_im_5_list_document_postponed_ids.tks_im_5_fullfilment_date'#ok
                'tks_im_8_period_date_after',
                'tks_end_date_23'
                # 'tks_im_2_temporary_change_end_date'
                )
    def onchange_dates(self):
        for approval in self:
            if(
                approval.tks_im_35_delivery_before_sign_contract_expected_return_date or\
                approval.tks_postpone_until_21 or\
                approval.tks_im_2_temporary_change_start_date or\
                approval.tks_im_48_waive_duty_stamp_fee_for_customer_period_end or\
                approval.tks_im_2_temporary_change_end_date or\
                approval.tks_end_date_23 or\
                approval.tks_end_date_16
            ):
                #date_end_23 OK
                #tks_im_35_delivery_before_sign_contract_expected_return_date OK
                date = approval.tks_im_35_delivery_before_sign_contract_expected_return_date or\
                approval.tks_postpone_until_21 or\
                approval.tks_im_2_temporary_change_end_date or\
                approval.tks_im_8_period_date_after or\
                approval.tks_im_48_waive_duty_stamp_fee_for_customer_period_end or\
                approval.tks_im_2_temporary_change_end_date or\
                approval.tks_end_date_23 or\
                approval.tks_end_date_16

                approval.cdp_due_date = date

            elif approval.tks_date_end_24 and approval.tks_im_opl_sparekey_type_id.id == 1:
                approval.cdp_due_date = approval.tks_date_end_24

            else:

                approval.cdp_due_date = False
