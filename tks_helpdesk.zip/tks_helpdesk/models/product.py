from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = "product.template"

    cdp_scope_id = fields.Many2one("cdp.scope", string="Scope")
    cdp_category_ids = fields.Many2many("cdp.category", string="Category")
