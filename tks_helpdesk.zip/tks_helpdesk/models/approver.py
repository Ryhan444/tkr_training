from odoo import models, fields, api


class ApprovalApprover(models.Model):
    _inherit = "approval.approver"

    cdp_repair_id = fields.Many2one("repair.order", "Repair", ondelete="cascade")
    cdp_approved = fields.Boolean()
    cdp_approver_level_repair = fields.Selection(
        selection=[
            ("1", "Reviewer"),
            ("2", "Final Approver"),
        ],
        string="Role",
    )

    company_id = fields.Many2one(
        "res.company",
        string="Company",
        related=False,
        compute="_cdp_compute_company",
        store=True,
        readonly=True,
        index=True,
    )
    cdp_approver_domain = fields.Char(compute="_get_approver_domain", store=True)

    @api.depends("cdp_approver_level_repair")
    def _get_approver_domain(self):
        for approver in self:
            domain = []
            if approver.cdp_approver_level_repair == "1":
                domain.append(("id", "in", [119, 77, 371]))
            else:
                domain.append(("id", "in", [119, 371, 77, 58]))

            approver.cdp_approver_domain = domain

    @api.depends(
        "request_id",
        "cdp_repair_id",
        "request_id.company_id",
        "cdp_repair_id.company_id",
    )
    def _cdp_compute_company(self):
        for approver in self:
            if approver.request_id:
                approver.company_id = approver.request_id.company_id
            elif approver.cdp_repair_id:
                approver.company_id = approver.cdp_repair_id.company_id
            else:
                approver.company_id = self.env.company
