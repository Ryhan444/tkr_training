from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import date


class CrmLead(models.Model):
    _inherit = "crm.lead"
    _order = "priority desc, tks_crm_number asc"

    # Overide field partner
    user_id = fields.Many2one(
        "res.users",
        string="Salesperson",
        domain="[('share', '=', False),('is_sales_group', '=', True)]",
    )
    partner_id = fields.Many2one(
        "res.partner",
        string="Customer",
        check_company=True,
        index=True,
        tracking=10,
        domain=[("is_company", "=", True)],
        help="Linked partner (optional). Usually created when converting the lead. You can find a partner by its Name, TIN, Email or Internal Reference.",
    )

    probability = fields.Float(
        "Probability",
        aggregator="avg",
        copy=False,
        compute=False,
        readonly=False,
        store=True,
    )

    automated_probability = fields.Float(
        "Automated Probability", compute=False, readonly=True, store=True
    )

    # New Field
    tks_lead_type_created = fields.Boolean(compute="_get_lead_type_created")
    tks_user_is_head_section_id = fields.Many2one(
        "res.users", related="tks_trans_section_id.tks_section_head_id.user_id"
    )
    tks_user_is_head_dept_id = fields.Many2one(
        "res.users", related="tks_trans_section_id.tks_department_id.manager_id.user_id"
    )
    tks_is_won = fields.Boolean(string="Is Won?", compute="_get_won_state")
    tks_is_lost = fields.Boolean(string="Is Lost?", compute="_get_lost_state")
    tks_prev_name_fl = fields.Char(string="Previous Name FL", store=True)
    tks_prev_name_opl = fields.Char(string="Previous Name OPL", store=True)
    tks_disbursement = fields.Selection(
        string="Disbursement", selection=[("yes", "Yes"), ("no", "No")]
    )
    tks_disbursement_date = fields.Date(string="Disbursement Date")
    tks_expected_disbursement_date = fields.Date(string="Expected Disbursement Date")
    tks_contract = fields.Selection(
        string="Contract", selection=[("yes", "Yes"), ("no", "No")]
    )
    tks_contract_no = fields.Char(string="Contract No.")

    # New field for company info
    tks_aging_rank_c = fields.Integer(string="Aging Rank C", compute="_set_aging_ranks")
    tks_aging_rank_b = fields.Integer(string="Aging Rank B", compute="_set_aging_ranks")
    tks_aging_rank_a = fields.Integer(string="Aging Rank A", compute="_set_aging_ranks")
    tks_total_aging = fields.Integer(
        string="Total Aging",
        compute="_set_total_aging",
    )
    tks_crm_lead_type = fields.Selection(
        string=_("CRM Type"),
        selection=[
            ("fl", "Finance Lease"),
            ("opl", "Operating Lease"),
        ],
    )
    tks_crm_number = fields.Integer(
        string="Last Number",
        compute="_compute_last_number",
        store=True,
        help="Number of CRM",
    )

    tks_basic_company_type = fields.Selection(
        string="Company Type", related="partner_id.tks_company_type"
    )

    tks_basic_company_type_remark = fields.Char(
        string="Company Type Remark", related="partner_id.tks_company_type_remark"
    )

    tks_company_name = fields.Char(string="Company Name", related="partner_id.name")

    tks_company_group_id = fields.Many2one(
        "tks.res.partner.company.group",
        string="Company Group",
        related="partner_id.tks_company_group_id",
    )

    tks_listed_company = fields.Selection(
        string="Listed Company(Tbk)",
        related="partner_id.tks_listed_company",
    )

    tks_basic_industry_id = fields.Many2one(
        "res.partner.industry",
        string="Line of Business",
        related="partner_id.industry_id",
    )
    tks_basic_vat = fields.Char(string="NPWP", related="partner_id.vat")

    tks_street_address = fields.Char(
        string="Head Office Street", related="partner_id.street"
    )

    tks_street_2_address = fields.Char(
        string="Head Office Street2", related="partner_id.street2"
    )

    tks_city_address = fields.Char(string="Head Office City", related="partner_id.city")

    tks_state_address_id = fields.Many2one(
        "res.country.state", string="Head Office State", related="partner_id.state_id"
    )

    tks_zip_address = fields.Char(string="Head Office Zip", related="partner_id.zip")

    tks_country_address_id = fields.Many2one(
        "res.country", string="Head Office Country", related="partner_id.country_id"
    )

    tks_basic_phone = fields.Char(
        string="Head Office Phone Number", related="partner_id.phone"
    )

    tks_branch_address_status = fields.Selection(
        string=_("Branch Address Status"),
        selection=[
            ("same_head", "Same as Head Office"),
            ("other", "Other"),
        ],
    )

    tks_partner_branch_id = fields.Many2one(
        "res.partner",
        string="Branch Contact",
        domain="[('type', '=', 'branch_address'), '|', ('parent_id', '=', partner_id), ('id', '=', partner_id)]",
    )

    tks_street_branch_address = fields.Char(
        string="Branch Office Street", related="tks_partner_branch_id.street"
    )

    tks_street_2_branch_address = fields.Char(
        string="Branch Office Street2", related="tks_partner_branch_id.street2"
    )

    tks_city_branch_address = fields.Char(
        string="Branch Office City", related="tks_partner_branch_id.city"
    )

    tks_state_branch_address_id = fields.Many2one(
        "res.country.state",
        string="Branch Office State",
        related="tks_partner_branch_id.state_id",
    )

    tks_zip_branch_address = fields.Char(
        string="Branch Office Zip", related="tks_partner_branch_id.zip"
    )

    tks_country_branch_address_id = fields.Many2one(
        "res.country",
        string="Branch Office Country",
        related="tks_partner_branch_id.country_id",
    )

    tks_partner_branch_phone = fields.Char(
        string="Branch Office Phone Number",
        related="tks_partner_branch_id.phone",
    )

    tks_partner_npwp_id = fields.Many2one(
        "res.partner",
        string="NPWP Contact",
        domain="[('type','=','npwp_address'),('parent_id','=',partner_id)]",
    )

    tks_street_npwp_address = fields.Char(
        string="NPWP Office Street", related="tks_partner_npwp_id.street"
    )

    tks_street_2_npwp_address = fields.Char(
        string="NPWP Office Street2", related="tks_partner_npwp_id.street2"
    )

    tks_city_npwp_address = fields.Char(
        string="NPWP Office City", related="tks_partner_npwp_id.city"
    )

    tks_state_npwp_address_id = fields.Many2one(
        "res.country.state",
        string="NPWP Office State",
        related="tks_partner_npwp_id.state_id",
    )

    tks_zip_npwp_address = fields.Char(
        string="NPWP Office Zip", related="tks_partner_npwp_id.zip"
    )

    tks_country_npwp_address_id = fields.Many2one(
        "res.country",
        string="NPWP Office Country",
        related="tks_partner_npwp_id.country_id",
    )

    tks_basic_classification = fields.Selection(
        string="Classification", related="partner_id.tks_classification"
    )

    tks_basic_company_size = fields.Selection(
        string="Company Size", related="partner_id.tks_company_size"
    )

    tks_basic_number_of_unit = fields.Integer(string="Number of Unit(s)")

    tks_basic_net_finance = fields.Monetary(
        string="Net Finance",
        currency_field="tks_basic_currency_id",
    )

    tks_basic_ma_profit = fields.Monetary(
        string="MA Profit",
        currency_field="tks_basic_currency_id",
    )

    tks_basic_currency_id = fields.Many2one(
        "res.currency",
        string="Currency",
        default=lambda self: self.env["res.currency"].search([("name", "=", "IDR")]),
    )

    # New field for PIC Info
    tks_cust_1_partner_id = fields.Many2one(
        "res.partner",
        string="Cust PIC Contact",
        domain="[('type','=','customer_pic'),('parent_id','=',partner_id)]",
    )

    tks_cust_1_name = fields.Char(
        string="Cust PIC Name", related="tks_cust_1_partner_id.name"
    )

    tks_cust_1_function = fields.Char(
        string=_("Cust PIC Job Title"), related="tks_cust_1_partner_id.function"
    )

    tks_cust_1_pic_department = fields.Char(
        string=_("Cust PIC Dept"),
        related="tks_cust_1_partner_id.tks_cust_department",
    )

    tks_cust_1_vat = fields.Char(string=_("NPWP"), related="tks_cust_1_partner_id.vat")

    tks_cust_1_email = fields.Char(
        string=_("Cust PIC Email"), related="tks_cust_1_partner_id.email"
    )

    tks_cust_1_mobile = fields.Char(
        string=_("Cust PIC Mobile No."), related="tks_cust_1_partner_id.mobile"
    )

    tks_cust_2_partner_id = fields.Many2one(
        "res.partner",
        string="Cust PIC Contact",
        domain="[('type','=','customer_pic'),('parent_id','=',partner_id)]",
    )

    tks_cust_2_name = fields.Char(
        string="Cust PIC Name", related="tks_cust_2_partner_id.name"
    )

    tks_cust_2_function = fields.Char(
        string=_("Cust PIC Job Title"), related="tks_cust_2_partner_id.function"
    )

    tks_cust_2_pic_department = fields.Char(
        string=_("Cust PIC Dept"),
        related="tks_cust_2_partner_id.tks_cust_department",
    )

    tks_cust_2_vat = fields.Char(string=_("NPWP"), related="tks_cust_2_partner_id.vat")

    tks_cust_2_email = fields.Char(
        string=_("Cust PIC Email"), related="tks_cust_2_partner_id.email"
    )

    tks_cust_2_mobile = fields.Char(
        string=_("Cust PIC Mobile No."), related="tks_cust_2_partner_id.mobile"
    )

    tks_cust_3_partner_id = fields.Many2one(
        "res.partner",
        string="Cust PIC Contact",
        domain="[('type','=','customer_pic'),('parent_id','=',partner_id)]",
    )

    tks_cust_3_name = fields.Char(
        string="Cust PIC Name", related="tks_cust_3_partner_id.name"
    )

    tks_cust_3_function = fields.Char(
        string=_("Cust PIC Job Title"), related="tks_cust_3_partner_id.function"
    )

    tks_cust_3_pic_department = fields.Char(
        string=_("Cust PIC Dept"),
        related="tks_cust_3_partner_id.tks_cust_department",
    )

    tks_cust_3_vat = fields.Char(string=_("NPWP"), related="tks_cust_3_partner_id.vat")

    tks_cust_3_email = fields.Char(
        string=_("Cust PIC Email"), related="tks_cust_3_partner_id.email"
    )

    tks_cust_3_mobile = fields.Char(
        string=_("Cust PIC Mobile No."), related="tks_cust_3_partner_id.mobile"
    )

    # New Field for dealer info
    tks_dealer_1_partner_id = fields.Many2one(
        "res.partner",
        string="Dealer PIC Contact",
        domain="[('type','=','dealer_pic'),('parent_id','=',partner_id)]",
    )

    tks_dealer_1_name = fields.Char(
        string="Dealer Name", related="tks_dealer_1_partner_id.tks_dealer_name"
    )

    tks_dealer_1_function = fields.Char(
        string=_("Dealer Job Title"), related="tks_dealer_1_partner_id.function"
    )

    tks_dealer_1_email = fields.Char(
        string=_("Dealer Email"), related="tks_dealer_1_partner_id.email"
    )

    tks_dealer_1_mobile = fields.Char(
        string=_("Dealer Mobile No."), related="tks_dealer_1_partner_id.mobile"
    )

    tks_street_dealer_1_address = fields.Char(
        string="Dealer Office Street", related="tks_dealer_1_partner_id.street"
    )

    tks_street_2_dealer_1_address = fields.Char(
        string="Dealer Office Street2", related="tks_dealer_1_partner_id.street2"
    )

    tks_city_dealer_1_address = fields.Char(
        string="Dealer Office City", related="tks_dealer_1_partner_id.city"
    )

    tks_state_dealer_1_address_id = fields.Many2one(
        "res.country.state",
        string="Dealer Office State",
        related="tks_dealer_1_partner_id.state_id",
    )

    tks_zip_dealer_1_address = fields.Char(
        string="Dealer Office Zip", related="tks_dealer_1_partner_id.zip"
    )

    tks_country_dealer_1_address_id = fields.Many2one(
        "res.country",
        string="Dealer Office Country",
        related="tks_dealer_1_partner_id.country_id",
    )

    tks_dealer_2_partner_id = fields.Many2one(
        "res.partner",
        string="Dealer PIC Contact",
        domain="[('type','=','dealer_pic'),('parent_id','=',partner_id)]",
    )

    tks_dealer_2_name = fields.Char(
        string="Dealer Name", related="tks_dealer_2_partner_id.tks_dealer_name"
    )

    tks_dealer_2_function = fields.Char(
        string=_("Dealer Job Title"), related="tks_dealer_2_partner_id.function"
    )

    tks_dealer_2_email = fields.Char(
        string=_("Dealer Email"), related="tks_dealer_2_partner_id.email"
    )

    tks_dealer_2_mobile = fields.Char(
        string=_("Dealer Mobile No."), related="tks_dealer_2_partner_id.mobile"
    )

    tks_street_dealer_2_address = fields.Char(
        string="Dealer 2 Office Street", related="tks_dealer_2_partner_id.street"
    )

    tks_street_2_dealer_2_address = fields.Char(
        string="Dealer 2 Office Street2", related="tks_dealer_2_partner_id.street2"
    )

    tks_city_dealer_2_address = fields.Char(
        string="Dealer 2 Office City", related="tks_dealer_2_partner_id.city"
    )

    tks_state_dealer_2_address_id = fields.Many2one(
        "res.country.state",
        string="Dealer 2 Office State",
        related="tks_dealer_2_partner_id.state_id",
    )

    tks_zip_dealer_2_address = fields.Char(
        string="Dealer 2 Office Zip", related="tks_dealer_2_partner_id.zip"
    )

    tks_country_dealer_2_address_id = fields.Many2one(
        "res.country",
        string="Dealer 2 Office Country",
        related="tks_dealer_2_partner_id.country_id",
    )

    # New field transaction info

    tks_trans_type_fl = fields.Selection(
        string=_("Transaction Type"),
        selection=[("pwip", "PWIP"), ("fl", "FL"), ("fl_slb", "FL SLB")],
    )

    tks_trans_section_id = fields.Many2one(
        "tks.section",
        string=_("Section"),
    )

    tks_trans_employee_id = fields.Many2one(
        "hr.employee",
        string="Marketing PIC",
        domain="[('tks_section_id', '=', tks_trans_section_id)]",
    )

    tks_trans_holding_unit = fields.Integer(
        string=_("Total Holding Unit(s)"),
        compute="_get_total_holding_unit",
        inverse="_inverse_total_holding_unit",
        store=True,
    )
    tks_cust_holding_unit = fields.Integer(
        string="Total Holding Unit(s)", related="partner_id.tks_total_holding_unit"
    )

    tks_trans_competitor = fields.Char(string=_("List of Competitors"), store=True)

    tks_trans_asset = fields.Float(
        string=_("Ownership Scheme Asset (%)"),
        compute="compute_trans_asset",
        readonly=False,
        store=True,
    )

    tks_trans_rental = fields.Float(
        string=_("Ownership Scheme Rental (%)"),
        compute="compute_trans_rental",
        readonly=False,
        store=True,
    )

    source_id = fields.Many2one("utm.source", string="Source of Inquiries")

    # New field for insurance info

    tks_insurance_additional_coverage = fields.Html(
        string=_("Additional Insurance Coverage")
    )

    # New field for invoice info

    tks_inv_payment_type = fields.Selection(
        string=_("Payment Type"),
        selection=[
            ("pdc", "PDC"),
            ("transfer", "Transfer"),
            ("staning_instruction", "Standing Instruction"),
        ],
    )

    tks_inv_bank_account_fl = fields.Selection(
        string=_("Bank Account"),
        selection=[
            ("bca_2", "BCA 2: 0733-01888-4"),
            ("permata_3", "PERMATA 3: 05112-78899"),
            ("mufg_idr", "MUFG IDR: 5100-000131"),
            ("mufg_usd", "MUFG USD: 5300-981201"),
            ("mufg_jpy", "MUFG JPY: 5200-981215"),
            ("bri", "BRI: 041701000294307"),
            ("mandiri", "MANDIRI: 117-000-637-4201"),
            ("woori", "WOORI: 2009-4000-0012"),
            ("BTN", "BTN: 00000379-01-30-000327-6"),
            ("danamon", "DANAMON: 010-00198-989"),
            ("bni", "BNI: 3009-8120-15"),
            ("btpn", "04510026085"),
            ("btpn_idr", "BTPN IDR: 0800-300-4865"),
            ("btpn_usd", "BTPN USD: 0800-300-4873"),
            ("btpn_jpy", "BTPN JPY: 0800-300-4881"),
        ],
    )

    # New field other info

    tks_other_request = fields.Html(string=_("Special Condition Request"))

    tks_other_additional_info = fields.Html(string=_("Additional Info"))

    # New field opl

    tks_trans_type_opl = fields.Selection(
        string=_("Transaction Type"),
        selection=[
            ("opl", "OPL"),
            ("opl_p", "OPL +"),
            ("opl_lp", "OPL + LP"),
            ("opl_q", "OPL Quick"),
            ("opl_slb", "OPL SLB"),
        ],
    )

    tks_trans_maintenance_coverage = fields.Selection(
        string=_("Maintenance Coverage"),
        selection=[("yes", "Yes"), ("no", "No"), ("other", "Other")],
    )

    tks_trans_maintenance_remark = fields.Char(string=_("Maintenance Coverage Remark"))

    tks_trans_replacement_car = fields.Selection(
        string="Replacement Car", selection=[("yes", "Yes"), ("no", "No")]
    )

    tks_trans_stnk_coverage = fields.Selection(
        string="STNK Coverage", selection=[("yes", "Yes"), ("no", "No")]
    )

    tks_trans_kir_coverage = fields.Selection(
        string="KIR Coverage", selection=[("yes", "Yes"), ("no", "No")]
    )

    tks_trans_stnk_cover = fields.Selection(
        string="Insurance Coverage", selection=[("yes", "Yes"), ("no", "No")]
    )

    # New field opl insurance
    tks_insurance_special_condition = fields.Html(
        string=_("Insurance Special Condition")
    )

    # New field invoice info opl

    tks_inv_req_document = fields.Html(
        string=_("List of Required Documents for Invoicing")
    )

    tks_inv_prorate = fields.Selection(
        string=_("Prorate Invoice"),
        selection=[
            ("applicable", "Applicable"),
            ("not_applicable", "Not Applicable"),
        ],
    )

    tks_inv_penalty = fields.Selection(
        string=_("Late Payment Penalty"),
        selection=[
            ("applicable", "Applicable"),
            ("not_applicable", "Not Applicable"),
        ],
    )

    tks_inv_spc_condition = fields.Text(string=_("Invoice Special Condition"))

    tks_inv_date = fields.Date(
        string=_("Delivery Invoice Date"),
    )

    tks_inv_period = fields.Selection(
        string=_("Invoice Period"),
        selection=[
            ("1", "1"),
            ("3", "3"),
            ("6", "6"),
            ("12", "12"),
        ],
    )

    tks_inv_faktur_type = fields.Selection(
        string=_("Faktur Type"),
        selection=[
            ("wapu", "WAPU"),
            ("non_wapu", "Non WAPU"),
        ],
    )

    tks_inv_faktur_code = fields.Selection(
        string=_("Faktur Code"),
        selection=[
            ("10", "10 - Non WAPU"),
            ("20", "20 - Bendahara"),
            ("30", "30 - WAPU"),
            ("40", "40 - DPP Nilai Lain"),
            ("50", "50 - Penyerahan Agunan"),
            ("60", "60 - Lainnya"),
            ("70", "70 - PPN Ditanggung Pemerintah"),
            ("80", "80 - PPN Dibebaskan"),
            ("90", "90 - Penjualan"),
        ],
    )

    tks_inv_bank_account_opl = fields.Selection(
        string=_("Bank Account"),
        selection=[
            ("bca_2", "BCA 2: 0733-01888-4"),
            ("permata_2", "PERMATA 2: 05110-58899"),
            ("mufg_idr", "MUFG IDR: 5100-000131"),
            ("mufg_usd", "MUFG USD: 5300-981201"),
            ("mufg_jpy", "MUFG JPY: 5200-981215"),
            ("bri", "BRI: 041701000294307"),
            ("mandiri", "MANDIRI: 117-000-637-4201"),
            ("woori", "WOORI: 2009-4000-0012"),
            ("BTN", "BTN: 00000379-01-30-000327-6"),
            ("danamon", "DANAMON: 010-00198-989"),
            ("bni", "BNI: 3009-8120-15"),
            ("btpn", "04510026085"),
            ("btpn_idr", "BTPN IDR: 0800-300-4865"),
            ("btpn_usd", "BTPN USD: 0800-300-4873"),
            ("btpn_jpy", "BTPN JPY: 0800-300-4881"),
            ("bank_jtm", "BANK JATIM: 6111000083"),
        ],
    )

    tks_inv_partner_id = fields.Many2one(
        "res.partner",
        string="Invoice Contact",
        domain="[('type','=','invoice'),('parent_id','=',partner_id)]",
    )

    tks_street_inv_address = fields.Char(
        string="Invoice Office Street", related="tks_inv_partner_id.street"
    )

    tks_street_2_inv_address = fields.Char(
        string="Invoice Office Street2", related="tks_inv_partner_id.street2"
    )

    tks_city_inv_address = fields.Char(
        string="Invoice Office City", related="tks_inv_partner_id.city"
    )

    tks_state_inv_address_id = fields.Many2one(
        "res.country.state",
        string="Invoice Office State",
        related="tks_inv_partner_id.state_id",
    )

    tks_zip_inv_address = fields.Char(
        string="Invoice Office Zip", related="tks_inv_partner_id.zip"
    )

    tks_country_inv_address_id = fields.Many2one(
        "res.country",
        string="Invoice Office Country",
        related="tks_inv_partner_id.country_id",
    )

    name = fields.Char(
        "Opportunity",
        index="trigram",
        compute=False,
        required=False,
        readonly=True,
        store=True,
    )

    tks_last_probabilty = fields.Float("Last Probabilty")

    # Compute
    @api.depends("tks_crm_lead_type")
    def _get_lead_type_created(self):
        for lead in self:
            lead.tks_lead_type_created = (
                True if lead.tks_crm_lead_type and lead.stage_id.id != 5 else False
            )

    def _get_lost_state(self):
        for lead in self:
            lead.tks_is_lost = False
            if lead.stage_id:
                lead.tks_is_lost = lead.stage_id.name == "Lost"
            else:
                lead.tks_is_lost = False

    def _get_won_state(self):
        for lead in self:
            lead.tks_is_won = False
            if lead.stage_id:
                lead.tks_is_won = (
                    lead.stage_id.name == "Deal" and lead.probability == 100
                )
            else:
                lead.tks_is_won = False

    @api.depends("name")
    def _compute_last_number(self):
        for record in self:
            if record.name:
                try:
                    record.tks_crm_number = int(record.name.split("/")[-1])
                except:
                    record.tks_crm_number = 0
            else:
                record.tks_crm_number = 0

    @api.depends("partner_id", "partner_id.tks_total_holding_unit")
    def _get_total_holding_unit(self):
        for lead in self:
            if lead.partner_id:
                lead.tks_trans_holding_unit = lead.partner_id.tks_total_holding_unit

    def _inverse_total_holding_unit(self):
        for lead in self:
            if lead.tks_cust_holding_unit or lead.tks_trans_holding_unit:
                lead.partner_id.tks_total_holding_unit = lead.tks_trans_holding_unit

    def _set_aging_ranks(self):
        for lead in self:
            value = 0
            days_value = {}
            rank_c = 0
            rank_b = 0
            rank_a = 0
            if lead.duration_tracking:
                for stage_id, duration in lead.duration_tracking.items():
                    days_value[stage_id] = int(duration) / 86400

                for stage, days in days_value.items():
                    if stage == "1":
                        rank_c = days
                    if stage == "2":
                        rank_b = days
                    if stage == "3":
                        rank_a = days

            lead.tks_aging_rank_c = rank_c
            lead.tks_aging_rank_b = rank_b
            lead.tks_aging_rank_a = rank_a

    def _set_total_aging(self):
        for lead in self:
            lead.tks_total_aging = (
                lead.tks_aging_rank_a + lead.tks_aging_rank_b + lead.tks_aging_rank_c
            )

    def cron_set_aging_days(self):
        leads = self.search([])
        leads._set_aging_ranks()
        leads._set_total_aging()

    @api.depends("tks_trans_asset")
    def compute_trans_rental(self):
        for lead in self:
            lead.tks_trans_rental = 0
            rest_rental = 1 - lead.tks_trans_asset
            if rest_rental < 0 or rest_rental > 1:
                raise ValidationError(_("Value cannot more than 100"))

            if rest_rental <= 1:
                self.tks_trans_rental = rest_rental

    @api.depends("tks_trans_rental")
    def compute_trans_asset(self):
        for lead in self:
            lead.tks_trans_asset = 0
            rest_asset = 1 - lead.tks_trans_rental
            if rest_asset < 0 or rest_asset > 1:
                raise ValidationError(_("Value cannot more than 100"))

            if rest_asset <= 1:
                self.tks_trans_asset = rest_asset

    @api.depends("tks_crm_lead_type")
    def _compute_name(self):
        for lead in self:
            if lead.tks_crm_lead_type:
                seq_obj = self.env["ir.sequence"]
                if not lead.name and lead.tks_crm_lead_type == "fl":
                    lead.name = seq_obj.next_by_code("tks.seq.crm.fl")
                if not lead.name and lead.tks_crm_lead_type == "opl":
                    lead.name = seq_obj.next_by_code("tks.seq.crm.opl")
                else:
                    super(CrmLead, lead)._compute_name()

    @api.depends(lambda self: ["stage_id", "team_id"] + self._pls_get_safe_fields())
    def _compute_probabilities(self):
        for lead in self:
            if lead.tks_crm_lead_type:
                lead.probability = lead.tks_last_probabilty
                lead.automated_probability = lead.tks_last_probabilty
            else:
                return super(CrmLead, self)._compute_probabilities()

    # Onchange
    @api.onchange("user_id")
    def onchange_user_id(self):
        if self.user_id:
            employee_ids = self.user_id.employee_ids
            if employee_ids:
                for employee in employee_ids:
                    if employee.sudo().tks_lease_type:
                        self.sudo().tks_crm_lead_type = employee.sudo().tks_lease_type
                        # self.with_context(is_from_user=True).sudo().write({'tks_crm_lead_type': employee.sudo().tks_lease_type})
                    elif employee.sudo().tks_section_id:
                        self.sudo().tks_trans_section_id = (
                            employee.sudo().tks_section_id
                        )
                        # self.sudo().write({'tks_trans_section_id': employee.sudo().tks_section_id})
            else:
                self.tks_crm_lead_type = False
                self.tks_trans_section_id = False

    # CRUD
    @api.model_create_multi
    def create(self, vals_list):
        res = super(CrmLead, self).create(vals_list)
        for vals in vals_list:
            if vals.get("tks_basic_number_of_unit"):
                if vals.get("tks_basic_number_of_unit") < 0:
                    raise ValidationError("Cannot enter negative number")

            if vals.get("probability"):
                if vals.get("probability") > 99 and not res.stage_id.is_won:
                    raise ValidationError(
                        "Probabilty can't be more than 99%% if the stage is not won"
                    )

            if vals.get("tks_crm_lead_type"):
                seq_obj = self.env["ir.sequence"]
                if not res.name:
                    if vals.get("tks_crm_lead_type") == "fl":
                        res.name = seq_obj.next_by_code("tks.seq.crm.fl")
                    elif vals.get("tks_crm_lead_type") == "opl":
                        res.name = seq_obj.next_by_code("tks.seq.crm.opl")
        return res

    def tks_update_crm(self, vals):
        if isinstance(vals, dict):
            for lead in self:
                name = [lead.name]
                # stage_id = lead.env["crm.stage"].search([('sequence','=',7)]).id
                if vals.get("active") == False:
                    lead.tks_last_probabilty = lead.probability

                if (
                    vals.get("tks_inv_address_status_id")
                    and vals.get("tks_inv_address_status_id") != 3
                ):
                    lead.tks_inv_partner_id = False
                    lead.tks_street_inv_address = False
                    lead.tks_street_2_inv_address = False
                    lead.tks_city_inv_address = False
                    lead.tks_state_inv_address_id = False
                    lead.tks_zip_inv_address = False
                    lead.tks_country_inv_address_id = False

                if vals.get("tks_crm_lead_type"):
                    seq_obj = self.env["ir.sequence"]
                    if vals.get("tks_crm_lead_type") == "fl":
                        if not lead.tks_prev_name_opl:
                            lead.tks_prev_name_opl = name[0]
                        lead.name = lead.tks_prev_name_fl
                        if lead.tks_prev_name_opl:
                            self.sudo().create(
                                {
                                    "name": lead.tks_prev_name_opl,
                                    # 'stage_id': stage_id,
                                    "active": False,
                                }
                            )
                        if not lead.name:
                            lead.name = seq_obj.next_by_code("tks.seq.crm.fl")
                        same_lead = self.env["crm.lead"].search(
                            [("name", "=", lead.name), ("active", "=", False)]
                        )
                        if same_lead:
                            same_lead.sudo().unlink()
                    elif vals.get("tks_crm_lead_type") == "opl":
                        if not lead.tks_prev_name_fl:
                            lead.tks_prev_name_fl = name[0]
                        lead.name = lead.tks_prev_name_opl
                        if lead.tks_prev_name_fl:
                            self.sudo().create(
                                {
                                    "name": lead.tks_prev_name_fl,
                                    # 'stage_id': stage_id,
                                    "active": False,
                                }
                            )
                        if not lead.name:
                            lead.name = seq_obj.next_by_code("tks.seq.crm.opl")
                        same_lead = self.env["crm.lead"].search(
                            [("name", "=", lead.name), ("active", "=", False)]
                        )
                        if same_lead:
                            same_lead.sudo().unlink()

                if vals.get("tks_basic_number_of_unit"):
                    if vals.get("tks_basic_number_of_unit") < 0:
                        raise ValidationError("Cannot enter negative number")

                if vals.get("probability"):
                    if vals.get("probability") > 99 and not self.stage_id.is_won:
                        raise ValidationError(
                            "Probabilty can't be more than 99%% if the stage is not won"
                        )

                if vals.get("stage_id") or vals.get("tks_crm_lead_type"):
                    if lead.stage_id.is_won:
                        lead.probability = 100

                    if vals.get("stage_id") in [2, 3, 4]:
                        number_of_unit = vals.get("tks_basic_number_of_unit") or lead.tks_basic_number_of_unit
                        net_finance = vals.get("tks_basic_net_finance") or lead.tks_basic_net_finance
                        ma_profit = vals.get("tks_basic_ma_profit") or lead.tks_basic_ma_profit
                        holding_unit = vals.get("tks_trans_holding_unit") or lead.tks_trans_holding_unit
                        if number_of_unit <= 0 and lead.tks_opl_type_id.name == 'New Car' or number_of_unit <= 0 and lead.tks_crm_lead_type == 'fl':
                            raise ValidationError(
                                "Number of units required to advance to the next rank."
                            )
                        if net_finance <= 0 and lead.tks_opl_type_id.name == 'New Car' or net_finance <= 0 and lead.tks_crm_lead_type == 'fl':
                            raise ValidationError(
                                "Net Finance required to advance to the next rank."
                            )
                        if ma_profit <= 0:
                            raise ValidationError(
                                "MA Profit required to advance to the next rank."
                            )
                        if holding_unit <= 0:
                            raise ValidationError(
                                "Total Holding required to advance to the next rank."
                            )

                if "tks_basic_number_of_unit" in vals or "tks_opl_type_id" in  vals:
                    number_of_unit = vals.get("tks_basic_number_of_unit")
                    if number_of_unit <= 0 and lead.stage_id.id in [2, 3, 4] and vals.get("tks_opl_type_id") == 1 or number_of_unit <= 0 and lead.stage_id.id in [2, 3, 4] and lead.tks_crm_lead_type == 'fl':
                        raise ValidationError(
                            "Cannot set Number of Unit to 0 or negative in this Rank"
                        )
                if "tks_basic_net_finance" in vals or "tks_opl_type_id" in  vals:
                    net_finance = vals.get("tks_basic_net_finance")
                    if net_finance <= 0 and lead.stage_id.id in [2, 3, 4] and vals.get("tks_opl_type_id") == 1 or net_finance <= 0 and lead.stage_id.id in [2, 3, 4] and lead.tks_crm_lead_type == 'fl':
                        raise ValidationError(
                            "Cannot set Net Finance to 0 or negative in this Rank"
                        )
                if "tks_basic_ma_profit" in vals:
                    ma_profit = vals.get("tks_basic_ma_profit")
                    if ma_profit <= 0 and lead.stage_id.id in [2, 3, 4]:
                        raise ValidationError(
                            "Cannot set MA Profit to 0 or negative in this Rank"
                        )
        else:
            return False

    def write(self, vals):
        if not isinstance(vals, dict):
            return super(CrmLead, self).write({})

        self.tks_update_crm(vals)
        return super(CrmLead, self).write(vals)

    def unlink(self):
        # stage_id = self.env["crm.stage"].search([('sequence','=',7)]).id
        for lead in self:
            lead_obj = self.env["crm.lead"]
            same_lead = self.env["crm.lead"].search(
                [("name", "=", lead.name), ("active", "=", False)], limit=1
            )
            if not same_lead:
                lead_obj.create({"name": lead.name, "active": False})
        return super(CrmLead, self).unlink()

    def copy_data(self, default=None):
        default = dict(default or {})
        vals_list = super().copy_data(default=default)
        seq_obj = self.env["ir.sequence"]
        for vals in vals_list:
            name = vals.get("name")
            lead_type = vals.get("tks_crm_lead_type")
            partner = vals.get("partner_id")
            if name:
                existing_name = (
                    self.env["crm.lead"]
                    .search([("name", "=", name)], limit=1)
                    .mapped("name")
                )
                if name in existing_name and lead_type == "fl" and partner:
                    vals["name"] = seq_obj.next_by_code("tks.seq.crm.fl")
                elif name in existing_name and lead_type == "fl" and partner:
                    vals["name"] = seq_obj.next_by_code("tks.seq.crm.opl")
        return vals_list

    # Button
    # Override function to show Lost leads in Stage
    def action_set_lost(self, **additional_values):
        """Lost semantic: probability = 0 or active = False"""
        # res = self.action_archive()
        stage_id = self.env["crm.stage"].search([("name", "=", "Lost")], limit=1).id
        if stage_id:
            self.write(
                {
                    "stage_id": stage_id,
                }
            )
        else:
            self.write(
                {
                    "active": False,
                }
            )
        if additional_values:
            self.write(dict(additional_values))
        # return res

    def toggle_restore(self):
        activated = self.filtered(lambda lead: lead.stage_id != 6)
        archived = self.filtered(lambda lead: lead.stage_id == 6)

        if activated:
            activated.write(
                {
                    "lost_reason_id": False,
                    "stage_id": self.env["crm.stage"].browse(5).id,
                }
            )
            if activated.probability == 100:
                activated.write({"probability": 99})

    def toggle_active(self):
        res = super(CrmLead, self).toggle_active()
        activated = self.filtered(lambda lead: lead.active)
        archived = self.filtered(lambda lead: not lead.active)
        if activated:
            activated.write({"lost_reason_id": False})
            activated._compute_probabilities()
        if archived:
            for arch in archived:
                arch.write(
                    {
                        "probability": arch.tks_last_probabilty,
                        "automated_probability": arch.tks_last_probabilty,
                    }
                )
        return res
