import { Component, useState, onWillStart } from "@odoo/owl";
import { ListController } from "@web/views/list/list_controller";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks"; 
patch(ListController.prototype, {
  setup() {
        super.setup();
        this.actionService = useService("action");
        this.orm = useService("orm");   
        let uid = this.props.context.uid || this.env.user.id;      
        this.user = useState({ 
            data: this.env.user,
        });
        onWillStart(async () => {
            if (uid) {
                await this._loadUserData(uid);
            }
        });        
    },
    async _loadUserData(userId) {
        try {
            const userData = await this.orm.call(
                'res.users', // Model
                'read',      // Metode
                [[userId]],  // args: [ID yang akan dibaca]
                { fields: ['id', 'name', 'is_call_center'] } // kwargs: field yang akan diambil
            );
            if (userData && userData.length > 0) {
                this.user.data = userData[0]; 
                this.user.is_call_center = userData[0].is_call_center; 
                console.log("Data user berhasil dimuat dengan ORM:", this.user.data);
            }
        } catch (error) {
            console.error("Gagal memuat data pengguna dengan ORM:", error);
            this.user.data = this.env.user; 
        }
    },   
    async onClickCreate() {
        if (!this.user.is_call_center && this.props.resModel == 'helpdesk.ticket') {
            this.env.services.notification.add(
                "Only Is Call Center Can create helpdesk",
                {
                    title: "Access Denied",
                    type: "danger", // Menampilkan notifikasi merah
                }
            );
            return; 
        }        
        return super.onClickCreate(...arguments);     
    },

    onClickGenerateXlsx() {
        return new Promise((resolve) =>
                this.env.model.action.doAction(
                    {
                        type: "ir.actions.act_window",
                        name: "Report",
                        res_model: "cdp.xlsx.wizard",
                        view_mode: "form",
                        views: [[false, "form"]],
                        target: "new",
                    },
                    { onClose: resolve }
                )
            );
    }
});
