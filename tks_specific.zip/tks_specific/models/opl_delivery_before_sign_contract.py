from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_35_delivery_before_sign_contract_no = fields.Char('Contract No')
    tks_im_35_delivery_before_sign_contract_addendum_no = fields.Char('Addendum No')
    tks_im_35_delivery_before_sign_contract_reason = fields.Text('Reason')
    tks_im_35_delivery_before_sign_contract_expected_delivery_date = fields.Date(
        'Expected Delivery Date')
    tks_im_35_delivery_before_sign_contract_expected_return_date = fields.Date(
        'Expected Contract Return Date')    
    tks_im_35_delivery_before_sign_contract_ids = fields.One2many(
        'opl.delivery.before.sign.contract', 
        'request_id', string='OPL - Risk & Mitigatio'
    )

class OplDeliveryBeforeSignContract(models.Model):
    _name = 'opl.delivery.before.sign.contract'
    _rec_name = 'risk_mitigation'
    _description = 'OPL Delivery Before Sign Contract'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation =  fields.Selection([
        ('risk', 'Risk'), ('mitigation', 'Mitigation'),], 
        string='Item')
    remarks = fields.Text('Remarks')