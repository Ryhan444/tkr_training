from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_partial_damage_id = fields.Many2one('tks.insurance.partial.damage', string="Partial Damage")

class TksInsurancePartialDamage(models.Model):
    _name = 'tks.insurance.partial.damage'
    _description = 'Partial Damage'

    name = fields.Char(string="Partial Damage")