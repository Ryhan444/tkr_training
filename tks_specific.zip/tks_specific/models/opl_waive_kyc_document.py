from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.document_name or not line.reason or not line.risk or not line.mitigation
            for line in self.tks_im_33_waive_kyc_documen_waived_ids
        )
        if self.tks_has_tks_im_waive_kyc_document_opl != 'no' and (
            not self.tks_im_33_waive_kyc_documen_waived_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('List of Documents Waived Empty'),
                    'message': _('List of Documents Waived must be filled, and all fields must be complete.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        if any(
            line.document_name == 'other' and not line.others
            for line in self.tks_im_33_waive_kyc_documen_waived_ids
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Additional Details Missing'),
                    'message': _('If Document Name is "Other", the "Others" field must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_im_33_waive_kyc_document_waived_contract_no = fields.Char('Contract No')
    tks_im_33_waive_kyc_document_waived_addendum_no = fields.Char('Addendum No')
    tks_im_33_waive_kyc_documen_waived_ids = fields.One2many(
        'opl.waive.kyc.document.waived', 
        'request_id', string='OPL - List of Documents Waived'
    )

class OplWaiveKycDocumentListDocumentsWaived(models.Model):
    _name = 'opl.waive.kyc.document.waived'
    _rec_name = 'document_name'
    _description = 'OPL Waive KYC Document List of Documents Waived'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    document_name = fields.Selection(
        string=_("Document Name"),
        selection=[
            ("npwp", "NPWP/tax registration number"),
            ("nib", "NIB/business registry number"),
            ("ktp", "KTP/KITAS/pasport"),        
            ("establishment_deed", "Establishment Deed"),        
            ("change_bod", "Change of Bod/Boc"),        
            ("change_shareholders", "Change of Shareholders"), 
            ("change_capital", "Change of Capital"),        
            ("other", "Other Documents"),
        ],
    )
    others = fields.Text('Others Documents')
    reason = fields.Text('Reason')
    risk = fields.Text('Risk')
    mitigation = fields.Text('Mitigation')
    remarks = fields.Text('Remarks')