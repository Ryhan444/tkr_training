import { MonetaryField } from "@web/views/fields/monetary/monetary_field";
import { IntegerField } from "@web/views/fields/integer/integer_field";
import { FloatField } from "@web/views/fields/float/float_field";
import { patch } from "@web/core/utils/patch";

function getCacheKey(model, field, record) {
    const recordId = record.resId
    return `hasInput_${model}_${field}_${recordId}`;
}

function setupFieldState(fieldInstance, stateKey) {
    const { record, name } = fieldInstance.props;
    const model = record.resModel;
    const recordId = record.resId || "new";
    const cacheKey = getCacheKey(model, name, recordId);

    fieldInstance.state[stateKey] = recordId !== "new" && localStorage.getItem(cacheKey) === "true";
    if (recordId === "new") localStorage.removeItem(cacheKey);
}

function patchField(FieldClass, stateKey) {
    patch(FieldClass.prototype, {
        setup() {
            super.setup();
            setupFieldState(this, stateKey);
        },
        onInput(event) {
            super.onInput?.(event);
            this.state[stateKey] = true;
            localStorage.setItem(getCacheKey(this.props.record.resModel, this.props.name, this.props.record.resId || "new"), "true");
        },
        get value() {
            const record = super.value;
            const { record: recordObj, name, readonly } = this.props;
            const model = recordObj.resModel;
            const hasInput = this.state[stateKey] || localStorage.getItem(getCacheKey(model, name, recordObj.resId || "new")) === "true";

            if (record === 0 && model !== "crm.lead" && !hasInput && !readonly) {
                recordObj.data[name] = false;
                return false;
            }
            return record;
        }
    });
}

patchField(MonetaryField, "isInput");
patchField(IntegerField, "hasInput");
patchField(FloatField, "hasInput");
