from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    
    tks_opl_permanent_exchange_ids = fields.One2many('opl.permanent.exchange', 'request_id', string='OPL - Permanent Exchange')
    tks_opl_permanent_exchange_bb_ids = fields.One2many('opl.permanent.exchange.business.benefit', 'request_id', string='OPL - Permanent Exchange Business Benefit')
    tks_contract_no_16 = fields.Char('Contract No.')
    tks_addendum_no_16 = fields.Char('Addendum No.')
    change_reason_16 = fields.Text('Change Reason')
    change_effective_date_16 = fields.Date('Change Effective Date')
    tks_im_16_vehicle_before = fields.Char('Vehicle Before')
    tks_im_16_vehicle_after = fields.Char('Vehicle After')
    tks_im_16_year_before = fields.Char('Year Before')
    tks_im_16_year_after = fields.Char('Year After')
    tks_im_16_police_number_before = fields.Char('Police Number Before')
    tks_im_16_police_number_after = fields.Char('Police Number After')
    tks_im_16_location_before = fields.Char('Location Before')
    tks_im_16_location_after = fields.Char('Location After')
    tks_im_16_lease_rent_before = fields.Char('Lease Rent Before')
    tks_im_16_lease_rent_after = fields.Char('Lease Rent After')
    tks_im_16_lease_term_before = fields.Char('Lease Term Before')
    tks_im_16_lease_term_after = fields.Char('Lease Term After')
    tks_im_16_spread_before = fields.Float('Spread Before')
    tks_im_16_spread_after = fields.Float('Spread After')
    tks_im_16_irr_before = fields.Float('IRR Before')
    tks_im_16_irr_after = fields.Float('IRR After')

    @api.constrains(
        "tks_im_16_year_before",
        "tks_im_16_year_after",
        "tks_im_16_lease_term_before",
        "tks_im_16_lease_term_after",
    )
    def check_year_before(self):
        fields = {
            "tks_im_16_year_before": _("Year must be a Number"),
            "tks_im_16_year_after": _("Year must be a Number"),
            "tks_im_16_lease_term_before": _("Lease Term must be a Number"),
            "tks_im_16_lease_term_after": _("Lease Term must be a Number"),
        }
        for rec in self:
            for field, error_msg in fields.items():
                if getattr(rec, field) and not getattr(rec, field).isdigit():
                    raise ValidationError(error_msg)
    
    


class OplPermanentExchange(models.Model):
    _name = 'opl.permanent.exchange'
    _description = 'OPL - Permanent Exchange'
    _rec_name = 'item_id'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item_id = fields.Many2one('fal.proposal.item', string='Item')
    before = fields.Char('Before')
    after = fields.Char('After')
    
    
class OplPermanentExchangeBusinessBenefit(models.Model):
    _name = 'opl.permanent.exchange.business.benefit'
    _description = 'Permanent Exchange Business Benefit'
    
    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')