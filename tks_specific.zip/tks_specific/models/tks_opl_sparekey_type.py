from odoo import fields, models

class TksOplSparekeyType(models.Model):
    _name = 'tks.opl.sparekey.type'
    _description = 'OPL Sparekey Type'

    tks_request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    name = fields.Char(string='Name')