from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_4_reprint_item = fields.Char(string="Reprint Item")
    tks_im_4_reason_explanation = fields.Text(string=_("Reason/Explanation"))
    tks_im_4_re_release_date = fields.Date(
        string=_("Re-release Date to Customer"),
    )
    tks_im_4_risk_mitigation_ids = fields.One2many(
        comodel_name="tks.im.4.risk.mitigation",
        inverse_name="tks_im_request_id",
        string="Risk & Mitigation",
        store=True,
    )

    def action_confirm(self):
        if self.tks_has_tks_im_reprint_contract != 'no':
            risk_mitigation = [not line.risk_mitigation or not line.remarks for line in self.tks_im_4_risk_mitigation_ids]
            if not risk_mitigation:
                notification = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Risk Mitigation Empty'),
                        'message': _('Risk Mitigation must be filled.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
                return notification
            elif risk_mitigation:
                if any(i for i in risk_mitigation) == True:
                    notification = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Risk Mitigation Empty'),
                        'message': _('Risk Mitigation must be filled.'),
                        'sticky': False,
                        'type': 'warning',
                        },
                    }
                    return notification
        return super(ApprovalRequest, self).action_confirm()


class TksIM4RiskMitigation(models.Model):
    _name = "tks.im.4.risk.mitigation"
    _description = "IM 4 Risk & Mitigation"

    tks_im_request_id = fields.Many2one("approval.request", string="Approval Request", ondelete="cascade")
    risk_mitigation = fields.Selection(
        string=_("Item"),
        selection=[
            ("risk", "Risk"),
            ("mitigation", "Mitigation"),
        ],
    )

    remarks = fields.Text(string=_("Remarks"))
