from odoo import fields, models, _, api
from odoo.exceptions import ValidationError
from markupsafe import Markup

class ResUsers(models.Model):
    _inherit = "res.users"

    is_approver_editor = fields.Boolean("Is Approver Editor", default=False)
    is_sales_group = fields.Boolean("Is Sales Group", compute="get_user_groups", store=True)
    is_im_maker = fields.Boolean("Is IM Maker?", compute="get_user_groups", store=True)

    @api.depends('name')
    def _compute_signature(self):
        res = super(ResUsers, self)._compute_signature()
        for user in self:
            if user.name:
                user.signature = Markup('<p>--<br />%s</p>') % user.name
        return res
    
    @api.depends("groups_id")
    def get_user_groups(self):
        for user in self:
            user.is_sales_group = user.has_group("sales_team.group_sale_manager") or user.has_group("sales_team.group_sale_salesman_all_leads") or user.has_group("sales_team.group_sale_salesman")
            user.is_im_maker = user.has_group("tks_specific.tks_create_internal_memo")

    def cron_get_user_groups(self):
        user = self.env['res.users'].search([])
        user.get_user_groups()