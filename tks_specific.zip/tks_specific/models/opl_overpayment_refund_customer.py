from odoo import fields, models, _, api
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.invoice_no or not line.user_name or not line.date_paid or not line.remarks
            for line in self.tks_im_41_overpayment_refund_customer_proposal_ids
        )
        if self.tks_has_tks_im_overpayment_refund_to_customer != 'no' and (
            not self.tks_im_41_overpayment_refund_customer_proposal_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Overpayment Refund Lines Empty'),
                    'message': _('Overpayment Refund Lines must be filled, and all required fields must be completed.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_im_41_overpayment_refund_customer_rm_cntrct_no = fields.Char(
        'Contract No'
    )
    tks_im_41_overpayment_refund_customer_rm_addendum_no = fields.Char(
        'Addendum No'
    )
    tks_im_41_overpayment_refund_customer_risk_mitigation_bank = fields.Char(
        'Bank'
    )
    tks_im_41_overpayment_refund_customer_risk_mitigation_acc_no = fields.Char(
        'Account No',
    )
    tks_im_41_overpayment_refund_customer_risk_mitigation_acc_name = fields.Char(
        'Account Name'
    )
    tks_im_41_overpayment_refund_customer_risk_mitigation_ep_date = fields.Date(
        'Expected Payment Date'
    )    
    tks_im_41_overpayment_refund_customer_proposal_ids = fields.One2many(
        'opl.overpayment.refund.customer.proposal', 
        'request_id', string='OPL - Overpayment Refund to Customer Proposal'
    )    
    tks_im_41_overpayment_refund_customer_risk_mitigation_ids = fields.One2many(
        'opl.overpayment.refund.customer.risk.mitigation', 
        'request_id', string='OPL - Overpayment Refund to Customer Risk Mitigation'
    )

    @api.constrains("tks_im_41_overpayment_refund_customer_risk_mitigation_acc_no")
    def check_vehicle_year_before(self):
        for rec in self:
            if rec.tks_im_41_overpayment_refund_customer_risk_mitigation_acc_no and not rec.tks_im_41_overpayment_refund_customer_risk_mitigation_acc_no.isdigit():
                raise ValidationError(_("Account No must be a Number"))
    
class OplOverpaymentRefundCustomerProposal(models.Model):
    _name = 'opl.overpayment.refund.customer.proposal'
    _description = 'OPL Overpayment Refund to Customer Proposal'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    tks_currency_id = fields.Many2one(
        related='request_id.tks_currency_id'
    )
    invoice_no = fields.Char(string='Invoice No')
    user_name = fields.Char(string='User Name')
    date_paid = fields.Date(string='Date Paid')
    amount_paid = fields.Monetary(
        string='Amount Paid (IDR)',  
        currency_field="tks_currency_id",)
    amount_refund = fields.Monetary(
        string='Amount Refund  (IDR)',
         currency_field="tks_currency_id",)
    remarks = fields.Text(string='Remarks')


class OplOverpaymentRefundCustomerRiskMitigation(models.Model):
    _name = 'opl.overpayment.refund.customer.risk.mitigation'
    _description = 'OPL Overpayment Refund to Customer Risk Mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')


    