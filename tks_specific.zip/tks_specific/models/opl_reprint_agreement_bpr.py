from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_contract_no_30 = fields.Char('Contract No.')
    tks_addendum_no_30 = fields.Char('Addendum No.')
    tks_reprint_item_30 = fields.Selection([
        ('agreement', 'Master Agreement'),
        ('addendum', 'Addendum'),
    ], string='Reprint Item', default='agreement')
    tks_reason_30 = fields.Text('Reason')
    tks_re_release_date = fields.Date('Expected Re-release Date to Customer')
    tks_opl_reprint_agreement_bpr_line_ids = fields.One2many('opl.reprint.agreement.bpr', 'request_id', string='Lines OPL - Reprint Master Agreement / Addendum')
    tks_opl_reprint_agreement_bpr_risk_mitigation_line_ids = fields.One2many('opl.reprint.agreement.bpr.risk.mitigation', 'request_id', string='Lines OPL - Reprint Master Agreement / Addendum Risk Mitigation')
    
class OPLReprintItem(models.Model):
    _name = 'fal.opl.reprint.item'
    _description = 'OPL - Reprint Item'
    
    name = fields.Char('Item')
    
    
class OPLReprintAgreementBPR(models.Model):
    _name = 'opl.reprint.agreement.bpr'
    _description = 'OPL - Reprint Agreement BPR'
    _rec_name = 'reprint_item'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    reprint_item = fields.Selection([
        ('reason', 'Reason'),
        ('expected_re_release_date', 'Expected Re-release Date to Customer'),
    ], string='Reprint Item')
    addendum = fields.Text('Addendum')
    
        
class OPLReprintAgreementBPRRiskMitigation(models.Model):
    _name = 'opl.reprint.agreement.bpr.risk.mitigation'
    _description = 'OPL - Extend Booking  Risk Mitigation'

    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')