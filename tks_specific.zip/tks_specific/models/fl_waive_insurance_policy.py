from odoo import fields, models, _, api
import datetime

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.document_name or not line.reason or not line.risk or not line.mitigation
            for line in self.tks_im_13_waive_insurance_policy_list_documents_waived_ids
        )
        if self.tks_has_tks_im_waive_insurance_policy_fl != 'no' and (
            not self.tks_im_13_waive_insurance_policy_list_documents_waived_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Proposal Line Empty'),
                    'message': _('Proposal Line must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_im_13_waive_insurance_policy_proposal_contract_no = fields.Char('Contract No')
    tks_im_13_waive_insurance_policy_proposal_addendum_no = fields.Char('Addendum No')
    tks_im_13_waive_insurance_policy_list_documents_waived_ids = fields.One2many(
        'opl.waive.insurance.policy.list.documents.waived', 
        'request_id', string='OPL - List of Documents Waived'
    )


class OplWaiveInsurancePolicyListDocumentsWaived(models.Model):
    _name = 'fl.waive.insurance.policy.list.documents.waived'
    _rec_name = 'document_name'
    _description = 'FL Waive Insurance Policy List of Documents Waived'
    
    @api.depends('request_id.tks_im_13_waive_insurance_policy_list_documents_waived_ids')
    def _compute_sequence(self):
        for line in self:
            if line.request_id:
                tks_im_13_waive_insurance_policy_list_documents_waived_idss = line.request_id.tks_im_13_waive_insurance_policy_list_documents_waived_ids.sorted(lambda l: l.create_date if l.create_date else datetime.datetime.max)
                for index, tks_im_13_waive_insurance_policy_list_documents_waived_ids in enumerate(tks_im_13_waive_insurance_policy_list_documents_waived_idss, start=1):
                    tks_im_13_waive_insurance_policy_list_documents_waived_ids.sequence = index
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    document_name = fields.Text('Detail')
    reason = fields.Text('Reason')
    risk = fields.Text('Risk')
    mitigation = fields.Text('Mitigation')
    sequence = fields.Integer('No.', compute='_compute_sequence', store=True)