from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    tks_safekeep_location_23_id = fields.Many2one('opl.safekeep.location', string='Safekeep Location')
    tks_start_date_23 = fields.Date('Start Date')
    tks_end_date_23 = fields.Date('End Date')
    tks_safekeep_cost_23 = fields.Monetary('Safekeep Cost', currency_field='tks_currency_id')
    tks_safekeep_running_contract_vehicle_risk_mitigation_ids = fields.One2many('opl.safekeep.running.contract.vehicle.risk.mitigation', 'request_id', string='Lines Safekeep Running Contract Vehicle Risk and Mitigation')
    reason_23 = fields.Text('Reason')
    
class OPLSafekeepLocation(models.Model):
    _name = 'opl.safekeep.location'
    _description = 'Master Data Safekeep Location'

    name = fields.Char(string='Name')

    
class OPLExtendBookingUnitRiskMitigation(models.Model):
    _name = 'opl.safekeep.running.contract.vehicle.risk.mitigation'
    _description = 'OPL - Safekeep Running Contract Vehicle'

    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')