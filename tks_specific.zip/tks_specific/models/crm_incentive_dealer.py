from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_incentive_dealer_id = fields.Many2one('tks.incentive.dealer', string="Incentive Dealer")

class TksIncentiveDealer(models.Model):
    _name = 'tks.incentive.dealer'
    _description = 'Incentive Dealer'

    name = fields.Char(string="Incentive Dealer")