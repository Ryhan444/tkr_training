import { statusBarField, StatusBarField } from "@web/views/fields/statusbar/statusbar_field";
import { patch } from "@web/core/utils/patch";

patch(StatusBarField.prototype, {
    getAllItems() {
        const result = super.getAllItems();
        return result.filter(item => item.label !== "Lost");
    }
});