from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_trans_scheme_id = fields.Many2one('tks.trans.scheme', string="Transaction Scheme")

class TksTransScheme(models.Model):
    _name = 'tks.trans.scheme'
    _description = 'Transaction Scheme'

    name = fields.Char(string="Transaction Scheme")

