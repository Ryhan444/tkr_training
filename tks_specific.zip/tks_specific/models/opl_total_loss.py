from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_opl_total_loss_ids = fields.One2many(
        "opl.total.loss.risk.mitigation",
        "request_id",
        string="OPL - Total Loss Risk Management",
    )
    tks_tlo_category_25 = fields.Selection(
        [
            ("theft", "Theft"),
            ("damage", "Damage"),
        ], default="theft",
        string="TLO Category",
    )
    tks_contract_status_25 = fields.Selection(
        [
            ("terminated", "Terminated"),
            ("continued", "Continued with Permanent Exchange"),
        ],
        string="Contract Status",
    )
    tks_replacements_25 = fields.Selection(
        [
            (" "," "),
            ("no", "No"),
            ("yes", "Yes"),
        ],
        string="Cost / Security Deposit",
    )
    tks_incident_25 = fields.Date("Incident Date")
    tks_effective_date_25 = fields.Date("Effective Date")
    tks_replacement_unit_25 = fields.Char("Replacement Unit")
    tks_insurance_25 = fields.Selection(
        [
            ("paid", "Paid"),
            ("unpaid", "Unpaid"),
        ],
        string="Insurance",
    )
    tks_contact_no_25 = fields.Char("Contact No.")
    tks_date_paid_25 = fields.Date("Date Paid")
    tks_reason_25 = fields.Text("Reason")
    tks_city_25 = fields.Char("City")
    tks_address_25 = fields.Text("Address")
    tks_partner_25 = fields.Char(string="Contact PIC")
    tks_paid_date_25 = fields.Date("Paid Date")
    tks_reason_25 = fields.Text("Reason / Explanation")


class OplTotalLossRiskManagement(models.Model):
    _name = "opl.total.loss.risk.mitigation"
    _description = "Total Lost Risk Management"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        [
            ("risk", "Risk"),
            ("mitigation", "Mitigation"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
