from odoo import api, models, fields, _

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_5_list_document_postponed_ids = fields.One2many(
        comodel_name="tks.im.5.list.of.document.postponed",
        inverse_name="tks_im_request_id",
        string="List of Document Postponed",
    )
    
    def action_confirm(self):
        missing_fields = any(
            not line.tks_contract_no or
            not line.tks_im_5_document_name or
            not line.tks_im_5_reason or
            not line.tks_im_5_risk_mitigation or
            not line.tks_im_5_fullfilment_date or
            (line.tks_im_5_document_name == 'other' and not line.tks_im_5_other_documents)
            for line in self.tks_im_5_list_document_postponed_ids
        )
        if self.tks_has_tks_im_postpone_kyc_document_fl != 'no' and (
            not self.tks_im_5_list_document_postponed_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('List of Document Postpone Empty'),
                    'message': _('Please fill in the required fields in the List of Document Postpone.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }

        return super(ApprovalRequest, self).action_confirm()


class TksIM5PostponedDocument(models.Model):
    _name = "tks.im.5.list.of.document.postponed"
    _description = "IM 5 Document Postponed"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_contract_no = fields.Char(string="Contract No.")
    tks_im_5_document_name = fields.Selection(
        string=_("Document Name"),
        selection=[
            ("pwp_tax", "NPWP / Tax Registration Number"),
            ("ib_business", "NIB / Business Registry Number"),
            ("bl", "Business License"),
            ("ktp_pass", "KTP / KITAS / pasport"),
            ("est_deed", "Establishment Deed"),
            ("change_ob", "Change of BOD/BOC"),
            ("change_os", "Change of Shareholders"),
            ("change_oc", "Change of Capital"),
            ("other", "Other Documents"),
        ],
    )

    tks_im_5_reason = fields.Text(string=_("Reason"))
    tks_im_5_risk_mitigation = fields.Text(string=_("Risk & Mitigation"))
    tks_im_5_fullfilment_date = fields.Date(
        string=_("Fullfilment Date"),
    )
    tks_im_5_due_date = fields.Date(string="Due Date", related="tks_im_5_fullfilment_date")
    tks_im_5_other_documents = fields.Text(string="Other Documents")
    tks_im_5_remarks = fields.Text(string="Remarks")
