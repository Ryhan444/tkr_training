from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.item or
            not line.before or
            not line.after
            for line in self.tks_plate_number_ids
        )
        if self.tks_has_tks_im_changing_plate_number != 'no' and (
            not self.tks_plate_number_ids or missing_fields
        ):
            # return {
            #     'type': 'ir.actions.client',
            #     'tag': 'display_notification',
            #     'params': {
            #         'title': _('Proposal Line Empty'),
            #         'message': _('Please fill in the required fields in the Proposal Line list.'),
            #         'sticky': False,
            #         'type': 'warning',
            #     },
            # }
            raise ValidationError("Please fill in the required fields in the Proposal Line list.")
        return super(ApprovalRequest, self).action_confirm()

    
    tks_paid_by = fields.Selection([
        ('tks', 'TKS'),
        ('customer', 'Customer'),
    ], default="tks", string='Paid By')
    tks_paid_date = fields.Date(_('Paid Date'))
    tks_amount_paid = fields.Monetary('Amount Paid', currency_field='tks_currency_id')
    tks_change_reason = fields.Text('Change Reason')
    tks_effective_date = fields.Date('Effective Date')
    tks_plate_number_ids = fields.One2many('opl.changing.plate.number', 'request_id', string='OPL - Changing Plate Number')
    tks_plate_number_risk_mitigation_ids = fields.One2many('opl.changing.plate.number.risk.mitigation', 'request_id', string='OPL - Changing Plate Number Risk and Mitigation')


class FalProposalItem(models.Model):
    _name = 'fal.proposal.item'
    _description = 'Proposal Item'
    
    name = fields.Char('Name')
    details = fields.Char('Details')

class OplChangingPlateNumber(models.Model):
    _name = 'opl.changing.plate.number'
    _description = 'OPL - Changing Plate Number'
    # _rec_name = 'item_id'
    
    item = fields.Selection(string='Item', selection=[('plate','Plate Number'),('loc','Location')])
    before = fields.Char('Before')
    after = fields.Char('After')
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    
    
class OplBorrowBPKBRiskMitigation(models.Model):
    _name = 'opl.changing.plate.number.risk.mitigation'
    _description = 'OPL - Borrow BPKB Risk and Mitigation'
    _rec_name = 'risk_mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], default="risk" ,string='Item')
    remarks = fields.Text('Remarks')