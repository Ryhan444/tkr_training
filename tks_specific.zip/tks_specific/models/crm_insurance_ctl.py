from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_ctl_id = fields.Many2one('tks.insurance.ctl', string="CTL")

class TksInsuranceCtl(models.Model):
    _name = 'tks.insurance.ctl'
    _description = 'CTL'

    name = fields.Char(string="CTL")