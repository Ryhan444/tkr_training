from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_inv_top_id = fields.Many2one('tks.inv.top', string="Terms of Payment")

class TksInsurancePartialDamage(models.Model):
    _name = 'tks.inv.top'
    _description = 'Terms of Payment'

    name = fields.Char(string="Terms of Payment")