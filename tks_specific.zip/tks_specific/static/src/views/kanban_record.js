import { KanbanRecord } from "@web/views/kanban/kanban_record";
import { KanbanColumnQuickCreate } from "@web/views/kanban/kanban_column_quick_create";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { onWillStart } from "@odoo/owl";
import { user } from "@web/core/user";

patch(KanbanRecord.prototype, {
    setup() {
        super.setup();
        onWillStart(async () => {
            this.adminAccess = await user.hasGroup("sales_team.group_sale_manager");
            this.deleteImAccess = await user.hasGroup("tks_specific.tks_can_delete_im")
            this.deleteCrmAccess = await user.hasGroup("tks_specific.tks_can_delete_crm")
        });
    },

    get renderingContext() {
        const renderingContext = super.renderingContext;
        const resModel = this.props.record.resModel;
        if (!this.adminAccess && resModel === 'res.partner') {
            renderingContext.widget.deletable = false;
        }
    
        if (!this.adminAccess && resModel == 'crm.lead') {
            renderingContext.widget.deletable = false;
        }
    
        if (resModel === 'ir.attachment') {
            renderingContext.widget.deletable = false;
        }
    
        if (resModel === 'approval.request' && resModel === 'approval.request' && !this.deleteImAccess) {
            renderingContext.widget.deletable = false;
        } else if (resModel === 'approval.request' && this.props.record.data.request_status != 'new') {
            renderingContext.widget.deletable = false;
        }
    
        if (!this.deleteCrmAccess && resModel === 'crm.lead') {
            renderingContext.widget.deletable = false;
        }
        return renderingContext;
    },
})

patch(KanbanColumnQuickCreate.prototype, {
    setup() {
        super.setup();
        onWillStart(async () => {
            this.props.adminAccess = await user.hasGroup("base.group_system");
        });
    },
})
