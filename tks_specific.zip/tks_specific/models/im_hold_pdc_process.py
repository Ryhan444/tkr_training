from odoo import models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    # tks_im_7_reason_explaination_lesse = fields.Char(string=_("Reason/Explanation"))
    tks_im_7_reason_explaination_tks = fields.Text(string=_("Reason/Explanation"))
    tks_im_7_risk_mitigation = fields.Text(string=_("Risk & Mitigation"))
    tks_im_7_items_ids = fields.One2many(
        comodel_name="tks.im.7.items",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_7_data_ids = fields.One2many(
        comodel_name="tks.im.7.data",
        inverse_name="tks_im_request_id",
        string="Data",
        store=True,
    )

    tks_im_7_clearing_date_ids = fields.One2many(
        comodel_name="tks.im.7.clearing.date",
        inverse_name="tks_im_request_id",
        string="PDC Clearing Date",
        store=True,
    )

    tks_im_7_risk_mitigation_ids = fields.One2many(
        comodel_name="tks.im.7.risk.mitigation",
        inverse_name="tks_im_request_id",
        string="Risk & Mitigation",
        store=True,
    )

    def action_confirm(self):
        if self.tks_has_tks_im_hold_pdc_process != 'no':
            data_fields = [not line.tks_im_7_pdc_clearing_date_before or not line.tks_im_7_pdc_clearing_date_after or not line.tks_im_7_contract_number or not line.tks_im_7_installment_period or not line.tks_im_7_pdc_number for line in self.tks_im_7_data_ids]
            # clearing_date_fields = [not line.tks_im_7_pdc_clearing_date_before or not line.tks_im_7_pdc_clearing_date_after for line in self.tks_im_7_clearing_date_ids]
            if not data_fields:
                notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                return notification
            elif data_fields:
                if any(i for i in data_fields) == True:
                    notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _(''),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                    return notification
        return super(ApprovalRequest, self).action_confirm()

class TksIM7Data(models.Model):
    _name = "tks.im.7.data"
    _description = "TKS Im 7 Data"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_7_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_7_contract_number = fields.Char(string="Contract No.")
    tks_im_7_installment_period = fields.Date(
        string=_("Installment Period"),
    )

    tks_im_7_pdc_number = fields.Char(string="PDC No.")

    tks_im_7_pdc_amount = fields.Monetary(
        string="PDC Amount", currency_field="tks_im_7_currency_id"
    )
    tks_im_7_pdc_clearing_date_before = fields.Date(
        string=_("PDC Clearing Date Before"),
    )
    tks_im_7_pdc_clearing_date_after = fields.Date(
        string=_("PDC Clearing Date After"),
    )

class TksIM7ClearingDate(models.Model):
    _name = "tks.im.7.clearing.date"
    _description = "TKS Im 7 Clearing Date"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_7_pdc_clearing_date_before = fields.Date(
        string=_("PDC Clearing Date Before"),
    )
    tks_im_7_pdc_clearing_date_after = fields.Date(
        string=_("PDC Clearing Date After"),
    )


class TksIM9Items(models.Model):
    _name = "tks.im.7.items"
    _description = "IM 7 Items"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_7_items_id = fields.Many2one("fal.proposal.item", string=_("Items"))

    tks_im_7_items_before = fields.Char(string=_("Before"))
    tks_im_7_items_after = fields.Char(string=_("After"))

    # tks_im_7_reason_explaination = fields.Text(string=_("Reason/Explanation"))

class TksIm7RiskMitigation(models.Model):
    _name = "tks.im.7.risk.mitigation"
    _description = "IM 7 Risk & Mitigation"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        string=_("Item"), selection=[("risk", "Risk"), ("mitigation", "Mitigation")]
    )
    remarks = fields.Text(string=_("Remarks"))
