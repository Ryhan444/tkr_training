from odoo import fields, models, api
from ast import literal_eval
from odoo.exceptions import UserError


class ApprovalConfiguration(models.Model):
    _name = "cdp.approval.configuration"
    _description = "Approval Configuration"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    role = fields.Selection(
        selection=[
            ("level_3", "Approver"),
            ("level_4", "Final Approver"),
        ], string="Role", required=True, tracking=True)

    user_id = fields.Many2one("res.users", string="User", required=True, tracking=True)

    new_user_id = fields.Many2one("res.users", string="New User", required=True, tracking=True)

    status = fields.Selection(
        [
            ("draft", "Draft"),
            ("updated", "Updated"),
        ],
        string="Status",
        default="draft",
        tracking=True,
    )

    def _action_update_approval_categ(self):
        categ_ids = self.env['approval.category'].search([])
        approver_to_upadate = categ_ids.approver_ids.filtered(
            lambda a: a.tks_approvers_level == self.role and a.user_id == self.user_id
        )
        approver_to_upadate.write({
            'user_id': self.new_user_id.id
        })
        return approver_to_upadate

    def action_update_approval(self):
        self.ensure_one()
        approvals = self.env['approval.approver'].search([
            ('user_id', '=', self.user_id.id),
            ('tks_approvers_level', '=', self.role),
            ('status', 'in', ['new', 'pending', 'waiting']),
        ])

        approver_in_categ = self._action_update_approval_categ()
        if not approvals and not approver_in_categ:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Not Found',
                    'message': 'Approval not found!',
                    'type': 'warning',
                    'sticky': False,
                }
            }

        # Cukup write user_id dan role, write akan memicu method write di approval.approver
        for approval in approvals:
            if approval.user_id != self.new_user_id:
                approval.write({
                    'user_id': self.new_user_id.id,
                })
        self.write({"status": "updated"})
        # update approver in IM categ
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Success',
                'message': 'Update approval success',
                'type': 'success',
                'sticky': False,
                'next': {'type': 'ir.actions.client', 'tag': 'reload'},
            }
        }