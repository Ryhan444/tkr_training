from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_personal_accident_id = fields.Many2one('tks.insurance.personal.accident', string="Personal Accident")

class TksInsurancePersonalAccident(models.Model):
    _name = 'tks.insurance.personal.accident'
    _description = 'Personal Accident'

    name = fields.Char(string="Personal Accident")