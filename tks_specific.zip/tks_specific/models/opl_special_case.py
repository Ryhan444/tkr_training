from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    # tks_im_46_document_type_ids = fields.One2many('opl.waive.agreement.document.type', 'request_id', string='OPL - Document Type')

    tks_im_46_special_case_approval_for = fields.Char('Approval For')
    tks_im_46_special_case_effective_date = fields.Date('Effective Date')
    tks_im_46_special_case_explanation = fields.Html('Explanation')

    
    tks_im_46_special_case_business_benefit_ids = fields.One2many(
        'opl.special.case.business.benefit', 'request_id', 
        string='OPL - Business Benefit'
    )
    tks_im_46_special_case_risk_mitigation_ids = fields.One2many(
        'opl.waive.agreement.risk.mitigation', 'request_id', 
        string='OPL - Risk & Mitigation'
    )

class OplBusinessBenefit(models.Model):
    _name = 'opl.special.case.business.benefit'  
    _description = 'OPL Special Case Business Benefit'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')

class OplSpecialCase(models.Model):
    _name = 'opl.special.case.risk.mitigation'  
    _description = 'OPL Special Case Risk Mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')


