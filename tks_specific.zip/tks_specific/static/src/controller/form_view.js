/** @odoo-module */

import { registry } from "@web/core/registry";
import { formView } from "@web/views/form/form_view";
import { FormController } from '@web/views/form/form_controller';
import { useEffect } from "@odoo/owl";

class TksFormViewInherit extends FormController {
    setup() {
        super.setup()
        
        useEffect(()=>{
            this.disableForm()
        }, ()=>[this.model.root.data.tks_contact_status])

        this.onNotebookPageChange = (notebookId, page) => {
            this.disableForm()
        };
    }

    disableForm(){
        const inputElements = document.querySelectorAll(".o_form_sheet input")
        const fieldWidgets = document.querySelectorAll(".o_form_sheet .o_field_widget")
        const model = this.props.resModel
        var locked = false

        if (model == 'res.partner') {
            var locked = this.model.root.data.tks_contact_status == 'verified'
            var submit = this.model.root.data.tks_contact_status == 'submitted'

            if (locked || submit) {
                if (inputElements) inputElements.forEach(e => e.setAttribute("disabled", 1))
                if (fieldWidgets) fieldWidgets.forEach(e => e.classList.add("pe-none"))
                this.canEdit = false
            } else {
                if (inputElements) inputElements.forEach(e => e.removeAttribute("disabled"))
                if (fieldWidgets) fieldWidgets.forEach(e => e.classList.remove("pe-none"))
                this.canEdit = true
            }
        }
    }

    async beforeLeave() {
        if (this.model.root.data.tks_contact_status == 'verified') return
        super.beforeLeave()
    }

    async beforeUnload(ev) {
        if (this.model.root.data.tks_contact_status == 'verified') return
        super.beforeUnload(ev)
    }
}

const formViewInherit = {
    ...formView,
    Controller: TksFormViewInherit,
}

registry.category("views").add("tks_form_disable", formViewInherit)