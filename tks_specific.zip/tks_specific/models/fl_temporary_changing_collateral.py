from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_2_plate_number_ba_before = fields.Char(string=_("Before"))
    tks_im_2_plate_number_ba_after = fields.Char(string=_("After"))
    tks_im_2_bpkb_number_before = fields.Char(string=_("Before"))
    tks_im_2_bpkb_number_after = fields.Char(string=_("After"))
    tks_im_2_type_unit_before = fields.Char(string=_("Before"))
    tks_im_2_type_unit_after = fields.Char(string=_("After"))
    tks_im_2_chasis_number_before = fields.Char(string=_("Before"))
    tks_im_2_chasis_number_after = fields.Char(string=_("After"))
    tks_im_2_engine_number_before = fields.Char(string=_("Before"))
    tks_im_2_engine_number_after = fields.Char(string=_("After"))
    tks_im_2_os_principal_before = fields.Monetary(
        string=_("Before"),
        currency_field="tks_currency_id",
    )
    tks_im_2_os_principal_after = fields.Monetary(
        string=_("After"),
        currency_field="tks_currency_id",
    )
    tks_im_2_estimated_rv_before = fields.Monetary(
        string=_("Before"), currency_field="tks_currency_id"
    )
    tks_im_2_estimated_rv_after = fields.Monetary(
        string=_("After"), currency_field="tks_currency_id"
    )
    tks_im_2_temporary_change_start_date = fields.Date(string=_("Start Date"))
    tks_im_2_temporary_change_end_date = fields.Date(string=_("End Date"))
    tks_im_2_risk_type = fields.Selection(
        string="Risk Type",
        selection=[("bb", "Business Benefit"), ("rm", "Risk Mitigation")],
        default="bb",
    )

    tks_im_2_risk_mitigation_ids = fields.One2many(
        comodel_name="tks.im.2.risk.mitigation",
        inverse_name="tks_im_request_id",
        string="Risk & Mitigation",
        store=True,
    )

    tks_im_2_plate_number_ids = fields.One2many(
        comodel_name="tks.im.2.plate.number",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_bpkb_number_ids = fields.One2many(
        comodel_name="tks.im.2.bpkb.number",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_type_unit_ids = fields.One2many(
        comodel_name="tks.im.2.type.unit",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_chasis_number_ids = fields.One2many(
        comodel_name="tks.im.2.chasis.number",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_engine_number_ids = fields.One2many(
        comodel_name="tks.im.2.engine.number",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_os_principal_ids = fields.One2many(
        comodel_name="tks.im.2.os.principal",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_2_items_before_ids = fields.One2many(comodel_name="tks.im.2.items.before", inverse_name="tks_im_request_id", string="Items")
    tks_im_2_items_after_ids = fields.One2many(comodel_name="tks.im.2.items.after", inverse_name="tks_im_request_id", string="Items")

    def action_confirm(self):
        if self.tks_has_tks_im_temporary_changing_collateral_bpkb != 'no':
            # plate_number_fields = [not line.tks_im_2_plate_number_before or not line.tks_im_2_plate_number_after for line in self.tks_im_2_plate_number_ids.filtered(lambda x: x)]
            # bpkb_fields = [not line.tks_im_2_bpkb_number_before or not line.tks_im_2_bpkb_number_after for line in self.tks_im_2_bpkb_number_ids.filtered(lambda x: x)]
            # type_unit_fields = [not line.tks_im_2_type_unit_before or not line.tks_im_2_type_unit_after for line in self.tks_im_2_type_unit_ids.filtered(lambda x: x)]
            # engine_number_fields = [not line.tks_im_2_engine_number_before or not line.tks_im_2_engine_number_after for line in self.tks_im_2_engine_number_ids.filtered(lambda x: x)]
            # chasis_number_fields = [not line.tks_im_2_chasis_number_before or not line.tks_im_2_chasis_number_after for line in self.tks_im_2_chasis_number_ids.filtered(lambda x: x)]
            # os_principal_fields = [line.tks_im_2_os_principal_before <= 0 or line.tks_im_2_os_principal_after <= 0 for line in self.tks_im_2_os_principal_ids.filtered(lambda x: x)]
            item_fields_before = [not line.tks_vehicle_color_before or not line.tks_vehicle_year_before or not line.tks_contract_no_before or not line.tks_im_2_bpkb_number_before or not line.tks_im_2_bpkb_number_before or not line.tks_im_2_type_unit_before or not line.tks_im_2_engine_number_before or not line.tks_im_2_chasis_number_before for line in self.tks_im_2_items_before_ids.filtered(lambda x: x)]
            item_fields_after = [not line.tks_vehicle_color_after or not line.tks_vehicle_year_after or not line.tks_contract_no_after or not line.tks_im_2_bpkb_number_after or not line.tks_im_2_bpkb_number_after or not line.tks_im_2_type_unit_after or not line.tks_im_2_engine_number_after or not line.tks_im_2_chasis_number_after for line in self.tks_im_2_items_after_ids.filtered(lambda x: x)]
            if item_fields_before and item_fields_after:
                if any(i for i in item_fields_after) == True or any(i for i in item_fields_before) == True:
                    notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                    return notification
            elif not item_fields_before or not item_fields_after:
                notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                return notification
        return super(ApprovalRequest, self).action_confirm()
    
class TksIM2Items(models.Model):
    _name = "tks.im.2.items.before"
    _description = "Items"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_2_currency_id = fields.Many2one(
        "res.currency", string="Currency", related="tks_im_request_id.tks_currency_id"
    )
    tks_contract_no_before = fields.Char(string="Contract No.")
    
    tks_im_2_plate_number_before = fields.Char(string=_("Plate Number"))
    tks_im_2_bpkb_number_before = fields.Char(string=_("BPKB Number"))
    tks_im_2_type_unit_before = fields.Char(string=_("Type Unit"))
    tks_im_2_chasis_number_before = fields.Char(string=_("Chasis Number"))
    tks_im_2_engine_number_before = fields.Char(string=_("Engine Number"))
    tks_im_2_os_principal_before = fields.Monetary(
        string=_("O/S Balance"),
        currency_field="tks_im_2_currency_id",
    )
    tks_vehicle_year_before = fields.Char(string="Vehicle Year")
    tks_vehicle_color_before = fields.Char(string="Vehicle Color")

    @api.constrains("tks_vehicle_year_before")
    def check_vehicle_year_before(self):
        for rec in self:
            if rec.tks_vehicle_year_before and not rec.tks_vehicle_year_before.isdigit():
                raise ValidationError(_("Vehicle Year must be a Number"))

class TksIM2ItemsAfter(models.Model):
    _name = "tks.im.2.items.after"
    _description = "Items"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_2_currency_id = fields.Many2one(
        "res.currency", string="Currency", related="tks_im_request_id.tks_currency_id"
    )
    tks_contract_no_after = fields.Char(string="Contract No.")
    tks_im_2_plate_number_after = fields.Char(string=_("Plate Number"))
    tks_im_2_bpkb_number_after = fields.Char(string=_("BPKB Number"))
    tks_im_2_type_unit_after = fields.Char(string=_("Type Unit"))
    tks_im_2_chasis_number_after = fields.Char(string=_("Chasis Number"))
    tks_im_2_engine_number_after = fields.Char(string=_("Engine Number"))
    tks_im_2_os_principal_after = fields.Monetary(
        string=_("O/S Balance"),
        currency_field="tks_im_2_currency_id",
    )
    tks_vehicle_year_after = fields.Char(string="Vehicle Year")
    tks_vehicle_color_after = fields.Char(string="Vehicle Color")

    @api.constrains("tks_vehicle_year_after")
    def check_vehicle_year_after(self):
        for rec in self:
            if rec.tks_vehicle_year_after and not rec.tks_vehicle_year_after.isdigit():
                raise ValidationError(_("Vehicle Year must be a Number"))
    

class TksIm2PlateNumber(models.Model):
    _name = "tks.im.2.plate.number"
    _description = "IM 2 Plate Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_2_plate_number_before = fields.Char(string=_("Before"))
    tks_im_2_plate_number_after = fields.Char(string=_("After"))

class TksIm2BpkbNumber(models.Model):
    _name = "tks.im.2.bpkb.number"
    _description = "IM 2 BPKB Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_2_bpkb_number_before = fields.Char(string=_("Before"))
    tks_im_2_bpkb_number_after = fields.Char(string=_("After"))

class TksIm2TypeUnit(models.Model):
    _name = "tks.im.2.type.unit"
    _description = "IM 2 Type Unit"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_2_type_unit_before = fields.Char(string=_("Before"))
    tks_im_2_type_unit_after = fields.Char(string=_("After"))

class TksIm2ChasisNumber(models.Model):
    _name = "tks.im.2.chasis.number"
    _description = "IM 2 Chasis Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_2_chasis_number_before = fields.Char(string=_("Before"))
    tks_im_2_chasis_number_after = fields.Char(string=_("After"))

class TksIm2EngineNumber(models.Model):
    _name = "tks.im.2.engine.number"
    _description = "IM 2 Engine Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_2_engine_number_before = fields.Char(string=_("Before"))
    tks_im_2_engine_number_after = fields.Char(string=_("After"))

class TksIm2OsPrincipal(models.Model):
    _name = "tks.im.2.os.principal"
    _description = "IM 2 O/S Principal"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_2_currency_id = fields.Many2one(
        "res.currency", string="Currency", related="tks_im_request_id.tks_currency_id"
    )

    tks_im_2_os_principal_before = fields.Monetary(
        string=_("Before"),
        currency_field="tks_im_2_currency_id",
    )

    tks_im_2_os_principal_after = fields.Monetary(
        string=_("After"),
        currency_field="tks_im_2_currency_id",
    )


class TksIm2RiskMitigation(models.Model):
    _name = "tks.im.2.risk.mitigation"
    _description = "IM 2 Risk & Mitigation"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        string=_("Item"), selection=[("risk", "Risk"), ("mitigation", "Mitigation")]
    )
    business_benefit = fields.Selection(
        string=_("Item"), selection=[("bc", "Business Consideration"), ("calculation", "Calculation (if any)")]
    )
    remarks = fields.Text(string=_("Remarks"))
