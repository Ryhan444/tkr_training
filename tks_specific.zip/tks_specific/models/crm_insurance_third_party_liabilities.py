from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_third_party_liabilities_id = fields.Many2one('tks.insurance.third.party.liabilities', string="Third Party Liabilities")

class TksInsuranceThirdParty(models.Model):
    _name = 'tks.insurance.third.party.liabilities'
    _description = 'Third Party Liabilities'

    name = fields.Char(string="Third Party Liabilities")