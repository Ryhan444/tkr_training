from . import models
from . import wizard
from . import controllers
from . import report

def post_init_hook(env):
    model = env['source.inquiry']
    model_2 = env['type.inquiry']
    model_3 = env['category.type']

    default_sources = ["Email", "Phone", "Whatsapp"]
    default_type = ["Service","Claim","Marketing","Pool","Asset","Finance"]
    default_categ = ["Accident",
                    "OR"
                    ,"Crime"
                    ,"Body Repair"
                    ,"Natural Disaster"
                    ,"Quotation"
                    ,"Reimburse"
                    ,"Contract"
                    ,"Emission Test"
                    ,"Add-On"
                    ,"Barcode Request"
                    ,"Unit Delivery"
                    ,"Unit Withdrawal"
                    ,"STNK"
                    ,"BPKB"
                    ,"KIR"
                    ,"WHT Request"
                    ,"Invoice Request"]
    for src in default_sources:
        if not model.search([('name', '=', src)], limit=1):
            model.create({'name': src})
    for type_d in default_type:
        if not model_2.search([('name', '=', type_d)], limit=1):
            model_2.create({'name': type_d})
    for categ in default_categ:
        if not model_3.search([('name', '=', categ)], limit=1):
            model_3.create({'name': categ})

