from odoo import api, fields, models, _

class TksVerifyWizard(models.TransientModel):
    _name = 'tks.verify.wizard'
    _description = 'Verify Wizard'

    def _get_default_im(self):
        context = self._context
        active_id = context.get('active_id')
        if active_id:
            related_im = self.env['approval.request'].browse(active_id)
            return related_im

    tks_im_id = fields.Many2one("approval.request", "Internal Memo", default=_get_default_im)
    tks_remark = fields.Text("Remark/Comment", required=True)

    def action_confirm(self):
        self.ensure_one()
        return self.tks_im_id._action_done_1(remark=self.tks_remark)
