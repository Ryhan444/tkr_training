from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_inv_installment_type_id = fields.Many2one('tks.inv.installment.type', string="Installment Type")
    tks_inv_payment_type_id = fields.Many2one('tks.inv.payment.type', string="Payment Type")
    tks_inv_payment_type_opl_id = fields.Many2one('tks.inv.payment.type', string="Payment Type")
    tks_bank_account_fl_id = fields.Many2one('tks.bank.account', string="Bank Account")
    tks_bank_account_opl_id = fields.Many2one('tks.bank.account.opl', string="Bank Account")
    tks_inv_prorate_id = fields.Many2one('tks.inv.prorate', string="Prorate Invoice")
    tks_inv_period_id = fields.Many2one('tks.inv.period', string="Invoice Period")
    tks_inv_penalty_id = fields.Many2one('tks.inv.prorate', string="Late Payment Penalty")
    tks_inv_faktur_type_id = fields.Many2one('tks.inv.faktur.type', string="Faktur Type")
    tks_inv_faktur_code_id = fields.Many2one('tks.inv.faktur.code', string="Faktur Code")

class TksTransType(models.Model):
    _name = 'tks.inv.installment.type'
    _description = 'Installment Type'

    name = fields.Char(string="Installment Type")


class TksPaymentType(models.Model):
    _name = 'tks.inv.payment.type'
    _description = 'Payment Type'

    name = fields.Char(string="Payment Type")


class TksBankAccount(models.Model):
    _name = 'tks.bank.account'
    _description = 'Bank Account'

    name = fields.Char(string="Bank Account")

class TksBankAccountOPL(models.Model):
    _name = 'tks.bank.account.opl'
    _description = 'Bank Account'

    name = fields.Char(string="Bank Account")

class TksInvProrate(models.Model):
    _name = 'tks.inv.prorate'
    _description = 'Prorate Invoice'

    name = fields.Char(string="Prorate Invoice")

class TksInvPeriod(models.Model):
    _name = 'tks.inv.period'
    _description = 'Period Invoice'

    name = fields.Char(string="Invoice Period")


class TksFakturType(models.Model):
    _name = 'tks.inv.faktur.type'
    _description = 'Faktur Type'

    name = fields.Char(string="Faktur Type")


class TksFakturCode(models.Model):
    _name = 'tks.inv.faktur.code'
    _description = 'Faktur Code'

    name = fields.Char(string="Faktur Code")