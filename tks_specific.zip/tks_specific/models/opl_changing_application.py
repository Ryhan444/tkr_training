from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.item or
            not line.before or
            not line.after
            for line in self.tks_im_13_item_ids
        )
        if self.tks_has_tks_im_changing_application != 'no' and (
            not self.tks_im_13_item_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Proposal Line Empty'),
                    'message': _('Please fill in the required fields in the Proposal Line list.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_im_13_business_benefit_ids = fields.One2many(
        "tks.im.13.business.benefit",
        "request_id",
        string="OPL - Business Benefit",
    )

    tks_im_13_item_ids = fields.One2many(
        "tks.im.13.item",
        "request_id",
        string="OPL - Business Benefit",
    )

    tks_im_13_change_reason = fields.Text(string="Change Reason")
    tks_im_13_irr = fields.Float(string="IRR")
    tks_im_13_net_spread = fields.Float(string="Spread")


class TksIm13Item(models.Model):
    _name = "tks.im.13.item"
    _description = "Items"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("lt", "Lease Term"),
            ("lr", "Lease Rent"),
            ("cost", "Cost"),
            ("scheme", "Scheme"),
            ("ut", "Unit Type"),
            ("irr", "IRR"),
            ("net_spread", "Net Spread"),
        ],
        string="Item",
    )
    before = fields.Text('Before')
    after = fields.Text('After')


class TksIm13BusinessBenefit(models.Model):
    _name = "tks.im.13.business.benefit"
    _description = "Business Benefit"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("bc", "Business Consideration"),
            ("calculation", "Calculation (if any)"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
