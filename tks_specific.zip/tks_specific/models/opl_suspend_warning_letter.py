from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    

    tks_im_43_suspend_warning_letter_contract_no = fields.Char('Contract No')
    tks_im_43_suspend_warning_letter_addendum_no = fields.Char('Addendum No')
    tks_im_43_suspend_warning_letter_no_wl = fields.Selection(selection=[('I', 'I'),('II', 'II'),('III', 'III'),],string='Number of Warning Letter')
    tks_im_43_suspend_warning_letter_no_wl_id = fields.Many2one("tks.suspend.warning.letter", string='Number of Warning Letter')
    tks_im_43_suspend_warning_letter_invoice_number = fields.Char('Invoice Number')
    tks_im_43_suspend_warning_letter_delivery_date = fields.Date('Delivery Date')
    tks_im_43_suspend_warning_letter_aging = fields.Integer('Aging')
    tks_im_43_suspend_warning_letter_top = fields.Char('TOP')
    tks_im_43_suspend_warning_letter_schdule_pay = fields.Date('Schedule Payment')
    tks_im_43_suspend_warning_letter_postpone_start = fields.Date('Postpone Start From')
    tks_im_43_suspend_warning_letter_postpone_until = fields.Date('Postpone Until')
    tks_im_43_suspend_warning_letter_amount = fields.Monetary(
        string=_("Amount"),
        currency_field="tks_currency_id",
    )
    tks_im_43_suspend_warning_letter_re = fields.Text('Reason / Explanation')
    tks_im_43_suspend_warning_letter_ids = fields.One2many(
        'opl.suspend.warning.letter', 
        'request_id', string='OPL - Suspend Warning Letter'
    )   

class OplSuspendWarningLetter(models.Model):
    _name = 'opl.suspend.warning.letter'  
    _description = 'OPL Suspend Warning Letter'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')    
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'), ('mitigation', 'Mitigation'),
    ], string='Item', default='risk')
    remarks = fields.Text('Remarks')

class OplSuspendWarningLetter(models.Model):
    _name = "tks.suspend.warning.letter"
    _description = "Suspend Warning"

    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    name = fields.Char(string='Name')