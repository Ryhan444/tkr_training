from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_12_business_benefit_ids = fields.One2many(
        "tks.im.12.business.benefit",
        "request_id",
        string="OPL - Business Benefit",
    )

    tks_im_12_item_ids = fields.One2many(
        "tks.im.12.item",
        "request_id",
        string="OPL - Business Benefit",
    )

    tks_im_12_finance_grade = fields.Char(string="Finance Grade")
    tks_im_12_labo_unit = fields.Selection(
        string="Labo Unit?", selection=[("yes", "Yes"), ("no", "No")], default="no"
    )
    tks_im_12_top = fields.Char(string="TOP")
    tks_im_12_lease_item = fields.Char('Lease Item')
    tks_im_12_quantity = fields.Float('Quantity')
    tks_im_12_lease_rent = fields.Char('Lease Rent')
    tks_im_12_lease_principal = fields.Char('Lease Item')
    tks_im_12_purchase_price = fields.Monetary('Purchase Price', currency_field='tks_currency_id')
    tks_im_12_irr = fields.Float('IRR')
    tks_im_12_net_spread = fields.Float('Net Spread')


class TksIm12Item(models.Model):
    _name = "tks.im.12.item"
    _description = "Items"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("li", "Lease Item"),
            ("qty", "Quantity"),
            ("lr", "Lease Rent"),
            ("pr", "Purchase Price"),
            ("irr", "IRR / Spread"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")


class TksIm12BusinessBenefit(models.Model):
    _name = "tks.im.12.business.benefit"
    _description = "Business Benefit"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("bc", "Business Consideration"),
            ("calculation", "Calculation (if any)"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")
