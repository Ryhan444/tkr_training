from odoo import models, fields, api, _
from ast import literal_eval
from dateutil.relativedelta import relativedelta

class SourceInquiry(models.Model):
    _name = 'source.inquiry'

    name = fields.Char(string="Source of Inquiry")