from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    tks_car_desc_20 = fields.Char('Car Description')
    tks_pool_location_20 = fields.Char('Pool Location')
    tks_start_date_20 = fields.Date('Start Date')
    tks_end_date_20 = fields.Date('End Date')
    tks_reason_20 = fields.Text('Reason / Explanation')
    tks_opl_extend_booking_unit_risk_mitigation_ids = fields.One2many('opl.borrow.bpkb.risk.mitigation', 'request_id', string='Lines Extend Booking Risk and Mitigation')
    
class OPLExtendBookingUnitRiskMitigation(models.Model):
    _name = 'opl.extend.booking.unit.risk.mitigation'
    _description = 'OPL - Extend Booking  Risk Mitigation'

    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')