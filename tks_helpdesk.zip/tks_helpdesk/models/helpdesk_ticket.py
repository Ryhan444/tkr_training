from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
import copy
from odoo.exceptions import ValidationError, UserError


class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"
    _description = "Inquiry"

    call_center_team = fields.Many2one(
        "res.partner",
        "Call Center Team",
        default=lambda self: self.env["res.partner"].search(
            [("name", "=", "Call Center Team")]
        ),
    )
    stage_id = fields.Many2one(
        "helpdesk.stage",
        string="Stage",
        compute="_compute_user_and_stage_ids",
        store=True,
        readonly=True,
        ondelete="restrict",
        tracking=1,
        group_expand="_read_group_stage_ids",
        copy=False,
        index=True,
        domain="[('team_ids', '=', team_id)]",
    )  # drag and drop off
    name = fields.Char(default="_Draft")
    x_create_date = fields.Datetime(string="Created At", default=fields.Datetime.now)
    tks_im_customer_status = fields.Selection(
        string=_("Customer Type"),
        selection=[
            ("new", "New"),
            ("existing", "Existing"),
        ],
        tracking=True,
    )

    source_inquiry_id = fields.Many2one(
        "source.inquiry", string="Source Inquiry", tracking=True
    )

    type_inquiry_id = fields.Many2one(
        "type.inquiry", string="Type Inquiry", tracking=True
    )
    name_customer = fields.Char("Customer Name", tracking=True)
    is_service = fields.Boolean(compute="_compute_is_service")
    is_customer_new = fields.Boolean(compute="_compute_is_customer_new")
    has_external_spk = fields.Boolean(compute="_compute_has_external_spk")
    user_is_service = fields.Boolean(compute="_compute_user_is_service")
    user_is_call_center = fields.Boolean(compute="_compute_user_is_call_center")
    is_all_spk_complete = fields.Boolean(compute="_compute_is_all_spk_complete")

    cdp_is_show_repair_button = fields.Boolean(
        "show repair button",
        compute="_compute_show_repair_button_2",
        default=False,
        copy=False,
    )

    cdp_external_show_repair_button = fields.Boolean(
        "show repair button",
        compute="_compute_external_show_repair_button",
        default=False,
        copy=False,
    )

    # Override Fields
    cdp_kanban_state = fields.Selection(
        [
            ("normal", "In Progress"),
            ("done", "Release To Customer"),
            ("blocked", "Release To System"),
        ],
        string="Kanban State",
        copy=False,
        default="normal",
        required=True,
    )

    @api.depends("repair_ids", "user_is_call_center", "user_is_service")
    def _compute_external_show_repair_button(self):
        for record in self:
            state = False
            extend_repair = record.repair_ids.filtered(
                lambda x: x.cdp_service_location == "external"
                and x.cdp_repair_type == "extend"
                and x.state == "complete"
            )
            external_complete = record.repair_ids.filtered(
                lambda x: x.cdp_service_location == "external"
                and x.cdp_repair_type == "new"
                and x.state == "complete"
            )

            if any(repair for repair in extend_repair) and record.user_is_call_center:
                state = False
            elif external_complete and record.user_is_call_center:
                state = True

            record.cdp_external_show_repair_button = state

    @api.depends("repair_ids", "user_is_call_center", "user_is_service")
    def _compute_show_repair_button_2(self):
        for record in self:
            record.cdp_is_show_repair_button = False
            if record.repair_ids:
                # Get the newest repair record
                extend_repair = record.repair_ids.filtered(
                    lambda x: x.cdp_service_location == "external"
                    and x.cdp_repair_type == "extend"
                    and x.state == "released"
                )

                external_released = record.repair_ids.filtered(
                    lambda x: x.cdp_service_location == "external"
                    and x.cdp_repair_type == "new"
                    and x.state == "released"
                )
                if extend_repair and record.user_is_call_center:
                    record.cdp_is_show_repair_button = True
                elif external_released and record.user_is_call_center:
                    record.cdp_is_show_repair_button = True

                if (
                    all(
                        repair.cdp_service_location
                        in ["inhouse", "storing", "external"]
                        for repair in record.repair_ids
                    )
                    and record.user_is_service
                ):
                    record.cdp_is_show_repair_button = True

    def _compute_is_all_spk_complete(self):
        for record in self:
            spk = False

            if record.repair_ids:
                inhouse_storing = all(
                    spk.state == "complete"
                    for spk in record.repair_ids.filtered(
                        lambda x: x.cdp_service_location in ["inhouse", "storing"]
                    )
                )
                external = any(
                    spk.state == "complete"
                    for spk in record.repair_ids.filtered(
                        lambda x: x.cdp_service_location == "external"
                    )
                )
                canceled_spk = any(spk.state == "cancel" for spk in record.repair_ids)
                if inhouse_storing:
                    spk = inhouse_storing
                elif external:
                    spk = external
                elif canceled_spk:
                    spk = canceled_spk

            if record.stage_id.id == 6:
                spk = True

            record.is_all_spk_complete = spk

    def _compute_user_is_call_center(self):
        for record in self:
            record.user_is_call_center = self.env.user.is_call_center

    @api.onchange("type_inquiry_id")
    def onchange_type_inquiry_id(self):
        for rec in self:
            rec.category_id = False
            if rec.type_inquiry_id:
                rec.name = rec.type_inquiry_id.name
            is_call_center = self.env.user.is_call_center
            if rec.type_inquiry_id and is_call_center:
                rec.cdp_responsibles = self.env.user

    @api.depends("is_service", "tks_im_customer_status")
    def _compute_is_customer_new(self):
        for record in self:
            record.is_customer_new = (
                not record.is_service and record.tks_im_customer_status == "new"
            )

    def _compute_has_external_spk(self):
        for helpdesk in self:
            helpdesk.has_external_spk = bool(
                helpdesk.repair_ids.filtered(
                    lambda x: x.cdp_service_location == "external"
                    and x.state == "released"
                )
                and helpdesk.user_is_call_center
            )

    @api.onchange(
        "is_service",
        "is_marketing_oth",
        "is_marketing",
        "is_marketing_only",
        "type_inquiry_id",
    )
    def _onchange_tks_im_customer_status(self):
        if not self.type_inquiry_id:
            self.tks_im_customer_status = None
        elif (
            self.type_inquiry_id.name == "Marketing"
            and self.category_id.name == "Quotation"
        ):
            self.tks_im_customer_status = None
        else:
            self.tks_im_customer_status = "existing"

    date_close = fields.Datetime("Closed Date", tracking=True)

    is_reject = fields.Boolean(compute="_compute_is_reject")

    @api.depends("stage_id")
    def _compute_is_reject(self):
        for record in self:
            record.is_reject = False
            if (
                record.stage_id.id == self.env.ref("helpdesk.stage_in_progress").id
                and record.repairs_count == 0
            ):
                record.is_reject = True
            elif record.stage_id.id == self.env.ref("tks_helpdesk.stage_reject").id:
                record.is_reject = True
            elif (
                record.stage_id.id == self.env.ref("helpdesk.stage_in_progress").id
                and record.repairs_count > 0
            ):
                record.is_reject = False
            else:
                record.is_reject = False

    def button_reject_ticket(self):
        for rec in self:
            rec.sudo().write(
                {
                    "stage_id": self.env.ref("tks_helpdesk.stage_reject").id,
                }
            )
            rec.cdp_reject_date = fields.Datetime.now()

    def _prepare_spk_default_value(self, old_spk):
        if old_spk.cdp_service_location == "external":
            vals = {
                "default_partner_id": old_spk.partner_id.id,
                "default_company_id": old_spk.company_id.id,
                "default_cdp_spk_type": old_spk.cdp_spk_type,
                "default_cdp_vendor_state_id": old_spk.cdp_vendor_state_id.id,
                "default_cdp_city_id": old_spk.cdp_city_id.id,
                "default_cdp_kilometer": self.kilometer,
                "default_cdp_company_vendor_id": old_spk.cdp_company_vendor_id.id,
                "default_cdp_vendor_id": old_spk.cdp_vendor_id.id,
                "default_cdp_child_workshop_id": old_spk.cdp_child_workshop_id.id,
                "default_cdp_related_spk": old_spk.id,
                "default_cdp_repair_type": "extend",
                "default_cdp_service_location": old_spk.cdp_service_location,
                "default_move_ids": [
                    (
                        0,
                        0,
                        {
                            "name": move.name,
                            "product_id": move.product_id.id,
                            "cdp_scope_id": move.cdp_scope_id.id,
                            "cdp_category_ids": move.cdp_category_ids.id,
                            "cdp_part_description": move.cdp_part_description,
                        },
                    )
                    for move in old_spk.move_ids
                ],
                "default_cdp_approval_approvers_ids": [
                    (
                        0,
                        0,
                        {
                            "cdp_approver_level_repair": approver.cdp_approver_level_repair,
                            "user_id": approver.user_id.id,
                        },
                    )
                    for approver in old_spk.cdp_approval_approvers_ids
                ],
                "default_cdp_need_estimation_cost": old_spk.cdp_need_estimation_cost,
                "default_cdp_currency_id": old_spk.cdp_currency_id.id,
                "default_cdp_alternative_vendor_ids": [
                    (
                        0,
                        0,
                        {
                            "cdp_alternative": alt.cdp_alternative,
                            "cdp_vendor_id": alt.cdp_vendor_id.id,
                            "cdp_est_cost": alt.cdp_est_cost,
                        },
                    )
                    for alt in old_spk.cdp_alternative_vendor_ids
                ],
                "default_cdp_need_budget": old_spk.cdp_need_budget,
                "default_cdp_total_budget_in_app": old_spk.cdp_total_budget_in_app,
                "default_cdp_cost_from_prev_contract": old_spk.cdp_cost_from_prev_contract,
                "default_cdp_cost_from_current_contract": old_spk.cdp_cost_from_current_contract,
                "default_cdp_estimation_cost": old_spk.cdp_estimation_cost,
                "default_cdp_profit_loss": old_spk.cdp_profit_loss,
                "default_cdp_description": old_spk.cdp_description,
            }
        else:
            vals = {
                "default_partner_id": old_spk.partner_id.id,
                "default_company_id": old_spk.company_id.id,
                "default_cdp_repair_type": "new",
                "default_cdp_description": old_spk.cdp_description,
            }
        return vals

    def action_repair_order_form(self):
        # cluedoo override
        res = super(HelpdeskTicket, self).action_repair_order_form()
        for rec in self:
            # cari repair yg BELUM done/complete
            not_done = rec.repair_ids.filtered(
                lambda r: r.state not in ("done", "complete", "released")
                and r.id == max(rec.repair_ids.mapped("id"))
            )
            external_not_done = rec.repair_ids.filtered(
                lambda r: r.state not in ("complete")
                and r.cdp_service_location == "external"
                and r.id == max(rec.repair_ids.mapped("id"))
            )
            # if not_done:
            #     raise UserError(
            #         _(
            #             "You cannot create new repair this ticket because some repairs are not completed yet."
            #         )
            #     )

            # if rec.has_external_spk and rec.user_is_service and external_not_done:
            #     raise UserError(
            #         _(
            #             "You cannot create new repair this ticket because some repairs are not completed yet."
            #         )
            #     )

            res["context"]["default_cdp_kilometer"] = self.kilometer
            if not rec.has_external_spk:
                res["context"]["default_cdp_repair_type"] = "new"
                old_spk_inh_sto = rec.repair_ids.filtered(
                    lambda x: x.cdp_service_location in ["inhouse", "storing"]
                    and x.state == "complete"
                    and x.id == max(rec.repair_ids.mapped("id"))
                )
                if old_spk_inh_sto:
                    new_vals = rec._prepare_spk_default_value(old_spk_inh_sto)
                    res["context"].update(new_vals)
            else:
                old_spk = rec.repair_ids.filtered(
                    lambda x: x.cdp_service_location == "external"
                    and x.state == "released"
                    and x.id
                    == max(
                        rec.repair_ids.filtered(
                            lambda x: x.cdp_service_location == "external"
                            and x.state == "released"
                        ).mapped("id")
                    )
                )

                if old_spk:
                    new_vals = rec._prepare_spk_default_value(old_spk)
                    new_vals.update({"default_cdp_repair_type": "extend"})
                    res["context"].update(new_vals)

            res["context"]["default_partner_id"] = rec.partner_id.id
        return res

    def button_close_ticket(self):
        for rec in self:
            # cari repair yg BELUM done/complete
            not_done = rec.repair_ids.filtered(
                lambda r: r.state not in ("done", "complete", "cancel")
            )
            if not_done:
                raise UserError(
                    _(
                        "You cannot close this ticket because some repairs are not completed yet."
                    )
                )
            user_call_center = self.env.user.is_call_center
            if not user_call_center:
                raise UserError(_("Only call center can close."))

            # kalau semua repair sudah selesai
            rec.sudo().write(
                {
                    "date_close": fields.Datetime.now(),
                    "stage_id": self.env.ref("helpdesk.stage_solved").id,
                }
            )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("type_inquiry_id"):
                type_inquiry = self.env["type.inquiry"].browse(vals["type_inquiry_id"])
                if type_inquiry and type_inquiry.name.lower() != "marketing":
                    vals["tks_im_customer_status"] = "existing"
                else:
                    vals["tks_im_customer_status"] = False
            user_call_center = self.env.user.is_call_center
            if not user_call_center:
                raise UserError(_("Only Call Center Can Create Helpdesk."))
        return super().create(vals_list)

    def write(self, vals):
        if vals.get("type_inquiry_id"):
            # cek dulu service dari master
            type_inquiry = self.env["type.inquiry"].browse(vals["type_inquiry_id"])
            if type_inquiry and type_inquiry.name.lower() != "marketing":
                vals["tks_im_customer_status"] = "existing"
        return super().write(vals)

    @api.depends("type_inquiry_id")
    def _compute_is_service(self):
        for record in self:
            record.is_service = False
            if (
                record.type_inquiry_id.name == "Service"
                or record.type_inquiry_id.name == "service"
            ):
                record.is_service = True
            else:
                record.is_service = False

    pic_name = fields.Char(string="PIC Name", tracking=True)

    pic_number = fields.Char(string="PIC Contact Number", tracking=True)

    # field specific type service
    plate_number = fields.Char(string="Plate Number", tracking=True)
    brand = fields.Char("Brand", tracking=True)
    type_details_service = fields.Char(string="Type", tracking=True)
    year = fields.Integer("Year", tracking=True)

    kilometer = fields.Float(string="Kilometer", tracking=True)
    rent_status = fields.Char("Rent Status", tracking=True)
    registered_area = fields.Char("Registered Area", tracking=True)
    actual_location = fields.Char("Actual Location", tracking=True)
    desciption_service = fields.Text("Description", tracking=True)
    cdp_color = fields.Char(string="Color", tracking=True)
    is_responsible = fields.Char(
        string="Is Responsible", tracking=True, compute="_compute_is_responsible"
    )
    cdp_responsible = fields.Char(string="Responsible", tracking=True)

    cdp_responsibles = fields.Many2one(
        "res.users",
        string="Responsible",
        tracking=True,
        compute="_get_responsible_user",
        store=True,
    )

    pic_call_center = fields.Char(
        "PIC Call Center",
        compute="_get_pic_call_center",
        inverse="_inverse_pic_call_center",
        tracking=True,
        store=True,
    )

    @api.constrains("kilometer")
    def _check_kilometer_required(self):
        for rec in self:
            if (
                rec.is_claim
                or rec.is_service
                or rec.is_asset
                or rec.is_finance
                or rec.is_barcode_request
                or rec.is_unit_delivery
                or rec.is_marketing_oth
            ) and not rec.kilometer:
                raise ValidationError("Kilometer is required for this type of request.")

    @api.constrains("pic_name_1", "pic_contact")
    def _check_pic_fields(self):
        for rec in self:
            if rec.pic_name_1 and any(ch.isdigit() for ch in rec.pic_name_1):
                raise ValidationError("PIC Name cannot contain numbers.")

            if rec.pic_contact and any(ch.isalpha() for ch in rec.pic_contact):
                raise ValidationError("PIC Contact cannot contain letters.")

    @api.constrains("pic_number")
    def constrains_pic_number(self):
        for ticket in self:
            if ticket.pic_number:
                region_code = ticket.pic_number[:3]
                id_code = ticket.pic_number[:2]

                if (region_code == "+62" and ticket.pic_number[3:].isdigit()) or (
                    id_code == "08" and ticket.pic_number[2:].isdigit()
                ):
                    continue
                elif (region_code == "+62" and not ticket.pic_number[3:].isdigit()) or (
                    id_code == "08" and not ticket.pic_number[2:].isdigit()
                ):
                    raise ValidationError(_("Mobile number can only contain numbers"))
                elif region_code != "+62" or id_code != "08":
                    raise ValidationError(
                        _("Mobile number can only start with '+62' or '08'")
                    )
                elif not ticket.pic_number.isdigit():
                    raise ValidationError(_("Mobile number can only contain numbers"))

    @api.depends("is_responsible")
    def _get_pic_call_center(self):
        for ticket in self:
            pic_call_center = ""
            if ticket.is_responsible == "True":
                pic_call_center = self.env.user.name
            else:
                pic_call_center = ticket.pic_call_center
            ticket.pic_call_center = pic_call_center

    def _inverse_pic_call_center(self):
        for ticket in self:
            pic_call_center = ""
            if ticket.is_responsible == "True":
                pic_call_center = self.env.user.name
            else:
                pic_call_center = ticket.pic_call_center
            ticket.pic_call_center = pic_call_center

    @api.depends("is_responsible", "user_is_call_center", "stage_id")
    def _get_responsible_user(self):
        for ticket in self:
            if ticket.is_responsible == "True" or ticket.user_is_call_center:
                ticket.cdp_responsibles = self.env.user.id
            else:
                ticket.cdp_responsibles = False

    @api.depends("stage_id")
    def _compute_user_is_service(self):
        for record in self:
            record.user_is_service = False
            records_responsible = self.env.user.is_service
            if records_responsible:
                record.user_is_service = True
            else:
                record.user_is_service = False

    @api.depends("stage_id")
    def _compute_is_responsible(self):
        for record in self:
            record.is_responsible = False
            # ini mawardi dan wisnu
            mawardi_and_wisnu = ["mawardi@takari.co.id", "wisnu.gunadi@takari.co.id"]
            new_domain = [("email", "in", mawardi_and_wisnu)]
            records_responsible = self.env["res.users"].sudo().search(new_domain)
            if self.env.user in records_responsible:
                record.is_responsible = True
            else:
                record.is_responsible = False

    date_submit = fields.Datetime("Date of Submitted", tracking=True)

    def func_name_seq(self):
        for tk in self:
            if tk.type_inquiry_id or tk.name == "" or not tk.name:
                tk.write(
                    {
                        "name": self.sudo()
                        .env["ir.sequence"]
                        .next_by_code("helpdesk." + tk.type_inquiry_id.name.lower())
                    }
                )

    def button_submit(self):
        for rec in self:
            if not rec.desciption_service:
                raise ValidationError("Please your input Description")
            elif not rec.is_service and not rec.department_id:
                raise ValidationError("Please your input Escalate to")
            elif rec.is_service and not rec.usr_id:
                raise ValidationError("Please your input Escalate to")
            elif not rec.pic_call_center:
                raise ValidationError("Please your input PIC Call Center")
            elif rec.is_service:
                rec.write(
                    {
                        "stage_id": self.env.ref("helpdesk.stage_in_progress").id,
                        "date_submit": fields.Datetime.now(),
                    }
                )
            else:
                rec.write(
                    {
                        "stage_id": self.env.ref("helpdesk.stage_solved").id,
                        "date_submit": fields.Datetime.now(),
                        "date_close": fields.Datetime.now(),
                    }
                )

            rec.func_name_seq()

            if rec.is_pool and rec.is_unit_delivery:
                rec.cdp_ref_inq = self.sudo().env["ir.sequence"].next_by_code("spk.exp")

            template = self.env.ref("tks_helpdesk.cdp_email_template_new_inquiry_spk")
            if template:
                template.with_context(notify_followers=False).send_mail(
                    self.id, force_send=True
                )

            if rec.usr_id:
                rec.with_context(from_spk_inq=True).activity_schedule(
                    "mail.mail_activity_data_todo",
                    user_id=rec.usr_id.id,
                )

    def button_print_preview(self):
        self.ensure_one()
        report = "tks_helpdesk.action_spkl_pool_report"
        filename = f"{self.name or 'Inquiry'}_{self.id}.pdf"
        return {
            "type": "ir.actions.act_url",
            "target": "new",
            "url": f"/report/pdf/{report}/{self.id}?download=false&filename={filename}",
        }

    def button_print_inquiry(self):
        self.ensure_one()
        report = "tks_helpdesk.action_spkl_pool_report"
        return self.env.ref(report).report_action(self)

    department_id = fields.Many2one(
        "hr.department", string="Escalate to", tracking=True
    )

    usr_id = fields.Many2one("res.users", string="Escalate to", tracking=True)

    category_id = fields.Many2one(
        "category.type", string="Category", tracking=True, default=False
    )

    is_inprogress = fields.Boolean(
        string="Inprogress", compute="_compute_is_inprogress"
    )

    @api.depends("stage_id")
    def _compute_is_inprogress(self):
        for record in self:
            if record.stage_id.id == self.env.ref("helpdesk.stage_in_progress").id:
                record.is_inprogress = True
            elif record.stage_id.id == self.env.ref("tks_helpdesk.stage_reject").id:
                record.is_inprogress = True
            else:
                record.is_inprogress = False

    attach_1 = fields.Binary("Attachment")
    attach_2 = fields.Binary("Attachment")
    attach_3 = fields.Binary("Attachment")

    # helper booleans
    is_claim = fields.Boolean(compute="_compute_inquiry_flags")
    is_asset = fields.Boolean(compute="_compute_inquiry_flags")
    is_finance = fields.Boolean(compute="_compute_inquiry_flags")
    is_pool = fields.Boolean(compute="_compute_inquiry_flags")
    is_marketing = fields.Boolean(compute="_compute_inquiry_flags")
    is_marketing_oth = fields.Boolean(compute="_compute_inquiry_flags")
    is_marketing_only = fields.Boolean(compute="_compute_inquiry_flags")

    is_barcode_request = fields.Boolean(compute="_compute_inquiry_flags")
    is_unit_delivery = fields.Boolean(compute="_compute_inquiry_flags")
    is_cust_pool = fields.Boolean(compute="_compute_is_cust_pool", store=True)

    # extra fields
    pic_name_1 = fields.Char("PIC Name")
    pic_contact = fields.Char("PIC Contact")
    relocation_address = fields.Char("Relocation Address")
    cdp_vendor_name = fields.Char("Vendor Name")
    cdp_vendor_address = fields.Char("Vendor Address")
    cdp_ref_inq = fields.Char("SPK ID")
    cdp_req_non_serv_inq_id = fields.Many2one("helpdesk.ticket", "Ref Inquiry ID")
    cdp_expired_date = fields.Datetime(
        "Expired Date", compute="_compute_expired_date", store=True
    )
    cdp_reject_date = fields.Datetime("Reject Date")

    @api.depends("date_submit")
    def _compute_expired_date(self):
        for rec in self:
            exp_date = False
            if rec.date_submit and rec.is_pool and rec.is_unit_delivery:
                exp_date = rec.date_submit + relativedelta(days=7)
            rec.cdp_expired_date = exp_date

    @api.depends("type_inquiry_id", "category_id")
    def _compute_inquiry_flags(self):
        for rec in self:
            rec.is_claim = rec.type_inquiry_id.name == "Claim"
            rec.is_asset = rec.type_inquiry_id.name == "Asset"
            rec.is_finance = rec.type_inquiry_id.name == "Finance"
            rec.is_pool = rec.type_inquiry_id.name == "Pool"
            rec.is_marketing = (
                rec.type_inquiry_id.name == "Marketing"
                and rec.category_id.name == "Quotation"
            )
            rec.is_barcode_request = (
                rec.is_pool and rec.category_id.name == "Barcode Request"
            )
            rec.is_unit_delivery = (
                rec.is_pool
                and rec.category_id.name == "Unit Delivery"
                or rec.category_id.name == "Unit Withdrawal"
            )
            rec.is_marketing_oth = (
                rec.type_inquiry_id.name == "Marketing"
                and rec.category_id.name != "Quotation"
            )
            rec.is_marketing_only = rec.type_inquiry_id.name == "Marketing"

    @api.depends("partner_id")
    def _compute_is_cust_pool(self):
        if self.partner_id and (
            self.partner_id.name == "Customer Pool"
            or self.partner_id.name == "Tks Pool"
            or self.partner_id.name == "TKS Pool"
        ):
            self.is_cust_pool = True
        else:
            self.is_cust_pool = False

    duration_tracking_display = fields.Char(
        string="Duration (readable)",
        compute="compute_duration_tracking_display",
        store=False,
    )
    total_duration_tracking = fields.Char(
        string="Total Duration (readable)",
        compute="compute_duration_tracking_display",
        store=False,
    )

    @api.depends("duration_tracking", "stage_id")
    def compute_duration_tracking_display(self):
        for rec in self:
            val = rec.duration_tracking or {}
            total_aging = 0
            if not val:
                rec.duration_tracking_display = ""
                continue
            stage_id = rec.stage_id.id if rec.stage_id else False
            if not stage_id:
                rec.duration_tracking_display = ""
                continue
            seconds = 0
            if isinstance(val, dict):
                seconds = int(val.get(stage_id) or val.get(str(stage_id)) or 0)
                for k, v in val.items():
                    if k in ["1", "2"]:
                        total_aging += int(v)

            days = seconds // 86400
            total_days = total_aging // 86400
            # hours = (seconds % 86400) // 3600
            # minutes = (seconds % 3600) // 60

            if rec.stage_id.id in [1, 2]:
                rec.duration_tracking_display = f"{int(days)}d"
            else:
                rec.duration_tracking_display = f"0d"

            rec.total_duration_tracking = f"{int(total_days)}d"
            # elif hours:
            #     rec.duration_tracking_display = f"{int(hours)}h"
            # else:
            #     rec.duration_tracking_display = f"{int(minutes)}m"

    def action_view_repairs(self):
        action = super().action_view_repairs()
        action["context"].update({"create": False})
        return action
