from odoo import fields, models, _, api


class IndustryScore(models.Model):
    _name = "tks.res.partner.industry.score"
    _order = "name"
    _description = "Industry Score"

    tks_sequence = fields.Integer(default=1)
    name = fields.Char(string=_("Name"))
