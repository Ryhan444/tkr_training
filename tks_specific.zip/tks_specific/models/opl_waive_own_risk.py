from odoo import fields, models, _, api
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    
    @api.depends('tks_im_45_waive_own_risk_amount','tks_im_45_waive_own_risk_waived')
    def _get_payable_amount(self):
        for rec in self:
            rec.tks_im_45_waive_own_risk_payable = rec.tks_im_45_waive_own_risk_amount - rec.tks_im_45_waive_own_risk_waived
            if rec.tks_im_45_waive_own_risk_waived > rec.tks_im_45_waive_own_risk_amount:
                raise ValidationError("Amount after exceeding amount before")
    
    @api.depends('tks_im_45_waive_own_risk_amount', 'tks_im_45_waive_own_risk_waived')
    def _get_waived_percentage(self):
        for rec in self:
            if rec.tks_im_45_waive_own_risk_amount:
                if rec.tks_im_45_waive_own_risk_waived:
                    amount = (rec.tks_im_45_waive_own_risk_waived / rec.tks_im_45_waive_own_risk_amount) * 100
                    rec.tks_im_45_waived_percentage = amount
                else:
                    rec.tks_im_45_waived_percentage = 0
            else:
                rec.tks_im_45_waived_percentage = 0
                
                
    @api.depends('tks_im_45_waive_own_risk_payable', 'tks_im_45_waive_own_risk_amount')
    def _get_payable_percentage(self):
        for rec in self:
            if rec.tks_im_45_waive_own_risk_amount:
                if rec.tks_im_45_waive_own_risk_amount:
                    amount = (rec.tks_im_45_waive_own_risk_payable / rec.tks_im_45_waive_own_risk_amount) * 100
                    rec.tks_im_45_payable_percentage = amount
            else:
                rec.tks_im_45_payable_percentage = 0
    
    tks_im_45_waived_percentage = fields.Float('Waived Percentage', compute='_get_waived_percentage', store=True)
    tks_im_45_payable_percentage = fields.Float('Payable Percentage', compute='_get_payable_percentage', store=True)
    
    
    tks_im_45_waive_own_risk_contract_no = fields.Char('Contract No')
    tks_im_45_waive_own_risk_addendum_no = fields.Char('Addendum No')
    tks_im_45_waive_own_risk_amount = fields.Monetary(
        string=_("Total Own Risk Amount"),
        currency_field="tks_currency_id",
    )
    tks_im_45_waive_own_risk_waived = fields.Monetary(
        string=_("Waived"),
        currency_field="tks_currency_id",
    )
    tks_im_45_waive_own_risk_payable = fields.Monetary(
        string=_("Payable"),
        currency_field="tks_currency_id", compute='_get_payable_amount', store=True
    )
    
    tks_im_45_waive_own_risk_before_invoice_no = fields.Char('Invoice No Before')
    tks_im_45_waive_own_risk_after_invoice_no = fields.Char('Invoice No After')
    tks_im_45_waive_own_risk_period_from = fields.Date('Period From')
    tks_im_45_waive_own_risk_period_to = fields.Date('Period To')
    tks_im_45_waive_own_risk_expected_pay_date = fields.Date('Expected Pay Date')
    tks_im_45_waive_own_risk_lessee = fields.Char('Lessee:')
    tks_im_45_waive_own_risk_tks= fields.Char('TKS:')
    tks_im_45_waive_own_risk_business_risk_mitigation = fields.Text('Risk & Mitigation')