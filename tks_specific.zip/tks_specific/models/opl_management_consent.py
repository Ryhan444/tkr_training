from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    
    def action_confirm(self):
        missing_consent_line_fields = any(
            not line.debtor or not line.collectability or not line.creditor or not line.risk_mitigation
            for line in self.tks_opl_management_consent_line_ids
        )
        missing_consent2_line_fields = any(
            not line.flag or not line.checking or not line.details or not line.risk_mitigation
            for line in self.tks_opl_management_consent2_line_ids
        )
        if (
            self.tks_has_tks_im_management_consent != 'no' 
            and self.tks_im_opl_management_consent != 'risk_compliance'
            and not self.tks_opl_management_consent_line_ids
            and self.tks_checking_date_26
        ) or (self.tks_im_opl_management_consent != 'risk_compliance' and missing_consent_line_fields):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Credit Bureau Collectability Result Empty'),
                    'message': _('Credit Bureau Collectability Result must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        if (
            (self.tks_has_tks_im_management_consent != 'no' and self.tks_im_opl_management_consent != 'credit_bureau')
            and not self.tks_opl_management_consent2_line_ids
        ) or (self.tks_im_opl_management_consent != 'credit_bureau' and missing_consent2_line_fields):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Risk Compliance Empty'),
                    'message': _('Risk Compliance must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_checking_date_26 = fields.Date("Checking Date")
    tks_credit_bureau_name = fields.Selection(
        [
            ("slik", "SLIK"),
            ("pefindo", "Pefindo"),
        ],
        default="slik",
        string="Credit  Bureau Name",
    )
    tks_opl_management_consent_line_ids = fields.One2many(
        "opl.management.consent.bpr",
        "request_id",
        string="Lines OPL - Management Consent BPR",
    )
    tks_opl_management_consent2_line_ids = fields.One2many(
        "opl.management.consent.bpr2",
        "request_id",
        string="Lines OPL - Management Consent BPR2",
    )


class OplManagementConsentBPR(models.Model):
    _name = "opl.management.consent.bpr"
    _description = "OPL - Management Consent BPR"
    _rec_name = "sequence"

    @api.depends("request_id")
    def _compute_number(self):
        """Function to compute line numbers"""
        for req in self.mapped('request_id'):
            sequence = 1
            if req.tks_opl_management_consent_line_ids:
                for lines in req.tks_opl_management_consent_line_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ''

    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    sequence = fields.Integer(string="No.", compute="_compute_number")
    debtor = fields.Text('Debtor')
    collectability = fields.Text('Collectability/Restructure')
    creditor = fields.Text('Creditor')
    risk_mitigation = fields.Text('Risk & Mitigation')
    pic_id = fields.Many2one('res.users', string='PIC', domain=[('is_im_maker', '=', True)])
    
class OplManagementConsentBPR2(models.Model):
    _name = "opl.management.consent.bpr2"
    _description = "OPL - Management Consent BPR 2"
    _rec_name = "sequence"

    @api.depends("request_id")
    def _compute_number(self):
        """Function to compute line numbers"""
        for req in self.mapped('request_id'):
            sequence = 1
            if req.tks_opl_management_consent2_line_ids:
                for lines in req.tks_opl_management_consent2_line_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ''

    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    sequence = fields.Integer(string="No.", compute="_compute_number")
    flag = fields.Selection([
        ('dow', 'Dow Jones'),
        ('sipp', 'SIPP-PN'),
        ('dttot', 'DTTOT'),
    ], string='Flag')
    checking = fields.Text('Checking Result')
    details = fields.Text('Details')
    risk_mitigation = fields.Text('Risk & Mitigation')