from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_inv_billing_type_id = fields.Many2one('tks.inv.billing.type', string="Billing Type")

class TksInsurancePartialDamage(models.Model):
    _name = 'tks.inv.billing.type'
    _description = 'Billing Type'

    name = fields.Char(string="Billing Type")