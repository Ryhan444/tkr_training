from odoo import models, fields, api


class ResUsers(models.Model):
    _inherit = "res.users"

    is_service = fields.Boolean(
        string="Is Service",
    )
    is_call_center = fields.Boolean(string='Is call center')   
