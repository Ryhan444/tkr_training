from odoo import models, fields, _
from odoo.exceptions import UserError


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_10_approval_for = fields.Text(
        string=_("Approval For"),
    )
    tks_im_10_period_from = fields.Date(string="Period")
    tks_im_10_period_to = fields.Date(string="Period")
    tks_im_10_exceutive_summary = fields.Html(string=_("Executive Summary"))

    def action_confirm(self):
        if self.tks_has_tks_im_tks_program != 'no' and not self.attachment_ids.filtered(lambda x: x.description == 'attach documents'):
            raise UserError(_("You have to attach at least one document."))
        return super(ApprovalRequest, self).action_confirm()
