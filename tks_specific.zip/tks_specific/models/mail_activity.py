# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields
from odoo.addons.mail.tools.discuss import Store


class MailActivity(models.Model):
    _inherit = "mail.activity"
    
    #super override
    def _to_store(self, store: Store):
        for activity in self:
            data = activity.read()[0]
            data["mail_template_ids"] = [
                {"id": mail_template.id, "name": mail_template.name}
                for mail_template in activity.mail_template_ids
            ]
            data["attachment_ids"] = Store.many(activity.attachment_ids, fields=["name"])
            data["persona"] = Store.one(activity.user_id.partner_id)
            store.add(activity, data)
        activity_type_approval_id = self.env.ref("approvals.mail_activity_data_approval")
        for activity in self.filtered(
            lambda activity: activity["res_model"] == "approval.request"
            and activity.activity_type_id == activity_type_approval_id
        ):
            request = self.env["approval.request"].browse(activity["res_id"])
            # approver = request.approver_ids.filtered(
            #             lambda approver: activity.user_id == approver.user_id
            #         )
            # if len(approver)>1:
            if request.request_status == "pending":
                    approver_reviewer = request.approver_ids.filtered(
                            lambda approver: activity.user_id == approver.user_id and approver.tks_approvers_level == 'level_1'
                        )
                    for approver in approver_reviewer:
                        store.add(activity, {"approver_id": approver.id, "approver_status": approver.status, "cdp_request_status": request.request_status})
            elif request.request_status == "new":
                    approver_submit = request.approver_ids.filtered(
                            lambda approver: activity.user_id == approver.user_id and approver.tks_approvers_level == 'level_1'
                        )
                    for approver in approver_submit:
                        store.add(activity, {"approver_id": approver.id, "approver_status": approver.status})
            elif request.request_status == "reviewed":
                    approver_reviewer_2 = request.approver_ids.filtered(
                            lambda approver: activity.user_id == approver.user_id and approver.tks_approvers_level == 'level_2'
                        )
                    for approver in approver_reviewer_2:
                        store.add(activity, {"approver_id": approver.id, "approver_status": approver.status})
            elif request.request_status == "ready_approve" and not request.tks_last_approve:
                    approver_reviewer_3 = request.approver_ids.filtered(
                            lambda approver: activity.user_id == approver.user_id and approver.tks_approvers_level == 'level_3'
                        )
                    for approver in approver_reviewer_3:
                        store.add(activity, {"approver_id": approver.id, "approver_status": approver.status})
            elif request.request_status == "ready_approve" and request.tks_last_approve:
                    approver_reviewer_4 = request.approver_ids.filtered(
                            lambda approver: activity.user_id == approver.user_id and approver.tks_approvers_level == 'level_4'
                        )
                    for approver in approver_reviewer_4:
                        store.add(activity, {"approver_id": approver.id, "approver_status": approver.status})
