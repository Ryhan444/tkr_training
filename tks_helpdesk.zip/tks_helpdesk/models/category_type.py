from odoo import models, fields, api, _
from ast import literal_eval
from dateutil.relativedelta import relativedelta

class CategoryType(models.Model):
    _name = 'category.type'

    name = fields.Char(string="Category")
    type_inq_id = fields.Many2one(
        'type.inquiry',
        string='Type Inquiry',
        )
