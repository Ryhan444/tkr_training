from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_fields = any(
            not line.document or not line.reason or not line.risk or not line.mitigation or (
                line.document == 'other' and not line.other
            )
            for line in self.tks_im_42_waive_reimbursement_documents_ids
        )
        if self.tks_has_tks_im_waive_reimbursement_documents != 'no' and (
            not self.tks_im_42_waive_reimbursement_documents_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Document Lines Empty'),
                    'message': _('Document Lines must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }

        return super(ApprovalRequest, self).action_confirm()

   
    
    tks_im_42_waive_reimbursement_documents_ids = fields.One2many(
        'opl.waive.reimbursement.documents', 
        'request_id', string='OPL - Waive Reimbursement Documents'
    )
    tks_reimbursement_currency_id = fields.Many2one('res.currency', string='Currency', related='company_id.currency_id')
    tks_im_42_amount_reimbursement = fields.Monetary('Amount of Reimbursement (In IDR)', currency_field="tks_reimbursement_currency_id")


class OplWaiveReimbursementDocuments(models.Model):
    _name = 'opl.waive.reimbursement.documents'  
    _description = 'OPL Waive Reimbursement Documents'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    document = fields.Selection([
        ('invoice', 'Invoice'),
        ('transfer_order', 'Transfer Order'),
        ('photo_proof_maintenance', 'Photo Proof of Maintenance'),
        ('call_center_ch', 'Call Center Contact History'),
        ('other', 'Other'),  
    ], string='Document')
    reason = fields.Text('Reason')
    risk = fields.Text('Risk')
    mitigation = fields.Text('Mitigation')
    other = fields.Text('Other Document')