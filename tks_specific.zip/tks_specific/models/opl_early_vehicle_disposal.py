from odoo import _, api, fields, models
import datetime

class ApprovalRequest(models.Model):
    _inherit = 'approval.request'
    
    def action_confirm(self):
        missing_disposal_fields = any(
            not line.sequence or
            not line.car_desc or
            not line.plate_no or
            not line.partner_id or
            not line.contract_end
            for line in self.tks_opl_early_vehicle_disposal_ids
        )
        # missing_pnl_fields = any(
        #     not line.nbv or
        #     not line.rv or
        #     not line.auction_price
        #     for line in self.tks_opl_disposal_pnl_analysis_ids
        # )
        missing_spread_fields = any(
            not line.before or
            not line.after
            for line in self.tks_opl_early_vehicle_spread_change_ids
        )
        if self.tks_has_tks_im_early_vehicle_disposal != 'no':
            if not self.tks_opl_early_vehicle_disposal_ids or missing_disposal_fields:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('List of Car Proposed to be Disposed Empty'),
                        'message': _('Please fill in the required fields in the List of Car Proposed to be Disposed.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
            if not self.tks_opl_disposal_pnl_analysis_ids:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Disposal Profit / Loss Analysis Empty'),
                        'message': _('Please fill in the required fields in the Disposal Profit / Loss Analysis.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
            if not self.tks_opl_early_vehicle_spread_change_ids or missing_spread_fields:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Spread Change Empty'),
                        'message': _('Please fill in the required fields in the Spread Change.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
        return super(ApprovalRequest, self).action_confirm()

    
    tks_opl_early_vehicle_disposal_ids = fields.One2many('opl.early.vehicle.disposal', 'request_id', string='List of Car Proposed to be Disposed')
    tks_opl_disposal_pnl_analysis_ids = fields.One2many('opl.disposal.pnl.analysis', 'request_id', string='Disposal Profit / Loss Analysis')
    tks_opl_early_vehicle_spread_change_ids = fields.One2many('opl.early.vehicle.spread.change', 'request_id', string='Spread Change')
    tks_opl_early_vehicle_business_benefit_ids = fields.One2many('opl.early.vehicle.business.benefit', 'request_id', string='Business Benefit')
    tks_reason_early_vehicle = fields.Text('Reason / Explanation')

class OplEarlyVehicleDisposal(models.Model):
    _name = 'opl.early.vehicle.disposal'
    _description = 'Opl Early Vehicle Disposal'

    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    sequence = fields.Integer('No.', compute='_compute_sequence', store=True)
    car_desc = fields.Text('Car Description')
    plate_no = fields.Char('Plate No.')
    partner_id = fields.Many2one('res.partner', string='Customer')
    contract_end = fields.Date('Contract End')
    vehicle_age = fields.Integer('Vehicle Age')


    @api.depends('request_id.tks_opl_early_vehicle_disposal_ids')
    def _compute_sequence(self):
        for line in self:
            if line.request_id:
                order_lines = line.request_id.tks_opl_early_vehicle_disposal_ids.sorted(
                    lambda l: l.create_date if l.create_date else datetime.datetime.max
                )
                for index, tks_opl_early_vehicle_disposal_ids in enumerate(order_lines, start=1):
                    tks_opl_early_vehicle_disposal_ids.sequence = index

    
class OplDisposalPnlAnalysis(models.Model):
    _name = 'opl.disposal.pnl.analysis'
    _description = 'Disposal Profit / Loss Analysis'
    
    nbv = fields.Monetary('NBV', currency_field='currency_id')
    rv = fields.Monetary('RV', currency_field='currency_id')
    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    currency_id = fields.Many2one('res.currency', string='currency', related='request_id.tks_currency_id', readonly=True)
    auction_price = fields.Monetary('Auction Price Survey', currency_field='currency_id')
    estimation_pnl_price = fields.Monetary('Estimation Profit / Loss', currency_field='currency_id', compute='_compute_pnl', store=True)
    
    @api.depends('auction_price', 'nbv')
    def _compute_pnl(self):
        for line in self:
            line.estimation_pnl_price = line.auction_price - line.nbv
    
class OplDisposalSpreadChange(models.Model):
    _name = 'opl.early.vehicle.spread.change'
    _description = 'Spread Change'
    
    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    before = fields.Char('Before')
    after = fields.Char('After')
    
    
class OplDisposalVehicleBusinessBenefit(models.Model):
    _name = 'opl.early.vehicle.business.benefit'
    _description = 'Business Benefit'
    
    request_id = fields.Many2one('approval.request', string='Request', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')
    
    
