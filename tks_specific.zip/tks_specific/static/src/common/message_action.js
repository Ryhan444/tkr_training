import { Message } from "@mail/core/common/message";
import { messageActionsRegistry } from "@mail/core/common/message_actions";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";

// patch(Message.prototype, {
//     setup() {
//         super.setup();
//         this.orm = useService("orm");
//         this.props.message.state = null;
//         this.orm.call('approval.request', 'get_state', [this.props.message.res_id])
//             .then(state => {
//                 this.props.message.state = state;
//             })
//             .catch(error => console.error("Error fetching state:", error));
//     },
// });

// const restrictApprovalActions = {
//     condition(component) {
//         const { model, state } = component.props.message || {};
//         return model === "approval.request" && state !== "new" ? false : super.condition(component);
//     },
// };

// ["delete", "edit"].forEach(action => patch(messageActionsRegistry.get(action), restrictApprovalActions));