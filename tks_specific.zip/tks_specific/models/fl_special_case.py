from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_9_approval_for = fields.Text(string="Approval For")
    tks_im_9_is_effective_date = fields.Selection(string="Effective Date", selection=[('yes','Yes'),('no','No')], default="no")
    tks_im_9_effective_date = fields.Date(
        string=_("Date"),
    )
    tks_im_9_items_ids = fields.One2many(
        comodel_name="tks.im.9.items",
        inverse_name="tks_im_request_id",
        string="Items",
        store=True,
    )

    tks_im_9_bussiness_benefit_ids = fields.One2many(
        comodel_name="tks.im.9.business.benefit",
        inverse_name="tks_im_request_id",
        string="Business Benefit",
        store=True,
    )

    tks_im_9_risk_mitigation_ids = fields.One2many(
        comodel_name="tks.im.9.risk.mitigation",
        inverse_name="tks_im_request_id",
        string="Business Benefit",
        store=True,
    )
    
    def action_confirm(self):
        missing_fields = any(
            not line.tks_im_9_items or
            not line.tks_im_9_items_before or
            not line.tks_im_9_items_after or
            not line.tks_im_9_reason_explaination
            for line in self.tks_im_9_items_ids
        )
        if self.tks_has_tks_im_special_case_fl != 'no' and (
            not self.tks_im_9_items_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Items Empty'),
                    'message': _('Please fill in the required fields in the Items list.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()



class TksIM9Items(models.Model):
    _name = "tks.im.9.items"
    _description = "IM 9 Items"

    tks_im_request_id = fields.Many2one("approval.request", string="Approval Request", ondelete="cascade")
    tks_im_9_items = fields.Selection(
        string=_("Items"),
        selection=[
            ("ls", "Lease Term"),
            ("lr", "Lease Rent"),
            ("cost", "Cost"),
            ("scheme", "Scheme"),
            ("ut", "Unit Type"),
            ("others", "Others"),
        ],
    )

    tks_im_9_items_before = fields.Text(string=_("Before"))
    tks_im_9_items_after = fields.Text(string=_("After"))

    tks_im_9_reason_explaination = fields.Text(string=_("Reason/Explanation"))


class TksIM9BusinessBenefit(models.Model):
    _name = "tks.im.9.business.benefit"
    _description = "IM 9 Business Benefit"

    tks_im_request_id = fields.Many2one("approval.request", string="Approval Request", ondelete="cascade")
    item = fields.Selection(
        string=_("Items"),
        selection=[
            ("bc", "Business Consideration"),
            ("calculation", "Calculation (if any)"),
        ],
    )

    remarks = fields.Text(string=_("Remarks"))


class TksIM9RiskMitigation(models.Model):
    _name = "tks.im.9.risk.mitigation"
    _description = "IM 9 Risk & Mitigation"

    tks_im_request_id = fields.Many2one("approval.request", string="Approval Request", ondelete="cascade")
    risk_mitigation = fields.Selection(
        string=_("Items"),
        selection=[
            ("risk", "Risk"),
            ("mitigation", "Mitigation"),
        ],
    )

    remarks = fields.Text(string=_("Remarks"))
