import { _t } from "@web/core/l10n/translation";
import { onWillStart } from "@odoo/owl";
import { user } from "@web/core/user";
import { FormController } from "@web/views/form/form_controller";
import { ListController } from "@web/views/list/list_controller";
import { KanbanController } from "@web/views/kanban/kanban_controller";
import { patch } from "@web/core/utils/patch";
import { 
    deleteConfirmationMessage,
    ConfirmationDialog 
} from "@web/core/confirmation_dialog/confirmation_dialog";

function setupContactAccess(controller) {
    onWillStart(async () => {
        controller.contactAccess = await user.hasGroup("tks_specific.tks_can_delete_contact");
        controller.adminAccess = await user.hasGroup("sales_team.group_sale_manager");
        controller.deleteImAccess = await user.hasGroup("tks_specific.tks_can_delete_im")
        controller.deleteCrmAccess = await user.hasGroup("tks_specific.tks_can_delete_crm")
        controller.AllLeads = await user.hasGroup("sales_team.group_sale_salesman_all_leads")
        controller.departmentLeads = await user.hasGroup("tks_specific.tks_group_sale_salesman_department_leads")
    });
}

function filterMenuItems(menuItems, adminAccess, departmentLeads, deleteCrmAccess, deteleAccess, deleteContact, resModel, status=false) {
    if (resModel === 'cdp.approval.configuration') {
        menuItems.action = menuItems.action?.filter((action) => !['duplicate', 'insert', 'delete',].includes(action.key)) || [];
    }

    if (!adminAccess && resModel === 'res.partner') {
        menuItems.action = menuItems.action?.filter((action) => !['export'].includes(action.key)) || [];
    }

    if (resModel === 'helpdesk.ticket') {
        menuItems.action = menuItems.action?.filter((action) => !['duplicate', 'archive', 'unarchive', 'delete', 'insert'].includes(action.key)) || [];
    }

    if (resModel === 'repair.order') {
        menuItems.action = menuItems.action?.filter((action) => !['delete', 'insert'].includes(action.key)) || [];
    }

    if (!deleteContact && resModel === 'res.partner') {
        menuItems.action = menuItems.action?.filter((action) => !['delete'].includes(action.key)) || [];
    }

    if (!departmentLeads && resModel == 'crm.lead') {
        menuItems.action = menuItems.action?.filter((action) => !['export'].includes(action.key)) || [];
    }

    if (!departmentLeads && resModel == 'mail.activity') {
        menuItems.action = menuItems.action?.filter((action) => !['export'].includes(action.key)) || [];
    }

    if (resModel == 'mail.activity') {
        menuItems.action = menuItems.action?.filter((action) => !['delete', 'insert', 'archive', 'unarchive'].includes(action.key)) || [];
    }

    if (resModel === 'ir.attachment') {
        menuItems.action = menuItems.action?.filter((action) => !['delete'].includes(action.key)) || [];
    }

    if (resModel === 'approval.request' && !deteleAccess) {
        menuItems.action = menuItems.action?.filter((action) => !['delete'].includes(action.key)) || [];
    } else if (resModel === 'approval.request' && status != 'new') {
        menuItems.action = menuItems.action?.filter((action) => !['delete'].includes(action.key)) || [];
    }

    if (resModel === 'approval.request') {
        menuItems.print = menuItems.print?.filter((print) => !['Approval Request'].includes(print.name)) || [];
        menuItems.action = menuItems.action?.filter((action) => !['insert'].includes(action.key)) || [];
    }

    if (resModel === 'res.partner') {
        menuItems.action = menuItems.action?.filter((action) => !['Merge', 'Send email', 'Send SMS', 'Download (vCard)', 'Grant portal access', 'Privacy Lookup'].includes(action.name)) || [];
        menuItems.action = menuItems.action?.filter((action) => !['insert', 'duplicate'].includes(action.key)) || [];
    }

    if (!deleteCrmAccess && resModel === 'crm.lead') {
        menuItems.action = menuItems.action?.filter((action) => !['delete'].includes(action.key)) || [];
    }

    if (resModel === 'crm.lead') {
        menuItems.action = menuItems.action?.filter((action) => !['addPropertyFieldValue','duplicate', 'insert', 'archive', 'unarchive'].includes(action.key)) || [];
        menuItems.action = menuItems.action?.filter((action) => !['Send email', 'Send SMS', 'Mark Lost', 'Convert to opportunities', 'Merge'].includes(action.name)) || [];
    }
    if (resModel === 'mail.activity') {
        menuItems.action = menuItems.action?.filter((action) => !['insert'].includes(action.key)) || [];
    }
    return menuItems;
}

patch(ListController.prototype, {
    setup() {
        super.setup();
        setupContactAccess(this);
    },

    get actionMenuItems() {
        const model = this.props.resModel
        if (model == 'approval.request') {
            let selectedRecord = this.model.root.selection
            for (let i=0; i < selectedRecord.length; i++) {
                const record = selectedRecord[i]
                return filterMenuItems(super.actionMenuItems, this.adminAccess, this.departmentLeads, this.deleteCrmAccess, this.deleteImAccess, this.contactAccess, model, record.data.request_status);
            }
        }
        return filterMenuItems(super.actionMenuItems, this.adminAccess, this.departmentLeads, this.deleteCrmAccess, this.deleteImAccess, this.contactAccess, model);
    },

    get deleteConfirmationDialogProps() {
        const deleteConfirmationDialogProps = super.deleteConfirmationDialogProps;
        return {
            ...deleteConfirmationDialogProps,
            confirm: async () => {
                await this.model.root.deleteRecords();

                await Promise.resolve();

                this.dialogService.add(ConfirmationDialog, {
                    body: _t("Record deleted successfully"),
                });
            },
        };
    }
});

patch(FormController.prototype, {
    setup() {
        super.setup();
        setupContactAccess(this);
    },

    get actionMenuItems() {
        const menu = filterMenuItems(super.actionMenuItems, this.adminAccess, this.deleteCrmAccess, this.deleteImAccess, this.contactAccess, this.props.resModel, this.model?.root?.data.request_status);
        const model = this.props.resModel
        if (model == 'approval.request') {
            menu.action = menu.action?.filter((action) => !['duplicate'].includes(action.key)) || [];
        }

        if (model == 'repair.order') {
            menu.action = menu.action?.filter((action) => !["duplicate", "delete", "addPropertyFieldValue"].includes(action.key)) || [];
            const data = this.model?.root?.data
            if (data.state === 'draft') {
                menu.print = menu.print?.filter((print) => !["SPK INHOUSE / SPKSK", "SURAT TUGAS STORING", "SPKL (INSPECTION)", "SPKL (REPAIR)", "SPKL (INSPECTION)"].includes(print.name))
            }

            if (data.cdp_service_location === 'inhouse') {
                menu.print = menu.print?.filter((print) => !["SURAT TUGAS STORING", "SPKL (INSPECTION)", "SPKL (REPAIR)"].includes(print.name))
            } else if (data.cdp_service_location === 'storing') {
                 menu.print = menu.print?.filter((print) => !["SPK INHOUSE / SPKSK", "SPKL (INSPECTION)", "SPKL (REPAIR)"].includes(print.name))
            } else if (data.cdp_service_location === 'external'){
                menu.print = menu.print?.filter((print) => !["SURAT TUGAS STORING", "SPK INHOUSE / SPKSK"].includes(print.name))
                if (data.cdp_spk_type === 'repair') {
                    menu.print = menu.print?.filter((print) => !["SPKL (INSPECTION)"].includes(print.name))
                } else {
                    menu.print = menu.print?.filter((print) => !["SPKL (REPAIR)"].includes(print.name))
                }
            }
        }

        if (model == 'helpdesk.ticket') {
            menu.action = menu.action?.filter((action) => !["duplicate", "delete", "archive", "unarchive"].includes(action.key)) || [];
            const data = this.model?.root?.data
            
            if (data.stage_id[1] === 'New' || data.type_inquiry_id[1] !== 'Pool') {
                menu.print = menu.print?.filter((print) => !["SPKL (POOL)"].includes(print.name))
            }
        }
        return menu
    },

    get deleteConfirmationDialogProps() {
        const deleteConfirmationDialogProps = super.deleteConfirmationDialogProps;
        return {
            ...deleteConfirmationDialogProps,
            confirm: async () => {
                await this.model.root.delete();

                await Promise.resolve();

                this.dialogService.add(ConfirmationDialog, {
                    body: _t("Record deleted successfully"),
                });
            },
        };
    }
});

patch(KanbanController.prototype, {
    setup() {
        super.setup();
    },
    async deleteRecord(record) {
        this.dialog.add(ConfirmationDialog, {
            title: _t("Bye-bye, record!"),
            body: deleteConfirmationMessage,
            confirm: () => {
                this.model.root.deleteRecords([record])
                this.dialog.add(ConfirmationDialog, {
                    body: _t("Record deleted successfully"),
                });
            },
            confirmLabel: _t("Delete"),
            cancel: () => {},
            cancelLabel: _t("No, keep it"),
        });
    }
})
