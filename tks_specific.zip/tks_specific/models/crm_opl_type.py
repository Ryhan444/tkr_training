from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_opl_type_id = fields.Many2one('tks.opl.type', string="OPL Type")

class TksOplType(models.Model):
    _name = 'tks.opl.type'
    _description = 'OPL Type'

    name = fields.Char(string="OPL Type")

