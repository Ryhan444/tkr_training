from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_trans_type_fl_id = fields.Many2one('tks.trans.type.fl', string="Transcation Type")
    tks_trans_type_opl_id = fields.Many2one('tks.trans.type.opl', string="Transcation Type")

class TksTransTypeFL(models.Model):
    _name = 'tks.trans.type.fl'
    _description = 'Transcation Type'

    name = fields.Char(string="Transcation Type")
    code = fields.Char(string="Code")


class TksTransTypeOPL(models.Model):
    _name = 'tks.trans.type.opl'
    _description = 'Transcation Type'

    name = fields.Char(string="Transcation Type")

