from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_3_article_to_be_revise_ids = fields.One2many(
        comodel_name="tks.im.article.to.revise.line",
        inverse_name="tks_im_3_approval_request_id",
        string="Article to bo Revise Line",
        store=True,
    )

    def action_confirm(self):
        if self.tks_has_tks_im_contract_adjustment != 'no':
            item = [not line.tks_im_3_contract_no or not line.tks_im_3_article_to_revise or not line.tks_im_3_revision or not line.tks_im_3_changes_detail or not line.tks_im_3_risk_mitigation for line in self.tks_im_3_article_to_be_revise_ids.filtered(lambda x: x)]
            if not item:
                notification = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Proposal Line Empty'),
                        'message': _('Proposal line must be filled.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
                return notification
            elif item:
                if any(i for i in item) == True:
                    notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                    return notification
        return super(ApprovalRequest, self).action_confirm()


class TksArticleToReviseLine(models.Model):
    _name = "tks.im.article.to.revise.line"
    _description = "Article to Revise Line"

    sequence = fields.Char(string="No.", compute="_compute_number", store=True)
    tks_im_3_contract_no = fields.Char(string="Contract No.")
    tks_im_3_approval_request_id = fields.Many2one(
        "approval.request",
        string="Approval Request", ondelete="cascade"
    )
    tks_im_3_article_to_revise = fields.Text(string="Before")

    tks_im_3_revision = fields.Selection(
        string="Adjustment",
        selection=[("waive", "Waive"), ("change", "Change"), ("add", "Add")],
    )

    tks_im_3_changes_detail = fields.Text(string="After")

    tks_im_3_risk_mitigation = fields.Text(string="Risk & Mitigation")
    tks_im_3_remarks = fields.Text(string="Remarks")

    @api.depends("tks_im_3_approval_request_id")
    def _compute_number(self):
        for req in self.mapped("tks_im_3_approval_request_id"):
            sequence = 1
            if req.tks_im_3_article_to_be_revise_ids:
                for lines in req.tks_im_3_article_to_be_revise_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ""
