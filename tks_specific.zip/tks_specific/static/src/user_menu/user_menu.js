import { UserMenu } from "@web/webclient/user_menu/user_menu";
// import { onWillStart } from "@odoo/owl";
// import { user } from "@web/core/user";
import { patch } from "@web/core/utils/patch";

// function setupContactAccess(controller) {
//     onWillStart(async () => {
//         controller.adminAccess = await user.hasGroup("sales_team.group_sale_manager");
//     });
// }

patch(UserMenu.prototype, {
    setup() {
        super.setup();
        // setupContactAccess(this);
    },
    getElements() {
        const sortedItems = super.getElements();
        const filteredItems = []
        for (let i = 0; i < sortedItems.length; i++) {
            if (sortedItems[i].id === 'logout' || sortedItems[i].id === 'color_scheme.switch_theme' || sortedItems[i].id === 'settings') {
                filteredItems.push(sortedItems[i])
            }
        }
        return filteredItems
        // return sortedItems;
    }
})