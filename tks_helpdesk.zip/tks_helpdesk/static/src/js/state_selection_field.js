/** @odoo-module */

import { registry } from '@web/core/registry';
import {
    StateSelectionField,
    stateSelectionField,
} from "@web/views/fields/state_selection/state_selection_field";

export class InquirySelectionField extends StateSelectionField {
    get options() {
        if (this.props.record.data.state !== 'released' && this.props.record.resModel === 'repair.order') {
            return this.props.record.fields[this.props.name].selection.filter((selection) => !['done'].includes(selection[0])).map(([state, label]) => {
                return [state, label];
            });
        }

        return this.props.record.fields[this.props.name].selection.map(([state, label]) => {
            return [state, label];
        });
    }
}

export const inquiryStateSelectionField = {
    ...stateSelectionField,
    component: InquirySelectionField,
};

registry.category("fields").add("inquiry_state_selection", inquiryStateSelectionField);
