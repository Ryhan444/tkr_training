from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_coverage_opl_id = fields.Many2one('tks.insurance.coverage.opl', string="Insurance Coverage")

class TksTransType(models.Model):
    _name = 'tks.insurance.coverage.opl'
    _description = 'Insurance Coverage'

    name = fields.Char(string="Insurance Coverage")