from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_1_release_date = fields.Date(string=_("Release Date"))
    tks_im_1_list_of_os_item = fields.Selection(
        string=_("List of Outstanding Items"),
        selection=[("yes", "Yes"), ("no", "No")],
        default="no",
    )

    tks_im_1_list_of_os_items_ids = fields.One2many(
        comodel_name="tks.im.os.items",
        inverse_name="tks_request_id",
        string="List of Outstanding Items",
    )
    tks_im_1_bpkb_release_ids = fields.One2many(
        comodel_name="tks.bpkb.release",
        inverse_name="tks_request_id",
        string="BPKB Release",
    )

    def action_confirm(self):
        if self.tks_has_tks_im_bpkb_release_etc != 'no':
            item = [not line.tks_contract_no or not line.tks_bpkb_release or not line.tks_type_unit or not line.tks_plate_number or not line.tks_chasis_number or not line.tks_engine_number for line in self.tks_im_1_bpkb_release_ids.filtered(lambda x: x)]
            if not item:
                notification = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Proposal Line Empty'),
                        'message': _('Proposal line must be filled.'),
                        'sticky': False,
                        'type': 'warning',
                    },
                }
                return notification
            elif item:
                if any(i for i in item) == True:
                    notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                    return notification

            if self.tks_im_1_list_of_os_item != 'no':
                os_item = [not line.tks_im_list_os_items or not line.tks_im_list_os_reason or not line.tks_im_list_os_risk_mitigation or not line.tks_im_list_os_fullfilment_date for line in self.tks_im_1_list_of_os_items_ids.filtered(lambda x: x)]
                if not os_item:
                    notification = {
                            'type': 'ir.actions.client',
                            'tag': 'display_notification',
                            'params': {
                                'title': _('List of Outstanding Items Empty'),
                                'message': _('List of Outstanding Items must be filled.'),
                                'sticky': False,
                                'type': 'warning',
                            },
                        }
                    return notification
                elif os_item:
                    if any(i for i in os_item) == True:
                        notification = {
                            'type': 'ir.actions.client',
                            'tag': 'display_notification',
                            'params': {
                                'title': _('List of Outstanding Items Empty'),
                                'message': _('List of Outstanding Items must be filled.'),
                                'sticky': False,
                                'type': 'warning',
                            },
                        }
                        return notification
                
        return super(ApprovalRequest, self).action_confirm()

class TksBpkbRelease(models.Model):
    _name = "tks.bpkb.release"
    _description = "BPKB Release"

    tks_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_contract_no = fields.Char(string="Contract No.")
    tks_bpkb_release = fields.Char(string=_("BPKB No."))
    tks_currency_bpkb_id = fields.Many2one(comodel_name="res.currency", string="Currency", related="tks_request_id.tks_currency_id")
    tks_os_balance = fields.Monetary(string="O/S Balance", currency_field="tks_currency_bpkb_id")
    tks_type_unit = fields.Char(string=_("Type Unit"))
    tks_plate_number = fields.Char(string=_("Plate Number"))
    tks_chasis_number = fields.Char(string=_("Chasis Number"))
    tks_engine_number = fields.Char(string=_("Engine Number"))


class TksOsItems(models.Model):
    _name = "tks.im.os.items"
    _description = "List of Outstanding Items"

    tks_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    sequence = fields.Integer(string="No.", compute="_compute_number", store=True)
    tks_im_list_os_items = fields.Char(string="Items")
    tks_im_list_os_reason = fields.Text(string="Reason/Amount")
    tks_im_list_os_risk_mitigation = fields.Text(string="Risk/Mitigation")
    tks_im_list_os_fullfilment_date = fields.Date(string="Fullfilment Date")

    @api.depends("tks_request_id")
    def _compute_number(self):
        for req in self.mapped("tks_request_id"):
            sequence = 1
            if req.tks_im_1_list_of_os_items_ids:
                for lines in req.tks_im_1_list_of_os_items_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ""
