import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { X2ManyFieldDialog } from "@web/views/fields/relational_utils";
import { executeButtonCallback } from "@web/views/view_button/view_button_hook";

patch(X2ManyFieldDialog.prototype, {
    setup() {
        super.setup();
        this.notification = useService("notification");
    },

    validateNumberField({ fieldName, value, minLength = 0 }) {
        const trimmed = value.trim();

        if (/\s/.test(trimmed)) {
            this.notification.add(`${fieldName} cannot contain spaces`, {
                title: `Invalid ${fieldName}`,
                type: "danger",
            });
            return false;
        }

        if (!/^\+?\d+$/.test(trimmed)) {
            this.notification.add(`${fieldName} must contain only numbers and may start with '+'`, {
                title: `Invalid ${fieldName}`,
                type: "danger",
            });
            return false;
        }

        if (minLength > 0 && trimmed.length < minLength) {
            this.notification.add(`${fieldName} must be at least ${minLength} digits`, {
                title: `Invalid ${fieldName}`,
                type: "danger",
            });
            return false;
        }

        return true;
    },

    // Override
    async save({ saveAndNew }) {
        return executeButtonCallback(this.modalRef.el, async () => {
            const phoneInput = this.modalRef.el.querySelector('input[id="phone_0"]');
            const mobileInput = this.modalRef.el.querySelector('input[id="mobile_0"]');
            const phone = phoneInput?.value || "";
            const mobile = mobileInput?.value || "";

            if (this.props.title === 'Open: Contact' || this.props.title === 'Create Contact') {
                if (phone && !this.validateNumberField({ fieldName: "Phone", value: phone })) {
                    return false;
                }

                if (mobile && !this.validateNumberField({ fieldName: "Mobile", value: mobile, minLength: 10 })) {
                    return false;
                }
            }

            if (await this.record.checkValidity({ displayNotification: true })) {
                await this.props.save(this.record);

                if (saveAndNew) {
                    await this.record.switchMode("readonly");
                    this.record = await this.props.addNew();
                }
            } else {
                return false;
            }

            if (!saveAndNew) {
                this.props.close();
            }

            return true;
        });
    },
});
