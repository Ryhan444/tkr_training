from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_bpkp_no_16 = fields.Char(string='BPKB No.')
    tks_borrow_reason_16 = fields.Text('Borrow Reason')
    tks_start_date_16 = fields.Date('Start Date')
    tks_end_date_16 = fields.Date('End Date')
    tks_opl_borrow_bpkb_line_ids = fields.One2many('opl.borrow.bpkb.risk.mitigation', 'request_id', string='Lines Borrow BPKB Risk and Mitigation')
    
    
class OplBorrowBPKBRiskMitigation(models.Model):
    _name = 'opl.borrow.bpkb.risk.mitigation'
    _description = 'OPL - Borrow BPKB Risk and Mitigation'
    _rec_name = 'risk_mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')
