from odoo import fields, models, _, api
from odoo.exceptions import ValidationError

CATEGORY_SELECTION = [("required", "Required"), ("no", "None")]


class ApprovalCategory(models.Model):
    _inherit = "approval.category"

    # FL Basic Fields
    tks_can_edit_all_approvers = fields.Boolean(string="Can edit all level", default=False)
    tks_has_tks_im_fl_type = fields.Selection(CATEGORY_SELECTION, string="Type", default="no")
    tks_has_tks_im_fl_special_case_category = fields.Selection(
        CATEGORY_SELECTION,
        string="Special Case Category",
        default="no",
    )
    tks_has_tks_im_fl_tks_program = fields.Selection(
        CATEGORY_SELECTION,
        string="TKS Program Type",
        default="no",
    )

    tks_use_approver_level = fields.Boolean(
        string="Use Approver Level",
        default=False,
    )
    
    tks_category_type = fields.Selection(
        string=_("Category Type"),
        selection=[
            ("fl", "FL"),
            ("opl", "OPL"),        
        ],
    )

    # OPL Basic Fields
    tks_has_tks_im_opl_special_case_category = fields.Selection(
        CATEGORY_SELECTION,
        string="Special Case Category",
        default="no",
    )
    tks_has_tks_im_opl_ci_type = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Invoice Type",
        default="no",
    )
    tks_has_tks_im_opl_management_consent = fields.Selection(
        CATEGORY_SELECTION,
        string="Management Consent",
        default="no",
    )
    tks_has_tks_im_opl_sparekey_type = fields.Selection(
        CATEGORY_SELECTION,
        string="Sparekey Type",
        default="no",
    )
    tks_has_tks_im_opl_waive_category = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Category",
        default="no",
    )

    # Basic Fields
    tks_has_tks_im_category = fields.Selection(
        CATEGORY_SELECTION,
        string="Category",
        default="no",
    )
    tks_has_tks_im_sub_category = fields.Selection(
        CATEGORY_SELECTION,
        string="Sub Category",
        default="no",
    )
    tks_has_tks_im_changing_clause = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Clause",
        default="no",
    )
    tks_has_tks_currency = fields.Selection(
        CATEGORY_SELECTION,
        string="Currency",
        default="no",
    )

    # new fields general information
    tks_has_tks_im_customer = fields.Selection(
        string="Customer", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_customer_status = fields.Selection(
        string="Customer Status", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_customer_since = fields.Selection(
        string="Customer Since", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_contract_no = fields.Selection(
        string="Contract No.", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_current_os_balance = fields.Selection(
        string="Current O/S", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_mhc_rating = fields.Selection(
        string="MHC Rating", selection=CATEGORY_SELECTION, default="no"
    )
    tks_has_tks_im_company_group = fields.Selection(
        CATEGORY_SELECTION, string="Company Group", default="no"
    )
    tks_has_tks_im_industry = fields.Selection(
        string="Line of Business", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_remaining_installment = fields.Selection(
        string="Remaining Installment", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_trans_type_fl = fields.Selection(
        string="Transaction Type FL", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_trans_type_opl = fields.Selection(
        string="Transaction Type OPL", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_coverage_type = fields.Selection(
        string="Coverage Type", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_total_holding_unit = fields.Selection(
        string="Total Holding Unit", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_unit_in_takari = fields.Selection(
        string="Unit in Takari (UIT)", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_car_description = fields.Selection(
        string="Car Description", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_location = fields.Selection(
        string="Location", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_no_palte = fields.Selection(
        string="Plate No.", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_remaining_term = fields.Selection(
        string="Remaining Term", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_total_term = fields.Selection(
        string="Total Term", selection=CATEGORY_SELECTION, default="no"
    )

    tks_has_tks_im_policy = fields.Selection(
        string="Policy", selection=CATEGORY_SELECTION, default="no"
    )

    # new fields for proposal
    tks_has_tks_im_plate_number = fields.Selection(
        string="Plate Number", selection=CATEGORY_SELECTION, default="no"
    )

    # Internal Memo Category
    # Finance Lease
    tks_has_tks_im_bpkb_release_etc = fields.Selection(
        CATEGORY_SELECTION,
        string="BPKB Release for Early Termination Condition",
        default="no",
    )
    tks_has_tks_im_temporary_changing_collateral_bpkb = fields.Selection(
        CATEGORY_SELECTION,
        string="Temporary Changing Collateral BPKB",
        default="no",
    )
    tks_has_tks_im_contract_adjustment = fields.Selection(
        CATEGORY_SELECTION,
        string="Contract Adjustment",
        default="no",
    )
    tks_has_tks_im_reprint_contract = fields.Selection(
        CATEGORY_SELECTION,
        string="Reprint Contract",
        default="no",
    )
    tks_has_tks_im_postpone_kyc_document_fl = fields.Selection(
        CATEGORY_SELECTION,
        string="Postpone KYC Document",
        default="no",
    )
    tks_has_tks_im_waive_kyc_document_fl = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive KYC Document",
        default="no",
    )
    tks_has_tks_im_hold_pdc_process = fields.Selection(
        CATEGORY_SELECTION,
        string="Hold PDC Process",
        default="no",
    )
    tks_has_tks_im_waive_overdue_penalty = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Overdue Penalty",
        default="no",
    )
    tks_has_tks_im_special_case_fl = fields.Selection(
        CATEGORY_SELECTION,
        string="Special Case",
        default="no",
    )
    tks_has_tks_im_tks_program = fields.Selection(
        CATEGORY_SELECTION,
        string="TKS Program",
        default="no",
    )
    tks_has_tks_im_waive_insurance_policy_fl = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Insurance Policy",
        default="no",
    )

    # Operation Lease
    tks_has_tks_im_transfer_agreement = fields.Selection(
        CATEGORY_SELECTION,
        string="Transfer Agreement",
        default="no",
    )
    tks_has_tks_im_below_min_spread_transaction = fields.Selection(
        CATEGORY_SELECTION,
        string="Below Minimum Spread Transaction",
        default="no",
    )
    tks_has_tks_im_changing_application = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Application",
        default="no",
    )
    tks_has_tks_im_early_purchase = fields.Selection(
        CATEGORY_SELECTION,
        string="Early Purchase",
        default="no",
    )
    tks_has_tks_im_permanent_exchange = fields.Selection(
        CATEGORY_SELECTION,
        string="Permanent Exchange",
        default="no",
    )
    tks_has_tks_im_borrow_bpkb = fields.Selection(
        CATEGORY_SELECTION,
        string="Borrow BPKB",
        default="no",
    )
    tks_has_tks_im_changing_plate_number = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Plate Number",
        default="no",
    )
    tks_has_tks_im_early_vehicle_disposal = fields.Selection(
        CATEGORY_SELECTION,
        string="Early Vehicle Disposal",
        default="no",
    )
    tks_has_tks_im_early_release_the_bpkb_to_user = fields.Selection(
        CATEGORY_SELECTION,
        string="Early Release The BPKB to User",
        default="no",
    )
    tks_has_tks_im_extend_booking_unit = fields.Selection(
        CATEGORY_SELECTION,
        string="Extend Booking Unit",
        default="no",
    )
    tks_has_tks_im_postpone_withdrawn_unit = fields.Selection(
        CATEGORY_SELECTION,
        string="Postpone Withdrawn Unit",
        default="no",
    )
    tks_has_tks_im_unit_relocation = fields.Selection(
        CATEGORY_SELECTION,
        string="Unit Relocation",
        default="no",
    )
    tks_has_tks_im_sparekey = fields.Selection(
        CATEGORY_SELECTION,
        string="Sparekey",
        default="no",
    )

    tks_has_tks_im_total_loss = fields.Selection(
        CATEGORY_SELECTION,
        string="Total Loss",
        default="no",
    )

    tks_has_tks_im_management_consent = fields.Selection(
        CATEGORY_SELECTION,
        string="Management Consent",
        default="no",
    )

    tks_has_tks_im_changing_clausal = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Clausal",
        default="no",
    )

    tks_has_tks_im_changing_signer = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing The Signer",
        default="no",
    )

    tks_has_tks_im_using_contract_template_by_customer = fields.Selection(
        CATEGORY_SELECTION,
        string="Using Contract Template By Customer",
        default="no",
    )

    tks_has_tks_im_reprint_master_agreement = fields.Selection(
        CATEGORY_SELECTION,
        string="Reprint Master Agreement / Addendum",
        default="no",
    )

    tks_has_tks_im_waive_master_agreement = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Master Agreement / Addendum / PPJB",
        default="no",
    )

    tks_has_tks_im_waive_insurance_policy = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Insurance Policy",
        default="no",
    )

    tks_has_tks_im_waive_kyc_document_opl = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive KYC Document",
        default="no",
    )

    tks_has_tks_im_postpone_kyc_document_opl = fields.Selection(
        CATEGORY_SELECTION,
        string="Postpone KYC Document",
        default="no",
    )

    tks_has_tks_im_delivery_before_sign_contract = fields.Selection(
        CATEGORY_SELECTION,
        string="Delivery Before Sign Contract",
        default="no",
    )

    tks_has_tks_im_dispatcher_request = fields.Selection(
        CATEGORY_SELECTION,
        string="Dispatcher Request",
        default="no",
    )

    tks_has_tks_im_safekeep_running_contract_vehicle = fields.Selection(
        CATEGORY_SELECTION,
        string="Safekeep Running Contract Vehicle",
        default="no",
    )

    tks_has_tks_im_safety_driving_training = fields.Selection(
        CATEGORY_SELECTION,
        string="Safety Driving Training",
        default="no",
    )

    tks_has_tks_im_changing_invoice = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Invoice",
        default="no",
    )

    tks_has_tks_im_changing_finance_grade = fields.Selection(
        CATEGORY_SELECTION,
        string="Changing Finance Grade",
        default="no",
    )

    tks_has_tks_im_waive_duty_stamp_fee_for_customer = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Duty Stamp Fee For Customer",
        default="no",
    )

    tks_has_tks_im_waive_duty_stamp_fee_for_customer_fl = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Duty Stamp Fee For Customer",
        default="no",
    )

    tks_has_tks_im_overpayment_refund_to_customer = fields.Selection(
        CATEGORY_SELECTION,
        string="Overpayment Refund to Customer",
        default="no",
    )

    tks_has_tks_im_waive_reimbursement_documents = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Reimbursement Documents",
        default="no",
    )

    tks_has_tks_im_suspend_warning_letter = fields.Selection(
        CATEGORY_SELECTION,
        string="Suspend Warning Letter",
        default="no",
    )

    tks_has_tks_im_waive_late_payment_penalty = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Late Payment Penalty",
        default="no",
    )

    tks_has_tks_im_waive_own_risk = fields.Selection(
        CATEGORY_SELECTION,
        string="Waive Own Risk",
        default="no",
    )

    tks_has_tks_im_special_case_opl = fields.Selection(
        CATEGORY_SELECTION,
        string="Special Case",
        default="no",
    )

    #Constrains
    @api.constrains('approval_minimum', 'approver_ids')
    def _constrains_approval_minimum(self):
        for record in self:
            if record.tks_use_approver_level:
                pass
            else:
                return super(ApprovalCategory, self)._constrains_approval_minimum()
    
    @api.constrains('approver_sequence', 'approval_minimum')
    def _constrains_approver_sequence(self):
        if self.tks_use_approver_level:
            pass
        else:
            return super(ApprovalCategory, self)._constrains_approver_sequence()
    
    # override 
    @api.constrains('approver_ids')
    def _constrains_approver_ids(self):
        for record in self:
            # Membuat daftar pasangan (user_id, tks_approvers_level) dari setiap entry
            seen_combinations = set()
            
            for approver in record.approver_ids:
                user_id = approver.user_id.id  # Ambil user_id
                tks_approvers_level = approver.tks_approvers_level  # Ambil tks_approvers_level

                # Membuat pasangan unik (user_id, tks_approvers_level)
                combination = (user_id, tks_approvers_level)
                
                # Jika kombinasi sudah ada sebelumnya, artinya duplikasi ditemukan
                # if combination in seen_combinations:
                #     raise ValidationError(_('An user with the same approvers level may not be in the approver list multiple times.'))

                # Jika tidak, tambahkan kombinasi ke set
                seen_combinations.add(combination)
    
    #Compute
    @api.depends_context('lang')
    @api.depends('approval_minimum', 'approver_ids', 'manager_approval')
    def _compute_invalid_minimum(self):
        for record in self:
            record.invalid_minimum = False
            if record.tks_use_approver_level:
                record.invalid_minimum = False
                record.invalid_minimum_warning = False
            else:
                return super(ApprovalCategory, self)._compute_invalid_minimum()

    #Write
    def write(self, vals):
        res = super(ApprovalCategory, self.sudo()).write(vals)
        for record in self:
            if 'approver_ids' in vals:
                all_level = ['level_1','level_2','level_3','level_4']
                approvers = record.approver_ids.mapped('tks_approvers_level')
                approvers = list(set(approvers))
                if False not in approvers:
                    approvers.sort()
                
                if all_level == approvers:
                    continue
                else:
                    raise ValidationError("Minimum approvers level is not met. Please add approvers level")
        return res


class ApprovalCategoryApprover(models.Model):
    _inherit = "approval.category.approver"

    tks_approvers_level = fields.Selection(
        string="Approver's Level",
        selection=[
            ("level_1", "Reviewer"),
            ("level_2", "Acknowledger"),
            ("level_3", "Approver"),
            ("level_4", "Final Approver"),
        ],
    )

    tks_use_approval_level = fields.Boolean(
        string="Use Approval Level", related="category_id.tks_use_approver_level"
    )

    tks_level_sequence = fields.Integer(string="Level Sequence", compute="compute_level_sequence", store=True)

    #Compute
    @api.depends('category_id', 'category_id.approver_ids', 'user_id', 'tks_approvers_level')
    def compute_level_sequence(self):
        for approver in self:
            sequence = 0
            if approver.tks_approvers_level == 'level_1':
                sequence = 1
            if approver.tks_approvers_level == 'level_2':
                sequence = 2
            if approver.tks_approvers_level == 'level_3':
                sequence = 3
            if approver.tks_approvers_level == 'level_4':
                sequence = 4
            approver.tks_level_sequence = sequence

    #Write
    def write(self, vals):
        res = super(ApprovalCategoryApprover, self).write(vals)
        if 'tks_approvers_level' in vals:
            current_user = self.user_id
            current_employee = current_user.employee_id
            if self.tks_approvers_level not in current_employee.tks_approver_level_ids.mapped("code"):
                raise ValidationError(_("%s is not belong to the current level. Please select another user for this level.", self.user_id.name))
        return res


class ApprovalApprover(models.Model):
    _inherit = "approval.approver"
    _order = 'tks_level_sequence, sequence, id'

    status = fields.Selection(selection_add=[
        ('refused','Rejected'),
        ('revised', 'Revised'),
    ])

    tks_approvers_level = fields.Selection(
        string="Approver's Level",
        selection=[
            ("level_1", "Reviewer"),
            ("level_2", "Acknowledger"),
            ("level_3", "Approver"),
            ("level_4", "Final Approver"),
        ],
    )

    tks_level_sequence = fields.Integer(string="Level Sequence", compute="compute_level_sequence", store=True)

    user_id = fields.Many2one('res.users', string="User", required=True, check_company=True, domain="[('employee_id.tks_approver_level_ids.code','=',tks_approvers_level)]")

    tks_same_user_level = fields.Boolean(string="Same user and level", store=True, compute="onchange_user_id", default=False)
    tks_prev_user = fields.Char(string="Previous Approver", readonly=True)
    tks_remark = fields.Text("Remark/Comment")

    status_display = fields.Char(
        string="Status",
        compute="_compute_status_display",
        store=False
    )

    @api.depends("status", "tks_approvers_level")
    def _compute_status_display(self):
        """Override label for level_1"""
        for rec in self:
            if rec.tks_approvers_level == "level_1":
                if rec.status == "pending":
                    rec.status_display = _("To Verify")
                elif rec.status == "approved":
                    rec.status_display = _("Verified")
                else:
                    rec.status_display = dict(self._fields['status'].selection).get(rec.status, rec.status)
            else:
                if rec.status == "approved" and rec.tks_approvers_level == "level_2":
                    rec.status_display = _("Acknowledged")
                else:
                    rec.status_display = dict(self._fields["status"].selection).get(
                        rec.status, rec.status
                    )

    # Compute
    @api.depends('request_id', 'request_id.approver_ids', 'user_id', 'tks_approvers_level')
    def compute_level_sequence(self):
        for approver in self:
            sequence = 0
            if approver.tks_approvers_level == 'level_1':
                sequence = 1
            if approver.tks_approvers_level == 'level_2':
                sequence = 2
            if approver.tks_approvers_level == 'level_3':
                sequence = 3
            if approver.tks_approvers_level == 'level_4':
                sequence = 4
            approver.tks_level_sequence = sequence

    # override all access user edit
    @api.depends('request_id.request_owner_id', 'request_id.approver_ids.user_id')
    def _compute_existing_request_user_ids(self):
        all_users = self.env['res.users'].search([])  # Mengambil semua user
        for approver in self:
            approver.existing_request_user_ids = all_users

    # Onchange
    @api.depends("user_id","tks_approvers_level")
    def onchange_user_id(self):
        for approver in self:
            same_user_level = approver.request_id.approver_ids.filtered(lambda x: x.user_id == approver.user_id and x.tks_approvers_level == approver.tks_approvers_level)
            if len(same_user_level) > 1:
                approver.tks_same_user_level = True
            elif len(same_user_level) <= 1:
                approver.tks_same_user_level = False

    # Write
    def write(self, vals):
        # Simpan record dengan perubahan pada user_id
        records_with_changed_user = []
        # Simpan user sebelumnya
        prev_user = []
        prev_level = []
        # Periksa perubahan sebelum write
        for record in self:
            if 'user_id' in vals and record.user_id.id != vals['user_id']:
                record.request_id._cancel_activities_specific(record.user_id)
                records_with_changed_user.append(record.id)
                prev_user.append(self.user_id)
                prev_level.append(dict(self._fields['tks_approvers_level'].selection).get(self.tks_approvers_level))

        # Panggil write untuk memperbarui data
        res = super(ApprovalApprover, self).write(vals)
        if prev_user and self.request_id.request_status not in ['refused','cancel'] and self.request_id.tks_already_submit:
            self.tks_prev_user = f'{prev_user[0].name} ({prev_level[0]})'

        if 'tks_approvers_level' in vals:
            current_user = self.user_id
            current_employee = current_user.employee_id
            if self.tks_approvers_level not in current_employee.tks_approver_level_ids.mapped("code"):
                raise ValidationError(_("%s is not belong to the current level. Please select another user for this level.", self.user_id.name))

        # Operasi setelah perubahan
        for record in self.browse(records_with_changed_user):
            if record.status == 'pending':
                record._create_activity()

        return res

    # New Function
    def view_edit_data(self):
        return {
            'name': _('Editor Approver'),
            'type': 'ir.actions.act_window',
            'res_id': self.id,
            'view_mode': 'form',
            'res_model': 'approval.approver',
            'view_id': self.env.ref('tks_specific.approval_approver_existing_form').id,
            "target": "new",
        }

    def action_delete(self):
        self.sudo().unlink()
