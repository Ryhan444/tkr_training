from odoo import api, models, fields

class MailThread(models.AbstractModel):
    _inherit = "mail.thread"

    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        res = super(MailThread, self).message_post(**kwargs)
        if 'attachment_ids' in kwargs and kwargs.get('attachment_ids'):
            attachment = self.env['ir.attachment'].browse(kwargs.get('attachment_ids')[0])
            attachment.description = "attach documents"
        return res
