from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_inv_address_status_id = fields.Many2one('tks.inv.address.status', string="Invoice Address Status")

class TksInvAddressStatus(models.Model):
    _name = 'tks.inv.address.status'
    _description = 'Invoice Address Status'

    name = fields.Char(string="Invoice Address Status")