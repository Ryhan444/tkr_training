from odoo import fields, models, _, api
from datetime import timedelta, datetime, time
from odoo.exceptions import ValidationError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    @api.constrains("tks_im_37_safety_driving_training_total_participant")
    def check_tks_im_37_safety_driving_training_total_participant(self):
        for rec in self:
            if rec.tks_im_37_safety_driving_training_total_participant and not rec.tks_im_37_safety_driving_training_total_participant.isdigit():
                raise ValidationError(_("Total Participant must be a Number"))

    tks_im_37_safety_driving_training_date = fields.Datetime('Date')    
    tks_im_37_safety_driving_training_location = fields.Char('Location')
    tks_im_37_safety_driving_training_total_participant = fields.Char('Total  Participant')
    tks_im_37_safety_driving_training_topic_materials = fields.Text('Topic & Materials') 
    tks_im_37_safety_driving_training_total_expected_cost = fields.Monetary(
        string=_("Total Expected Cost"),
        currency_field="tks_currency_id",
    )
    tks_im_37_safety_driving_training_cost_allocation = fields.Selection([
        ('profitability_deduction', 'Profitability Deduction'),
        ('csr_budget', 'CSR Budget'),
    ], string='Cost Allocation')
    tks_im_37_safety_driving_training_cost_allocation_id = fields.Many2one('opl.training.cost.allocation', string='Cost Allocation')
    tks_im_37_safety_driving_training_ids = fields.One2many(
        'opl.safety.driving.training', 
        'request_id', string='OPL - Safety Driving Training'
    )

class OplSafetyDrivingTraining(models.Model):
    _name = 'opl.safety.driving.training'
    _description = 'OPL Safety Driving Training'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')

class OplTrainingCostAllocation(models.Model):
    _name = 'opl.training.cost.allocation'
    _description = 'OPL Training Cost Allocation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    name = fields.Char(string='Name')

    