from odoo import models, fields, api, _
from odoo.exceptions import UserError
from dateutil.relativedelta import relativedelta
from datetime import datetime
import logging

_logger = logging.getLogger(__name__)


class RepairOrder(models.Model):
    _name = "repair.order"
    _description = "SPK"
    _inherit = [
        "repair.order",
    ]

    # Custom duration tracking for state field
    state_duration_tracking = fields.Json(
        string="State Duration Tracking",
        default=dict,
        compute="_compute_state_duration_tracking",
        help="JSON mapping state values to seconds spent in each state.",
    )
    state_last_update = fields.Datetime(
        string="Last State Update",
        default=lambda self: fields.Datetime.now(),
        help="Datetime when the state was last changed.",
    )

    state_duration_tracking_display = fields.Char(
        string="Duration (readable)",
        compute="_compute_state_duration_tracking_display",
        store=False,
    )

    plate_number = fields.Char(
        string="Plate Number",
        tracking=True,
        related="ticket_id.plate_number",
        store=True,
    )
    cdp_release_date = fields.Datetime(string="Release Date")
    cdp_complete_date = fields.Datetime(string="Complete Date")
    cdp_expired_date = fields.Datetime(
        string="Expired Date", compute="_get_expired_date", store=True
    )

    # Related Details
    cdp_type_inquiry_id = fields.Many2one(
        "type.inquiry", related="ticket_id.type_inquiry_id"
    )
    cdp_plate_number = fields.Char(
        string="Plate Number", tracking=True, related="ticket_id.plate_number"
    )
    cdp_brand = fields.Char("Brand", tracking=True, related="ticket_id.brand")
    cdp_type_details_service = fields.Char(
        string="Type", tracking=True, related="ticket_id.type_details_service"
    )
    cdp_year = fields.Integer("Year", tracking=True, related="ticket_id.year")
    cdp_kilometer = fields.Float(
        string="Kilometer",
        tracking=True,
    )
    cdp_rent_status = fields.Char(
        "Rent Status", tracking=True, related="ticket_id.rent_status"
    )
    cdp_registered_area = fields.Char(
        "Registered Area", tracking=True, related="ticket_id.registered_area"
    )
    cdp_actual_location = fields.Char(
        "Actual Location", tracking=True, related="ticket_id.actual_location"
    )
    cdp_desciption_service = fields.Text(
        "Description", tracking=True, related="ticket_id.desciption_service"
    )
    cdp_color = fields.Char(
        string="Color", tracking=True, related="ticket_id.cdp_color"
    )
    cdp_pic_call_center = fields.Char(
        "PIC Call Center", tracking=True, related="ticket_id.pic_call_center"
    )

    cdp_department_id = fields.Many2one(
        "hr.department",
        string="Escalate to",
        tracking=True,
        related="ticket_id.department_id",
    )

    cdp_usr_id = fields.Many2one(
        "res.users", string="Escalate to", tracking=True, related="ticket_id.usr_id"
    )

    cdp_category_id = fields.Many2one(
        "category.type",
        string="Category",
        tracking=True,
        default=False,
        related="ticket_id.category_id",
    )

    cdp_is_inprogress = fields.Boolean(
        string="Inprogress", related="ticket_id.is_inprogress"
    )

    cdp_attach_1 = fields.Binary("Attachment", related="ticket_id.attach_1")
    cdp_attach_2 = fields.Binary("Attachment", related="ticket_id.attach_2")
    cdp_attach_3 = fields.Binary("Attachment", related="ticket_id.attach_3")

    # helper booleans
    cdp_is_service = fields.Boolean(related="ticket_id.is_service")
    cdp_is_claim = fields.Boolean(related="ticket_id.is_claim")
    cdp_is_asset = fields.Boolean(related="ticket_id.is_asset")
    cdp_is_finance = fields.Boolean(related="ticket_id.is_finance")
    cdp_is_pool = fields.Boolean(related="ticket_id.is_pool")
    cdp_is_marketing = fields.Boolean(related="ticket_id.is_marketing")
    cdp_is_marketing_oth = fields.Boolean(related="ticket_id.is_marketing_oth")
    cdp_is_marketing_only = fields.Boolean(related="ticket_id.is_marketing_only")

    cdp_is_barcode_request = fields.Boolean(related="ticket_id.is_barcode_request")
    cdp_is_unit_delivery = fields.Boolean(related="ticket_id.is_unit_delivery")

    # extra fields
    cdp_pic_name_1 = fields.Char("PIC Name", related="ticket_id.pic_name_1")
    cdp_pic_contact = fields.Char("PIC Contact", related="ticket_id.pic_contact")
    cdp_relocation_address = fields.Char(
        "Relocation Address", related="ticket_id.relocation_address"
    )
    cdp_team_id = fields.Many2one(
        "helpdesk.team", string="Team", related="ticket_id.team_id", required=True
    )
    cdp_repair_count = fields.Integer(
        string="Repair Count", compute="_compute_cdp_repair_count", store=True
    )
    cdp_responsibles = fields.Many2one(
        "res.users", string="Responsible", related="ticket_id.cdp_responsibles"
    )
    cdp_related_spk = fields.Many2one("repair.order", string="Related SPK")
    cdp_related_inq_spk_ids = fields.One2many(
        "repair.order", related="ticket_id.repair_ids"
    )
    cdp_is_service_user = fields.Boolean(related="ticket_id.user_is_service")
    cdp_schedule_date = fields.Date(string="Scheduled Date")
    cdp_is_rel_not_ext = fields.Boolean(
        string="Is related external", compute="_compute_is_related_external", store=True
    )
    revised_reason = fields.Text("Revised Reason")
    cancel_reason = fields.Text("Cancel Reason")
    kanban_state = fields.Selection(
        [
            ("normal", "In Progress"),
            ("done", "Release To Customer"),
        ],
        string="Kanban State",
        copy=False,
        default="normal",
        required=True,
    )
    cdp_description = fields.Char(string="Description")

    @api.depends("cdp_related_spk")
    def _compute_is_related_external(self):
        for repair in self:
            state = False
            if repair.cdp_related_spk:
                if repair.cdp_related_spk.cdp_service_location != "external":
                    state = False
                else:
                    state = True
            repair.cdp_is_rel_not_ext = state

    @api.depends("ticket_id", "ticket_id.repair_ids")
    def _compute_cdp_repair_count(self):
        for repair in self:
            count = 0
            if repair.ticket_id:
                count = len(repair.ticket_id.repair_ids)
            repair.cdp_repair_count = count

    @api.depends("state_duration_tracking")
    def _compute_state_duration_tracking_display(self):
        for rec in self:
            val = rec.state_duration_tracking or {}
            if not val:
                rec.state_duration_tracking_display = ""
                continue

            total_seconds = sum(val.values()) if isinstance(val, dict) else 0
            days = total_seconds // 86400
            duration = f"{int(days)}d" if days != "0" else "0d"

            if rec.state != "complete":
                rec.state_duration_tracking_display = duration
            else:
                rec.state_duration_tracking_display = "0d"

    def _cdp_get_default_curr(self):
        return self.env["res.currency"].search([("name", "=", "IDR")], limit=1).id

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("in_approval", "In Approval"),
            ("released", "Released"),
            ("complete", "Complete"),
            ("cancel", "Cancelled"),
        ],
        string="Status",
        copy=False,
        default="draft",
        readonly=True,
        tracking=True,
        index=True,
        help="* The 'Draft' status is used when a new SPK is being created and has not yet been confirmed.\n"
        "* The 'In Approval' status is indicates that the SPK is currently going through the approval process.\n"
        "* The 'Released' status is used when the SPK has been approved and officially released.\n"
        "* The 'Complete' status is set when the SPK process has been fully completed.\n"
        "* The 'Cancelled' status is used when user cancel SPK.",
    )
    # field new state ini hanya mirroring dari field state, tapi dengan urutan yang berbeda untuk keperluan grouping di kanban view
    new_state = fields.Selection(
        [
            ("1_draft", "Draft"),
            ("2_in_approval", "In Approval"),
            ("3_released", "Released"),
            ("4_complete", "Complete"),
            ("5_cancel", "Cancelled"),
        ],
        string="Status",
        compute="_compute_new_state",
        store=True,
    )

    @api.depends("state")
    def _compute_new_state(self):
        for rec in self:
            mapping = {
                "draft": "1_draft",
                "in_approval": "2_in_approval",
                "released": "3_released",
                "complete": "4_complete",
                "cancel": "5_cancel",
            }
            rec.new_state = mapping.get(rec.state, rec.state)

    @api.model
    def create(self, vals_list):
        # Support both single and multi create
        schedule_date = False
        if isinstance(vals_list, dict):
            vals_list = [vals_list]
        now = fields.Datetime.now()
        for vals in vals_list:
            if "cdp_schedule_date" in vals and vals["cdp_schedule_date"] != False:
                schedule_date = datetime.strptime(vals["cdp_schedule_date"], "%Y-%m-%d")
            vals.setdefault("state_last_update", now)
            vals.setdefault("state_duration_tracking", {})
        records = super().create(vals_list)
        # ...existing code for sequence assignment...
        for record in records:
            if (
                record.cdp_need_estimation_cost == "yes"
                and not record.cdp_alternative_vendor_ids
            ):
                raise UserError("Alternatives is empty, please fill it first")

            if schedule_date and schedule_date.date() < record.create_date.date():
                raise UserError(
                    "The schedule date cannot be earlier than the creation date."
                )

            if record.cdp_service_location == "external":
                record.name = "_Draft"
            if record.state == "draft":
                record.name = "_Draft"
            if record.cdp_repair_type == "extend":
                record.cdp_service_location = "external"
        return records

    def write(self, vals):
        # Custom duration tracking for state field
        for rec in self:
            if "state" in vals:
                rec.state_last_update = fields.Datetime.now()

            if "cdp_schedule_date" in vals and vals["cdp_schedule_date"] != False:
                if rec.schedule_date:
                    schedule_date = datetime.strptime(
                        vals["cdp_schedule_date"], "%Y-%m-%d"
                    )
                    if schedule_date.date() < rec.create_date.date():
                        raise UserError(
                            "The schedule date cannot be earlier than the creation date."
                        )
            # only wrte on draft state
            if "state" in vals:
                if vals.get("state") == "draft":
                    rec.new_state = "1_draft"

            if "state" in vals:
                if vals.get("state") == "draft":
                    rec.new_state = "1_draft"

            # if "cdp_service_location" in vals:
            #     if not vals.get("cdp_related_spk"):
            #         if vals.get("cdp_service_location") in ["inhouse", "storing"]:
            #             rec.cdp_vendor_state_id = False
            #             rec.cdp_city_id = False
            #             rec.cdp_company_vendor_id = False
            #             rec.cdp_vendor_id = False
            #             rec.cdp_child_workshop_id = False
            #             rec.cdp_spk_type = False
            #         else:
            #             rec.cdp_schedule_date = False
            #             rec.cdp_mechanic_name = False
            #             rec.cdp_subject = False
            #         rec.cdp_description = False

            if "cdp_related_spk" in vals:
                spk = rec.cdp_related_spk

                rec.move_ids.unlink()
                rec.cdp_alternative_vendor_ids.unlink()
                rec.cdp_approval_approvers_ids.unlink()

                if spk.move_ids:
                    rec.move_ids = spk.move_ids.copy()

                if spk.cdp_alternative_vendor_ids:
                    rec.cdp_alternative_vendor_ids = (
                        spk.cdp_alternative_vendor_ids.copy()
                    )

                rec.partner_id = spk.partner_id
                rec.company_id = spk.company_id
                rec.cdp_spk_type = spk.cdp_spk_type
                rec.cdp_service_location = spk.cdp_service_location
                rec.cdp_vendor_state_id = spk.cdp_vendor_state_id
                rec.cdp_city_id = spk.cdp_city_id
                rec.cdp_kilometer = spk.cdp_kilometer
                rec.cdp_company_vendor_id = spk.cdp_company_vendor_id
                rec.cdp_vendor_id = spk.cdp_vendor_id
                rec.cdp_child_workshop_id = spk.cdp_child_workshop_id
                rec.cdp_description = spk.cdp_description
                rec.cdp_repair_type = spk.cdp_repair_type
                rec.cdp_need_estimation_cost = spk.cdp_need_estimation_cost
                rec.cdp_currency_id = spk.cdp_currency_id.id
                rec.cdp_need_budget = spk.cdp_need_budget
                rec.cdp_total_budget_in_app = spk.cdp_total_budget_in_app
                rec.cdp_cost_from_prev_contract = spk.cdp_cost_from_prev_contract
                rec.cdp_cost_from_current_contract = spk.cdp_cost_from_current_contract
                rec.cdp_estimation_cost = spk.cdp_estimation_cost
                rec.cdp_profit_loss = spk.cdp_profit_loss
                rec.cdp_repair_type = "extend"
        return super().write(vals)

    def _compute_state_duration_tracking(self):
        for rec in self:
            prev_state = rec.state
            now = fields.Datetime.now()
            prev_update = (
                rec.state_last_update or rec.create_date or fields.Datetime.now()
            )
            duration = (now - prev_update).total_seconds() if prev_update else 0
            tracking = dict(rec.state_duration_tracking or {})
            if prev_state:
                tracking[prev_state] = tracking.get(prev_state, 0) + int(duration)

            rec.state_duration_tracking = tracking

    def get_state_duration_tracking(self):
        """
        Returns a dict mapping state values to seconds spent in each state, including the current state up to now.
        """
        result = {}
        now = fields.Datetime.now()
        for rec in self:
            tracking = dict(rec.state_duration_tracking or {})
            last_update = rec.state_last_update or rec.create_date or now
            if rec.state:
                duration = (now - last_update).total_seconds() if last_update else 0
                tracking[rec.state] = tracking.get(rec.state, 0) + int(duration)
            result[rec.id] = tracking
        return result

    cdp_repair_type = fields.Selection(
        selection=[("new", " New"), ("extend", "Extend SPK")],
        string="SPK",
        store=True,
    )

    cdp_service_location = fields.Selection(
        string="Service Location",
        selection=[
            ("inhouse", "Inhouse"),
            ("storing", "Storing"),
            ("external", "External"),
        ],
        store=True,
    )

    cdp_vendor_id = fields.Many2one(
        "res.partner",
        "Vendor Name",
    )
    cdp_child_workshop_id = fields.Many2one("res.partner", "Vendor Address")
    cdp_city_id = fields.Many2one("res.city", string="City")
    cdp_vendor_street_1 = fields.Char(
        related="cdp_child_workshop_id.street", string="Vendor Address"
    )
    cdp_vendor_state_id = fields.Many2one(
        "res.country.state",
        "Vendor State",
    )
    cdp_country_id = fields.Many2one(
        "res.country", "Country", related="cdp_vendor_id.country_id"
    )
    cdp_spk_type = fields.Selection(
        string="SPK Type",
        selection=[
            ("inspector", "SPK Inspection"),
            ("repair", "SPK Repair"),
        ],
    )

    cdp_mechanic_name = fields.Char(
        "Mechanic Name",
        index="trigram",
    )
    cdp_subject = fields.Char(
        "Subject",
        index="trigram",
    )
    cdp_attachment = fields.Binary(string="Attach SPKSK", attachment=True)
    cdp_attachment_name = fields.Char(string="Attach SPKSK")
    cdp_need_estimation_cost = fields.Selection(
        selection=[("yes", "Yes"), ("no", "No")],
        string="Need Estimation Cost?",
    )
    cdp_currency_id = fields.Many2one(
        "res.currency", "Currency", default=_cdp_get_default_curr
    )
    cdp_alternative_vendor_ids = fields.One2many(
        "cdp.alternative.vendor", "cdp_repair_id", "Alternative"
    )
    cdp_need_budget = fields.Selection(
        selection=[("yes", "Yes"), ("no", "No")], string="Need Budget?"
    )
    cdp_total_budget_in_app = fields.Monetary(
        "Total Budget in Application",
        currency_field="cdp_currency_id",
    )
    cdp_cost_from_prev_contract = fields.Monetary(
        "Cost From Previous Contract",
        currency_field="cdp_currency_id",
    )
    cdp_cost_from_current_contract = fields.Monetary(
        "Cost From Current Contract",
        currency_field="cdp_currency_id",
    )
    cdp_estimation_cost = fields.Monetary(
        "Estimation Cost",
        currency_field="cdp_currency_id",
        compute="cdp_get_alt_estimation_cost",
        store=True,
    )
    cdp_profit_loss = fields.Monetary(
        "Profit/Loss",
        currency_field="cdp_currency_id",
        compute="_get_profit_loss_amount",
    )

    cdp_approval_approvers_ids = fields.One2many(
        "approval.approver",
        inverse_name="cdp_repair_id",
        string="Approver",
    )
    cdp_company_vendor_id = fields.Many2one("res.partner", "Branch")
    cdp_user_service = fields.Boolean(
        string="Is Service User",
        compute="_compute_current_user_is_service",
        store=False,
    )
    cdp_can_approve = fields.Boolean(
        string="Can Approve?", compute="_get_can_approve_status"
    )
    cdp_spk_ref = fields.Char(string="SPK Ref")
    cdp_spk_ref_id = fields.Many2one(
        "repair.order",
        string="SPK Ref.",
        domain=[
            ("cdp_spk_type", "=", "inspector"),
            ("state", "in", ["released", "complete"]),
        ],
    )

    # additional
    cdp_user_is_call_center = fields.Boolean(
        "Call center user", related="ticket_id.user_is_call_center", store=False
    )
    call_center_team = fields.Many2one(
        "res.partner",
        "Call Center Team",
        default=lambda self: self.env["res.partner"].search(
            [("name", "=", "Call Center Team")]
        ),
    )
    cdp_is_approver_user = fields.Boolean(
        "Is in Approver?", compute="_get_is_user_in_approver"
    )

    # Compute
    @api.depends("ticket_id", "ticket_id.repair_ids")
    def _get_is_user_in_approver(self):
        for rec in self:
            is_approver = False
            if rec.ticket_id:
                all_approver_user = rec.ticket_id.repair_ids.mapped(
                    "cdp_approval_approvers_ids"
                ).mapped("user_id")
                if (
                    self.env.user in all_approver_user
                    and rec.create_uid != self.env.user
                ):
                    is_approver = True
            rec.cdp_is_approver_user = is_approver

    def _get_can_approve_status(self):
        for rec in self:
            can_approve = False
            if rec.cdp_approval_approvers_ids:
                for approver in rec.cdp_approval_approvers_ids.filtered(
                    lambda x: x.user_id == self.env.user and not x.cdp_approved
                ):
                    approver_avail = rec.cdp_approval_approvers_ids.filtered(
                        lambda x: not x.cdp_approved
                    )
                    current_approver = min(approver_avail.mapped("id"))
                    if approver.id == current_approver:
                        can_approve = True
                        break
                    else:
                        can_approve = False

            rec.cdp_can_approve = can_approve

    def _compute_current_user_is_service(self):
        for rec in self:
            rec.cdp_user_service = self.env.user.is_service

    @api.depends("cdp_service_location")
    def _get_spk_type(self):
        for repair in self:
            type = ""
            if repair.cdp_service_location:
                if repair.cdp_service_location == "external":
                    type = "extend"
                else:
                    type = "new"
            repair.cdp_repair_type = type

    def inverse_spk_type(self):
        for repair in self:
            if repair.cdp_service_location:
                if repair.cdp_service_location != "external":
                    repair.cdp_repair_type = "new"

    @api.depends("cdp_release_date")
    def _get_expired_date(self):
        for repair in self:
            expired_date = False
            if repair.cdp_release_date:
                expired_date = repair.cdp_release_date + relativedelta(days=7)

            repair.cdp_expired_date = expired_date

    @api.depends(
        "cdp_alternative_vendor_ids",
        "cdp_alternative_vendor_ids.cdp_alternative",
        "cdp_alternative_vendor_ids.cdp_est_cost",
    )
    def cdp_get_alt_estimation_cost(self):
        for repair in self:
            est_cost = 0.0
            if repair.cdp_alternative_vendor_ids:
                for alt in repair.cdp_alternative_vendor_ids.filtered(
                    lambda x: x.cdp_alternative == "selected"
                ):
                    est_cost += alt.cdp_est_cost
            repair.cdp_estimation_cost = est_cost

    @api.depends(
        "cdp_need_budget",
        "cdp_cost_from_current_contract",
        "cdp_total_budget_in_app",
        "cdp_cost_from_prev_contract",
        "cdp_estimation_cost",
    )
    def _get_profit_loss_amount(self):
        for repair in self:
            total_amount = 0.0
            if repair.cdp_need_budget:
                total_amount = repair.cdp_total_budget_in_app - (
                    repair.cdp_cost_from_current_contract
                    + repair.cdp_cost_from_prev_contract
                    + repair.cdp_estimation_cost
                )
            else:
                total_amount = 0.0
            repair.cdp_profit_loss = total_amount

    # Onchange
    @api.onchange("cdp_need_estimation_cost")
    def _onchange_need_estimation_cost(self):
        if self.cdp_need_estimation_cost == "no":
            self.cdp_need_budget = "no"

    # @api.model_create_multi
    # def create(self, vals_list):
    #     record = super().create(vals_list)
    #     if record.cdp_service_location == "inhouse":
    #         sequence = self.env["ir.sequence"].next_by_code("spk.inh")
    #     elif record.cdp_service_location == "storing":
    #         sequence = self.env["ir.sequence"].next_by_code("spk.sto")
    #     elif record.cdp_service_location == "external":
    #         sequence = self.env["ir.sequence"].next_by_code("spk.ext")
    #     record.name = sequence
    #     return record

    def action_submit(self):
        for rec in self:
            if (
                rec.cdp_service_location == "external"
                and rec.cdp_need_estimation_cost == "yes"
            ):
                if not rec.move_ids:
                    notification = {
                        "type": "ir.actions.client",
                        "tag": "display_notification",
                        "params": {
                            "title": _("Parts Empty"),
                            "message": _("Parts must be filled."),
                            "sticky": False,
                            "type": "danger",
                        },
                    }
                    return notification

            if (
                rec.cdp_service_location == "external"
                and rec.cdp_need_estimation_cost == "yes"
                and not rec.cdp_alternative_vendor_ids
            ):
                raise UserError("Alternatives is empty, please fill it first")

            if (
                rec.cdp_service_location == "external"
                and rec.cdp_repair_type != "extend"
            ):
                template = self.env.ref("tks_helpdesk.cdp_email_template_reviewer_spk")
                if not rec.cdp_approval_approvers_ids:
                    notification = {
                        "type": "ir.actions.client",
                        "tag": "display_notification",
                        "params": {
                            "title": _("Approver Empty"),
                            "message": _("Approver must be filled."),
                            "sticky": False,
                            "type": "danger",
                        },
                    }
                    return notification

                approvers = rec.cdp_approval_approvers_ids.mapped("user_id")
                if len(rec.cdp_approval_approvers_ids) == 1:
                    rec.message_subscribe(
                        partner_ids=[
                            rec.cdp_approval_approvers_ids.user_id.partner_id.id
                        ]
                    )
                    rec.with_context(from_spk_inq=True).activity_schedule(
                        "mail.mail_activity_data_todo",
                        user_id=rec.cdp_approval_approvers_ids.user_id.id,
                    )
                if len(rec.cdp_approval_approvers_ids) > 1:
                    for appr in rec.cdp_approval_approvers_ids:
                        min_approver = min(rec.cdp_approval_approvers_ids.mapped("id"))
                        if (
                            appr.cdp_approver_level_repair == "1"
                            and appr.id == min_approver
                        ):
                            rec.message_subscribe(
                                partner_ids=[appr.user_id.partner_id.id]
                            )
                            rec.with_context(from_spk_inq=True).activity_schedule(
                                "mail.mail_activity_data_todo",
                                user_id=appr.user_id.id,
                            )
                if template:
                    if len(approvers) == 1:
                        template.sudo().write({"partner_to": approvers.partner_id.id})
                        template.with_context(
                            notify_followers=False,
                        ).send_mail(self.id, force_send=True)
                    elif len(approvers) > 1:
                        first_role = min(
                            rec.cdp_approval_approvers_ids.mapped(
                                "cdp_approver_level_repair"
                            )
                        )
                        first_approvers = rec.cdp_approval_approvers_ids.filtered(
                            lambda x: x.cdp_approver_level_repair == first_role
                        ).mapped("user_id")
                        partner_ids = ", ".join(
                            str(a.partner_id.id) for a in first_approvers
                        )
                        template.sudo().write({"partner_to": partner_ids})
                        template.with_context(
                            notify_followers=False,
                        ).send_mail(self.id, force_send=True)
                rec.message_post(
                    body="Dokumen telah diajukan. Menunggu proses persetujuan."
                )
                rec.name = "New"
                rec.state = "in_approval"
            else:
                template_release = self.env.ref(
                    "tks_helpdesk.cdp_email_template_new_released_spk"
                )
                sequence = False
                if rec.cdp_service_location == "inhouse":
                    sequence = self.env["ir.sequence"].next_by_code("spk.inh")
                elif rec.cdp_service_location == "storing":
                    sequence = self.env["ir.sequence"].next_by_code("spk.sto")
                elif rec.cdp_related_spk:
                    sequence = self.env["ir.sequence"].next_by_code("spk.ext")

                rec.name = sequence
                rec.cdp_release_date = fields.Datetime.now()
                rec.state = "released"
                if template_release and rec.create_uid.id != 113:
                    template_release.sudo().write(
                        {
                            "partner_to": f"({rec.cdp_usr_id.partner_id.id}), ({rec.cdp_responsibles.partner_id.id}), ({188})"
                        }
                    )
                    template_release.with_context(notify_followers=False).send_mail(
                        self.id, force_send=True
                    )

                message = _("SPK Released")
                subtype_id = self.env["ir.model.data"]._xmlid_to_res_id("mail.mt_note")
                for order in rec.filtered("ticket_id"):
                    order.ticket_id.message_post_with_source(
                        "helpdesk.ticket_conversion_link",
                        render_values={"created_record": order, "message": message},
                        subtype_id=subtype_id,
                    )

            if self.cdp_repair_type == "extend":
                # prev_spk = rec.ticket_id.repair_ids.filtered(
                #     lambda x: x.state == "released"
                #     and x.cdp_service_location == "external"
                #     and x.id
                #     == max(
                #         rec.ticket_id.repair_ids.filtered(
                #             lambda y: y.id != rec.id
                #         ).mapped("id")
                #     )
                # )
                prev_spk = self.cdp_related_spk
                if prev_spk:
                    prev_spk.sudo().write({"state": "cancel"})

    def action_approve(self):
        user_approval = self.cdp_approval_approvers_ids.filtered(
            lambda a: a.user_id == self.env.user and not a.cdp_approved
        )[0]
        approvers = self.cdp_approval_approvers_ids.filtered(
            lambda x: x.id > user_approval.id and not x.cdp_approved
        ).mapped("id")
        next_approver = False
        next_id = False

        if approvers:
            next_id = min(approvers)

        if next_id:
            next_approver = self.cdp_approval_approvers_ids.filtered(
                lambda x: x.id == next_id
            )

        current_level = user_approval.cdp_approver_level_repair
        activity = self.activity_ids.filtered(
            lambda x: x.user_id.id == user_approval.user_id.id
        )
        template = self.env.ref("tks_helpdesk.cdp_email_template_reviewer_spk")
        template_release = self.env.ref(
            "tks_helpdesk.cdp_email_template_new_released_spk"
        )
        if user_approval.cdp_approved:
            raise UserError("You already approved this SPK")

        if not user_approval:
            raise UserError("Anda tidak terdaftar sebagai approver untuk dokumen ini.")

        if len(self.cdp_approval_approvers_ids) == 1:
            self.cdp_approval_approvers_ids.sudo().write({"cdp_approved": True})
            # if activity:
            #     activity.action_feedback()

            if all(
                approved == True
                for approved in self.cdp_approval_approvers_ids.mapped("cdp_approved")
            ):
                self.state = "released"
        elif len(self.cdp_approval_approvers_ids) > 1:
            if next_approver:
                self.message_subscribe(
                    partner_ids=[next_approver.user_id.partner_id.id]
                )
                self.with_context(from_spk_inq=True).activity_schedule(
                    "mail.mail_activity_data_todo",
                    user_id=next_approver.user_id.id,
                )

        if activity:
            # activity.action_feedback()
            if template:
                if next_approver:
                    template.sudo().write(
                        {"partner_to": next_approver[0].user_id.partner_id.id}
                    )
                    template.with_context(
                        notify_followers=False,
                    ).send_mail(self.id, force_send=True)
        user_approval.cdp_approved = True

        if all(
            approved == True
            for approved in self.cdp_approval_approvers_ids.mapped("cdp_approved")
        ):
            self.state = "released"
            self.cdp_release_date = fields.Datetime.now()
            sequence = self.env["ir.sequence"].next_by_code("spk.ext")
            if sequence:
                self.name = sequence

            if template_release and self.create_uid.id != 113:
                template_release.sudo().write(
                    {
                        "partner_to": f"({self.cdp_usr_id.partner_id.id}), ({self.cdp_responsibles.partner_id.id}), ({188})"
                    }
                )
                template_release.with_context(notify_followers=False).send_mail(
                    self.id, force_send=True
                )

            message = _("SPK Approved")
            subtype_id = self.env["ir.model.data"]._xmlid_to_res_id("mail.mt_note")
            for order in self.filtered("ticket_id"):
                order.ticket_id.message_post_with_source(
                    "helpdesk.ticket_conversion_link",
                    render_values={"created_record": order, "message": message},
                    subtype_id=subtype_id,
                )

    def action_reject(self):
        self.state = "draft"
        self.message_post(body="SPK Refused.")
        template = self.env.ref("tks_helpdesk.cdp_email_template_spk_rejected")
        if template:
            template.with_context(notify_followers=False).send_mail(
                self.id, force_send=True
            )

    def _action_revised(self):
        self.state = "draft"
        self.cdp_approval_approvers_ids.filtered(lambda a: a.cdp_approved).sudo().write(
            {"cdp_approved": False}
        )
        template = self.env.ref("tks_helpdesk.cdp_email_template_spk_rejected")
        if template:
            template.with_context(notify_followers=False).send_mail(
                self.id, force_send=True
            )
        self.with_context(from_spk_inq=True).activity_schedule(
            "mail.mail_activity_data_todo",
            user_id=self.cdp_usr_id.id,
        )
        self.message_post(body="SPK Revised.")

    def action_revised(self):
        return {
            "name": _("Revised Reason"),
            "res_model": "spk.reason",
            "view_mode": "form",
            "views": [[False, "form"]],
            "context": {
                "active_ids": self.ids,
                "default_cdp_spk_id": self.id,
                "button": "revised",
            },
            "target": "new",
            "type": "ir.actions.act_window",
        }

    def _action_cancel(self):
        self.state = "cancel"
        self.message_post(body="SPK Cancelled.")

    def action_cancel(self):
        return {
            "name": _("Cancel Reason"),
            "res_model": "spk.reason",
            "view_mode": "form",
            "views": [[False, "form"]],
            "context": {
                "active_ids": self.ids,
                "default_cdp_spk_id": self.id,
                "button": "cancel",
            },
            "target": "new",
            "type": "ir.actions.act_window",
        }

    def action_complete(self):
        for rec in self:
            if (
                self.cdp_user_is_call_center
                or self.env.user.is_service
                and self.cdp_service_location == "external"
            ):
                rec.state = "complete"
                rec.cdp_complete_date = fields.Datetime.now()
            elif self.env.user.is_service and self.cdp_service_location != "external":
                if not self.cdp_attachment:
                    raise UserError("Please attach SPKSK before you complete this SPK")
                rec.state = "complete"
                rec.cdp_complete_date = fields.Datetime.now()

            template = self.env.ref("tks_helpdesk.cdp_email_template_spk_completed")
            if template:
                template.sudo().write(
                    {
                        "partner_to": f"({self.cdp_responsibles.partner_id.id}), ({self.env.user.partner_id.id}), ({188})"
                    }
                )
                template.with_context(notify_followers=False).send_mail(
                    self.id, force_send=True
                )
            message = _("Repair Complete")
            subtype_id = self.env["ir.model.data"]._xmlid_to_res_id("mail.mt_note")
            for order in rec.filtered("ticket_id"):
                order.ticket_id.message_post_with_source(
                    "helpdesk.ticket_conversion_link",
                    render_values={"created_record": order, "message": message},
                    subtype_id=subtype_id,
                )

    # CRON
    def _send_spk_reminder(self):
        template = self.env.ref("tks_helpdesk.cdp_email_template_spk_expired_reminder")
        odoo_bot = self.env.ref("base.user_root")
        min_2 = fields.Date.today() + relativedelta(days=2)
        start_dt = datetime.combine(min_2, datetime.min.time())
        end_dt = datetime.combine(min_2, datetime.max.time())

        expired_spk = self.env["repair.order"].search(
            [
                ("cdp_expired_date", ">=", start_dt),
                ("cdp_expired_date", "<=", end_dt),
            ]
        )
        for expired in expired_spk:
            body_html = template._render_field("body_html", expired.ids)[expired.id]
            if expired:
                expired.with_context(notify_followers=False).message_post(
                    body=body_html,
                    message_type="comment",
                    subtype_xmlid="mail.mt_comment",
                    author_id=odoo_bot.partner_id.id,
                )

    # additional
    def action_preview_pdf(self):
        self.ensure_one()
        if self.cdp_service_location == "inhouse":
            report = "tks_helpdesk.action_spk_inhouse_report"
        elif self.cdp_service_location == "storing":
            report = "tks_helpdesk.action_surat_tugas_storing_report"
        elif self.cdp_service_location == "external":
            if self.cdp_spk_type == "inspector":
                report = "tks_helpdesk.action_spkl_inspection_report"
            elif self.cdp_spk_type == "repair":
                report = "tks_helpdesk.action_spkl_repair_report"
        else:
            raise UserError(
                "preview only available for inhouse, storing and external service location"
            )
        filename = f"{self.name or 'SPK'}_{self.id}.pdf"
        return {
            "type": "ir.actions.act_url",
            "target": "new",
            "url": f"/report/pdf/{report}/{self.id}?download=false&filename={filename}",
        }

    def action_download_pdf(self):
        self.ensure_one()
        report = self._get_report_name()
        return self.env.ref(report).report_action(self)

    def _get_report_name(self):
        if self.cdp_service_location == "inhouse":
            return "tks_helpdesk.action_spk_inhouse_report"
        elif self.cdp_service_location == "storing":
            return "tks_helpdesk.action_surat_tugas_storing_report"
        elif self.cdp_service_location == "external":
            if self.cdp_spk_type == "inspector":
                return "tks_helpdesk.action_spkl_inspection_report"
            elif self.cdp_spk_type == "repair":
                return "tks_helpdesk.action_spkl_repair_report"
        raise UserError("Unsupported service location or type")

    @api.onchange("cdp_service_location")
    def _onchange_cdp_service_location_cleanup(self):
        for record in self:
            if record.cdp_service_location in ["inhouse", "storing", "external"]:
                record.cdp_schedule_date = False
                record.cdp_mechanic_name = " "
                record.cdp_subject = " "
                if record.move_ids:
                    # record.move_ids.unlink()
                    record.move_ids = False
                record.cdp_mechanic_name = ""
                record.cdp_subject = ""
                if record.cdp_repair_type == "new":
                    record.cdp_description = " "
                    record.cdp_description = ""

            if record.cdp_repair_type == "extend":
                if not record.move_ids:
                    record.move_ids = record.cdp_related_spk.move_ids.copy().ids


class CdpAlternativeVendor(models.Model):
    _name = "cdp.alternative.vendor"

    cdp_repair_id = fields.Many2one("repair.order", "Repair", ondelete="cascade")
    cdp_alternative = fields.Selection(
        selection=[
            ("selected", "Selected Workshop"),
            ("alt_1", "Alt Workshop 1"),
            ("alt_2", "Alt Workshop 2"),
        ],
        string="Alternative",
    )
    cdp_currency_id = fields.Many2one(
        "res.currency", "Currency", related="cdp_repair_id.cdp_currency_id"
    )
    cdp_vendor_id = fields.Many2one(
        "res.partner",
        "Vendor",
        domain=[("cdp_is_vendor", "=", True)],
        compute="_get_workshop_id",
        inverse="_inverse_workshop_id",
        store=True,
    )
    cdp_est_cost = fields.Float("Estimated Cost")

    @api.depends("cdp_alternative", "cdp_repair_id")
    def _get_workshop_id(self):
        for alt in self:
            workshop = False
            if (
                alt.cdp_repair_id
                and alt.cdp_repair_id.cdp_vendor_id
                and alt.cdp_alternative == "selected"
            ):
                workshop = alt.cdp_repair_id.cdp_vendor_id.id
            else:
                workshop = alt.cdp_vendor_id
            alt.cdp_vendor_id = workshop

    def _inverse_workshop_id(self):
        for alt in self:
            workshop = False
            if (
                alt.cdp_repair_id
                and alt.cdp_repair_id.cdp_vendor_id
                and alt.cdp_alternative == "selected"
            ):
                workshop = alt.cdp_repair_id.cdp_vendor_id.id
            else:
                workshop = alt.cdp_vendor_id
            alt.cdp_vendor_id = workshop
