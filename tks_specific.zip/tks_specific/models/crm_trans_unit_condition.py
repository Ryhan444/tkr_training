from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_trans_unit_condition_id = fields.Many2one('tks.trans.unit.condition', string="Unit Condition")
    tks_trans_replacement_car_id = fields.Many2one('tks.big.project', string="Replacement Car")
    tks_trans_maintenance_coverage_id = fields.Many2one('tks.trans.maintenance.coverage', string="Maintenance Coverage")
    tks_trans_stnk_coverage_id = fields.Many2one('tks.big.project', string="STNK Coverage")
    tks_trans_kir_coverage_id = fields.Many2one('tks.big.project', string="KIR Coverage")
    tks_trans_stnk_cover_id = fields.Many2one('tks.big.project', string="Insurance Coverage")

class TksTransType(models.Model):
    _name = 'tks.trans.unit.condition'
    _description = 'Unit Condition'

    name = fields.Char(string="Unit Condition")


class TksTransMainCover(models.Model):
    _name = 'tks.trans.maintenance.coverage'
    _description = 'Maintenance Coverage'

    name = fields.Char(string="Maintenance Coverage")

