from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_financial_statement_id = fields.Many2one('tks.financial.statement', string="Financial Statement")

class TksFinancialStatement(models.Model):
    _name = 'tks.financial.statement'
    _description = 'Financial Statement'

    name = fields.Char(string="Financial Statement")