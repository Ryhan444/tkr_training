from odoo import fields, models, _, api
from datetime import timedelta, datetime, time

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_40_waive_duty_stamp_fee_for_customer_contract_no = fields.Char(
        'Contract No'
    )
    tks_im_40_waive_duty_stamp_fee_for_customer_addendum_no = fields.Char(
        'Addendum No'
    )   
    tks_im_40_waive_duty_stamp_fee_for_customer_total_amount = fields.Monetary(
        string=_("Total Amount Waived"),
        currency_field="tks_currency_id",
    )
    tks_im_40_waive_duty_stamp_fee_for_customer_period_start = fields.Date(
        'Period Start'
    )
    tks_im_40_waive_duty_stamp_fee_for_customer_period_end = fields.Date(
        'Period Date'
    )
    tks_im_40_waive_duty_stamp_fee_for_customer_reason_explanation = fields.Text(
        'Reason / Explanation'
    )
    tks_im_40_waive_duty_stamp_fee_for_customer_ids = fields.One2many(
        'opl.waive.duty.stamp.fee.for.customer', 
        'request_id', string='OPL - Waive Duty Stamp Fee For Customer'
    )

    
class OplWaiveDutyStampFeeForCustomer(models.Model):
    _name = 'opl.waive.duty.stamp.fee.for.customer'
    _description = 'OPL Waive Duty Stamp Fee For Customer'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    item = fields.Selection([
        ('bc', 'Business Consideration'),
        ('calculation', 'Calculation (if any)'),
    ], string='Item')
    remarks = fields.Text('Remarks')


    