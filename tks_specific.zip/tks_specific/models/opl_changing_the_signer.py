from odoo import _, api, fields, models

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_signer_line_fields = any(
            not line.before or not line.after
            for line in self.tks_opl_changing_signer_line_ids
        )
        if self.tks_has_tks_im_changing_signer != 'no' and (
            not self.tks_opl_changing_signer_line_ids or missing_signer_line_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _("List of Signer's Changes Empty"),
                    'message': _("List of Signer's Changes must be filled."),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


    tks_contract_no_28 = fields.Char('Contract No')
    tks_addendum_no_28 = fields.Char('Addendum No.')
    tks_change_reason_28 = fields.Text('Change Reason')
    tks_effective_date_28 = fields.Date('Effective Date')
    tks_opl_changing_signer_line_ids = fields.One2many('opl.changing.signer', 'request_id', string='Lines OPL - Changing The Signer')
    tks_opl_changing_signer_risk_mitigation_line_ids = fields.One2many('opl.changing.signer.risk.mitigation', 'request_id', string='Lines OPL - Changing The Signer Risk Mitigation')
    
    
class OplChangingSigner(models.Model):
    _name = 'opl.changing.signer'
    _description = 'OPL - Changing The Signer'
    
    @api.depends('request_id')
    def _compute_number(self):
        """Function to compute line numbers"""
        for req in self.mapped('request_id'):
            sequence = 1
            if req.tks_opl_changing_signer_line_ids:
                for lines in req.tks_opl_changing_signer_line_ids:
                    lines.sequence = sequence
                    sequence += 1
            else:
                self.sequence = ''

    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    sequence = fields.Integer(string="No.", compute="_compute_number")
    before = fields.Text('Before')
    after = fields.Text('After')
        
class OplChangingSignerRiskMitigation(models.Model):
    _name = 'opl.changing.signer.risk.mitigation'
    _description = 'OPL - Changing The Signer Risk and Mitigation'
    _rec_name = 'risk_mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')