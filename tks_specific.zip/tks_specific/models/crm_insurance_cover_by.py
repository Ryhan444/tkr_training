from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_insurance_cover_by_id = fields.Many2one('tks.insurance.cover.by', string="Cover By")

class TksTransType(models.Model):
    _name = 'tks.insurance.cover.by'
    _description = 'Cover By'

    name = fields.Char(string="Cover By")