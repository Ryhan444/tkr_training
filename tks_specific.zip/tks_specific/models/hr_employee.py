from odoo import models, fields, _, api
from odoo.exceptions import UserError, ValidationError
from odoo.tools import frozendict


class HrEmployeePrivate(models.Model):
    _inherit = "hr.employee"

    tks_lease_type = fields.Selection(
        string=_("Lease Type"),
        selection=[("fl", "Finance Lease"), ("opl", "Operation Lease")],
    )

    tks_section_id = fields.Many2one('tks.section',string="Section")
    tks_section_head_section_ids = fields.Many2many(
        "tks.section",
        string="Head Section of",
    )
    tks_section_head_dept_ids = fields.Many2many(
        "hr.department", string="Head Department of"
    )
    tks_approver_level_ids = fields.One2many(
        comodel_name="tks.approver.level",
        inverse_name="employee_id",
        string="Approver's Level",
    )

    tks_is_in_section_group = fields.Boolean(
        compute="_compute_is_in_section_group",
    )
    tks_is_in_department_group = fields.Boolean(
        compute="_compute_is_in_department_group",
    )

    def _compute_is_in_section_group(self):
        for employee in self:
            employee.tks_is_in_section_group = False
            if employee.user_id.has_group(
                "tks_specific.tks_group_sale_salesman_section_leads"
            ):
                employee.tks_is_in_section_group = True

    def _compute_is_in_department_group(self):
        for employee in self:
            employee.tks_is_in_department_group = False
            if employee.user_id.has_group(
                "tks_specific.tks_group_sale_salesman_department_leads"
            ):
                employee.tks_is_in_department_group = True

    def write(self, vals):
        res = super(HrEmployeePrivate, self.sudo()).write(vals)
        section_changed = vals.get("tks_section_head_section_ids", [])
        department_changed = vals.get("tks_section_head_dept_ids", [])

        def handle_section(employee, section):
            if (
                section.tks_section_head_id
                and section.tks_section_head_id.id != employee.id
            ):
                raise UserError(
                    _("Section %s already has a head of section.") % section.name
                )
            section.tks_section_head_id = (
                employee.id
                if not section.tks_section_head_id
                else section.tks_section_head_id
            )

        def handle_department(employee, department):
            if department.manager_id and department.manager_id.id != employee.id:
                raise UserError(
                    _("Department %s already has a head of department.")
                    % department.name
                )
            department.manager_id = (
                employee.id if not department.manager_id else department.manager_id
            )

        for employee in self:
            for action, id in section_changed:
                if action == 4 or action == 6:
                    handle_section(employee, self.env["tks.section"].browse(id))
                elif action == 3:
                    deleted_section = self.env["tks.section"].browse(id)
                    if deleted_section.tks_section_head_id.id == employee.id:
                        deleted_section.tks_section_head_id = False

            for action, id in department_changed:
                if action == 4 or action == 6:
                    handle_department(employee, self.env["hr.department"].browse(id))
                elif action == 3:
                    deleted_department = self.env["hr.department"].browse(id)
                    if deleted_department.manager_id.id == employee.id:
                        deleted_department.manager_id = False

        return res


class HrEmployeePublic(models.Model):
    _inherit = "hr.employee.public"

    tks_lease_type = fields.Selection(
        string=_("Lease Type"),
        related='employee_id.tks_lease_type',
    )

    tks_section_id = fields.Many2one('tks.section',string="Section", related="employee_id.tks_section_id")
    tks_approver_level_ids = fields.One2many(
        comodel_name="tks.approver.level",
        inverse_name="employee_id",
        string="Approver's Level",
    )
    tks_section_head_section_ids = fields.Many2many(
        related="employee_id.tks_section_head_section_ids"
    )
    tks_section_head_dept_ids = fields.Many2many(
        related="employee_id.tks_section_head_dept_ids"
    )

    tks_is_in_section_group = fields.Boolean(
        related="employee_id.tks_is_in_section_group",
    )
    tks_is_in_department_group = fields.Boolean(
        related="employee_id.tks_is_in_department_group",
    )

class TksApproverLevel(models.Model):
    _name = "tks.approver.level"
    _description = "Tks Approver Level"

    employee_id = fields.Many2one("hr.employee", string="Employee", ondelete="cascade")
    name = fields.Char(string="Name")
    code = fields.Selection(
        string="Level",
        selection=[
            ("level_0", "None"),
            ("level_1", "Reviewer"),
            ("level_2", "Acknowledger"),
            ("level_3", "Approver"),
            ("level_4", "Final Approver"),
        ],
    )


class HrDepartment(models.Model):
    _inherit = "hr.department"

    tks_section_ids = fields.One2many(
        "tks.section", "tks_department_id", string="Sections"
    )
