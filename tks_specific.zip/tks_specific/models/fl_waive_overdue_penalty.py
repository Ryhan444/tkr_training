from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_8_waive_overdue_penalty = fields.Selection(
        string="Waive Overdue Penalty",
        selection=[
            ("wop_w", "Waive Overdue Penalty(Whole)"),
            ("wop_p", "Waive Overdue Penalty(Partial)"),
        ],
        default="wop_w",
    )
    
    # tks_inv_no_after = fields.Char(string=_("After"))
    tks_im_8_reason_lesse = fields.Char(string="Lesse")

    tks_im_8_reason_tks = fields.Text(string="Reason/Explaination")
    tks_im_8_expected_pay_date_before = fields.Date(
        string=_("Expected Pay Date Before"),
    )
    tks_im_8_expected_pay_date_after = fields.Date(
        string=_("Expected Pay Date After"),
    )
    tks_im_8_period_date_before = fields.Date(
        string=_("Period Date After"),
    )

    tks_im_8_period_date_after = fields.Date(
        string=_("Period Date After"),
    )

    tks_im_8_risk_mitigation_ids = fields.One2many(
        comodel_name="tks.im.8.risk.mitigation",
        inverse_name="tks_im_request_id",
        string="Risk & Mitigation",
        store=True,
    )

    tks_im_8_items_ids = fields.One2many(
        "tks.im.8.items", "tks_im_8_request_id", string=_("Items")
    )

    tks_im_8_contract_number_ids = fields.One2many(
        "tks.im.8.contract.number", "tks_im_request_id", string=_("Contract Number")
    )

    tks_im_8_od_amount_ids = fields.One2many(
        "tks.im.8.od.amount", "tks_im_request_id", string=_("OD Amount")
    )

    tks_im_8_od_days_ids = fields.One2many(
        "tks.im.8.od.days", "tks_im_request_id", string=_("OD Days")
    )

    tks_im_8_overdue_penalty_before_ids = fields.One2many(
        "tks.im.8.overdue.penalty.before", "tks_im_request_id", string=_("Overdue Penalty")
    )

    tks_im_8_overdue_penalty_after_ids = fields.One2many(
        "tks.im.8.overdue.penalty.after", "tks_im_request_id", string=_("Overdue Penalty")
    )

    tks_im_8_amount_original_ids = fields.One2many(
        "tks.im.8.amount.original", "tks_im_request_id", string=_("OD Days")
    )

    tks_im_8_amount_waived_ids = fields.One2many(
        "tks.im.8.amount.waived", "tks_im_request_id", string=_("OD Days")
    )

    tks_im_8_invoice_number_ids = fields.One2many(
        "tks.im.8.invoice.number", "tks_im_request_id", string=_("OD Days")
    )

    tks_im_8_period_date_ids = fields.One2many(
        "tks.im.8.period.date", "tks_im_request_id", string=_("OD Days")
    )

    tks_im_8_expected_date_ids = fields.One2many(
        "tks.im.8.expected.date", "tks_im_request_id", string=_("OD Days")
    )

    def action_confirm(self):
        if self.tks_has_tks_im_waive_overdue_penalty != 'no':
            # contract_number_fields = [not line.tks_im_8_contract_number_before or not line.tks_im_8_contract_number_after for line in self.tks_im_8_contract_number_ids.filtered(lambda x: x)]
            # od_amount_fields = [line.tks_im_8_od_amount_before <= 0 or line.tks_im_8_od_amount_after <= 0 for line in self.tks_im_8_od_amount_ids.filtered(lambda x: x)]
            # od_days_fields = [line.tks_im_8_od_days_before <= 0 or line.tks_im_8_od_days_after <= 0 for line in self.tks_im_8_od_days_ids.filtered(lambda x: x)]
            # overdue_penalty_before_fields = [not line.tks_im_8_collect_overdue_penalty_before or not line.tks_im_8_amount_original_before or not line.tks_im_8_inv_no_before for line in self.tks_im_8_overdue_penalty_before_ids.filtered(lambda x: x)]
            # overdue_penalty_after_fields = [not line.tks_im_8_collect_overdue_penalty_after or not line.tks_im_8_amount_original_after or not line.tks_im_8_inv_no_after for line in self.tks_im_8_overdue_penalty_after_ids.filtered(lambda x: x)]
            # amount_original_fields = [line.tks_im_8_amount_original_before <= 0 or line.tks_im_8_amount_original_after <= 0 for line in self.tks_im_8_amount_original_ids.filtered(lambda x: x)]
            # amount_waived_fields = [line.tks_im_8_amount_waived_before <= 0 or line.tks_im_8_amount_waived_after <= 0 for line in self.tks_im_8_amount_waived_ids.filtered(lambda x: x)]
            # invoice_number_fields = [not line.tks_im_8_inv_no_before or not line.tks_im_8_inv_no_after for line in self.tks_im_8_invoice_number_ids.filtered(lambda x: x)]
            # period_date_fields = [not line.tks_im_8_period_date_before or not line.tks_im_8_period_date_after for line in self.tks_im_8_period_date_ids.filtered(lambda x: x)]
            # expected_date_fields = [not line.tks_im_8_expected_pay_date_before or not line.tks_im_8_expected_pay_date_after for line in self.tks_im_8_expected_date_ids.filtered(lambda x: x)]
            item_fields = [not line.tks_im_8_collect_overdue_penalty_after or not line.tks_im_8_inv_no_after or not line.tks_im_8_collect_overdue_penalty_before or not line.tks_im_8_inv_no_before or not line.tks_im_8_contract_number for line in self.tks_im_8_items_ids.filtered(lambda x: x)]
            if item_fields:
                if any(i for i in item_fields) == True:
                    notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                    return notification
            elif not item_fields:
                notification = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Proposal Line Empty'),
                            'message': _('Proposal line must be filled.'),
                            'sticky': False,
                            'type': 'warning',
                        },
                    }
                return notification
        return super(ApprovalRequest, self).action_confirm()

class TksIm8Items(models.Model):
    _name = "tks.im.8.items"
    _description = "IM 8 Items"

    tks_im_8_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_contract_number = fields.Char(string="Contract No.")

    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_8_request_id.tks_currency_id')

    tks_im_8_od_amount = fields.Monetary(
        string="OD Amount", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_od_days = fields.Integer(string="OD Days")
    tks_im_8_collect_overdue_penalty_before = fields.Selection(
        string="Overdue Penalty Before", selection=[("copf","Collect Overdue Penalty in Full")], default="copf"
    )
    tks_im_8_collect_overdue_penalty_after = fields.Selection(
        string="Overdue Penalty After", selection=[("partial","Waive Overdue Penalty (Partial)"),("whole","Waive Overdue Penalty (Whole)")], default="partial"
    )
    tks_im_8_amount_original_before = fields.Monetary(
        string="Amount Original", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_amount_original_after = fields.Monetary(
        string="Amount Waived", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_inv_no_before = fields.Char(string="Invoice No. Before")
    tks_im_8_inv_no_after = fields.Char(string="Invoice No. After")
    tks_im_8_period_date = fields.Date(
        string=_("Period Date"),
    )
    tks_im_8_expected_pay_date = fields.Date(
        string=_("Expected Pay Date"),
    )

class TksIm8OverduePenaltyBefore(models.Model):
    _name = "tks.im.8.overdue.penalty.before"
    _description = "IM 8 Overdue Penalty"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_collect_overdue_penalty_before = fields.Selection(
        string="Overdue Penalty", selection=[("copf","Collect Overdue Penalty in Full")], default="copf"
    )
    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_8_amount_original_before = fields.Monetary(
        string="Amount Original", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_inv_no_before = fields.Char(string="Invoice No.")

class TksIm8OverduePenaltyAfter(models.Model):
    _name = "tks.im.8.overdue.penalty.after"
    _description = "IM 8 Overdue Penalty"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_collect_overdue_penalty_after = fields.Selection(
        string="Overdue Penalty", selection=[("partial","Waive Overdue Penalty (Partial)"),("whole","Waive Overdue Penalty (Whole)")], default="partial"
    )
    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_8_amount_original_after = fields.Monetary(
        string="Amount Waived", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_inv_no_after = fields.Char(string="Invoice No.")

class TksIm8ContractNumber(models.Model):
    _name = "tks.im.8.contract.number"
    _description = "IM 8 Contract Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_contract_number_before = fields.Char(string="Before")
    tks_im_8_contract_number_after = fields.Char(string="After")

class TksIm8OdAmount(models.Model):
    _name = "tks.im.8.od.amount"
    _description = "IM 8 OD Amount"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_8_od_amount_before = fields.Monetary(
        string="Before", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_od_amount_after = fields.Monetary(
        string="After", currency_field="tks_im_8_currency_id"
    )

class TksIm8OdDays(models.Model):
    _name = "tks.im.8.od.days"
    _description = "IM 8 OD Days"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_od_days_before = fields.Integer(string="Before")
    tks_im_8_od_days_after = fields.Integer(string="After")

class TksIm8AmountOriginal(models.Model):
    _name = "tks.im.8.amount.original"
    _description = "IM 8 Amount Original"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_8_amount_original_before = fields.Monetary(
        string="Original", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_amount_original_after = fields.Monetary(
        string="Waived", currency_field="tks_im_8_currency_id"
    )

class TksIm8AmountWaived(models.Model):
    _name = "tks.im.8.amount.waived"
    _description = "IM 8 Amount Waived"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    tks_im_8_currency_id = fields.Many2one("res.currency", string="Currency", related='tks_im_request_id.tks_currency_id')
    tks_im_8_amount_waived_before = fields.Monetary(
        string="Before", currency_field="tks_im_8_currency_id"
    )
    tks_im_8_amount_waived_after = fields.Monetary(
        string="After", currency_field="tks_im_8_currency_id"
    )

class TksIm8InvoiceNo(models.Model):
    _name = "tks.im.8.invoice.number"
    _description = "IM 8 Inovice Number"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_inv_no_before = fields.Char(string="Before")
    tks_im_8_inv_no_after = fields.Char(string="After")

class TksIm8PeriodDate(models.Model):
    _name = "tks.im.8.period.date"
    _description = "IM 8 Period Date"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_period_date_before = fields.Date(string="Start Date")
    tks_im_8_period_date_after = fields.Date(string="End Date")

class TksIm8ExpectedDate(models.Model):
    _name = "tks.im.8.expected.date"
    _description = "IM 8 Expected Date"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )

    tks_im_8_expected_pay_date_before = fields.Date(string="Start Date")
    tks_im_8_expected_pay_date_after = fields.Date(string="End Date")

class TksIm7RiskMitigation(models.Model):
    _name = "tks.im.8.risk.mitigation"
    _description = "IM 8 Risk & Mitigation"

    tks_im_request_id = fields.Many2one(
        "approval.request", string="Approval Request", ondelete="cascade"
    )
    risk_mitigation = fields.Selection(
        string=_("Item"), selection=[("risk", "Risk"), ("mitigation", "Mitigation")]
    )
    remarks = fields.Text(string=_("Remarks"))


class TksIm8OverduePenalty(models.Model):
    _name = "tks.im.8.overdue.penalty"
    _description = "IM 8 Overdue Penalty"


