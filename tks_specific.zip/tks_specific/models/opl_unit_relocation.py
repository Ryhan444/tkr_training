from odoo import api, models, fields, _


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_city_initial_22 = fields.Char('City Initial')
    tks_city_relocation_22 = fields.Char('City Relocation')
    tks_maint_network_initial_22 = fields.Selection([
        ('available', 'Available'),
        ('not_available', 'Not Available'),
    ], default="available", string='TKS Maint. Network Initial')
    tks_maint_network_relocation_22 = fields.Selection([
        ('available', 'Available'),
        ('not_available', 'Not Available'),
    ], default="available", string='TKS Maint. Network Relocation')
    tks_address_initial_22 = fields.Text('Address Initial')
    tks_address_relocation_22 = fields.Text('Address Relocation')
    tks_contact_no_initial_22 = fields.Char('Contact No. Initial')
    tks_contact_no_relocation_22 = fields.Char('Contact No. Relocation')
    tks_contact_pic_initial_22 = fields.Char('Contact PIC Initial')
    tks_contact_pic_relocation_22 = fields.Char('Contact PIC Relocation')
    tks_relocation_type_initial_22 = fields.Selection([
        ('temporary', 'Temporary'),
        ('permanent', 'Permanent'),
    ], default="temporary", string='Relocation Type')
    tks_eff_date_initial_22 = fields.Date('Effective Date Initial')
    tks_cost_covered_by_22 = fields.Selection([
        ('customer', 'Customer'),
        ('takari', 'Takari'),
    ], default="customer", string='Cost Covered by')
    tks_expedition_type_22 = fields.Selection([
        ('one_way', 'One-Way'),
        ('roundtrip', 'Roundtrip'),
    ], default="one_way", string='Expedition Type')
    tks_remaining_term_22 = fields.Integer('Remaining Term')
    tks_delivery_method_22 = fields.Selection([
        ('expedition', 'Expedition'),
        ('self', 'Self Drive'),
    ], default="expedition", string='Delivery Method')
    tks_expedition_cost_22 = fields.Monetary('Expedition Cost', currency_field='tks_currency_id')
    tks_settlement_date_22 = fields.Date('Settlement Date')
    tks_reason_one_way_22 = fields.Text('Reason for one way expedition')
    tks_maintenance_exceed_budget_22 = fields.Selection([
        ('no', 'No'),
        ('yes', 'Yes'),
    ], default="no", string='Exceed Budget (Potential) (Maintenance)')
    tks_replacement_car_exceed_budget_22 = fields.Selection([
        ('no', 'No'),
        ('yes', 'Yes'),
    ], default="no", string='Exceed Budget (Potential) (Replacement Car)')
    tks_explanation_22 = fields.Text('Explanation:')

# class TksIM22RiskMitigation(models.Model):
#     _name = "tks.im.22.risk.mitigation"
#     _description = "IM 22 Risk & Mitigation"

#     tks_im_request_id = fields.Many2one("approval.request", string="Approval Request")
#     tks_im_22_items = fields.Selection(
#         string=_("Items"),
#         selection=[
#             ("risk", "Risk"),
#             ("mitigation", "Mitigation"),
#         ],
#     )

#     tks_im_22_remarks = fields.Text(string=_("Remarks"))
