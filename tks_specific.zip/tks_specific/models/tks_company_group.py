from odoo import fields, models, _, api


class CompanyGroup(models.Model):
    _name = "tks.res.partner.company.group"
    _order = "name"
    _description = "Company Group"

    tks_sequence = fields.Integer(default=1)
    name = fields.Char(string=_("Name"))

    _sql_constraints = [('name_unique', 'unique(name)', 'A name already exists!')]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name"):
                name = vals.get("name")
                if not name.istitle():
                    vals["name"] = name.title()
        return super(CompanyGroup, self).create(vals_list)

    def write(self, vals):
        if vals.get("name"):
            name = vals.get("name")
            if not name.istitle():
                vals["name"] = name.title()
        return super(CompanyGroup, self).write(vals)
