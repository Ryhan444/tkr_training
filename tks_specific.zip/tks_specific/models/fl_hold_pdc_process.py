from odoo import models, fields, _


class TksIMHoldPdcProcess(models.Model):
    _name = "tks.im.hold.pds.process"
    _description = "Hold PDC Process"

    tks_im_7_pdc_clearing_date = fields.Date(
        string=_("PDC Clearing Date"),
    )

    tks_im_7_pdc_number = fields.Char(string=_("PDC No."))
    tks_im_7_pdc_amount = fields.Monetary(
        string="PDC Amount (IDR)", currency_field="tks_currency_id"
    )
