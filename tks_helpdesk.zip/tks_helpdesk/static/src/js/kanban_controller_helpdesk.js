import { Component, useState, onWillStart } from "@odoo/owl";
import { KanbanController } from "@web/views/kanban/kanban_controller";

import { useService } from "@web/core/utils/hooks"; 
import { patch } from "@web/core/utils/patch";
import { registry } from "@web/core/registry";
import { session } from "@web/session";

patch(KanbanController.prototype, {
    setup() {
        super.setup();
        this.actionService = useService("action");
        this.orm = useService("orm");   
        let uid = this.props.context.uid || this.env.user.id;      
        this.user = useState({ 
            data: this.env.user,
        });
        onWillStart(async () => {
            if (uid) {
                await this._loadUserData(uid);
            }
        });        
    },
    async _loadUserData(userId) {
        try {
            const userData = await this.orm.call(
                'res.users', // Model
                'read',      // Metode
                [[userId]],  // args: [ID yang akan dibaca]
                { fields: ['id', 'name', 'is_call_center'] } // kwargs: field yang akan diambil
            );
            if (userData && userData.length > 0) {
                this.user.data = userData[0]; 
                this.user.is_call_center = userData[0].is_call_center; 
                console.log("Data user berhasil dimuat dengan ORM:", this.user.data);
            }
        } catch (error) {
            console.error("Gagal memuat data pengguna dengan ORM:", error);
            this.user.data = this.env.user; 
        }
    },    
    async createRecord() {
        if (!this.user.is_call_center && this.props.resModel == 'helpdesk.ticket') {
            this.env.services.notification.add(
                "Only Is Call Center Can create helpdesk",
                {
                    title: "Access Denied",
                    type: "danger", // Menampilkan notifikasi merah
                }
            );
            return; 
        }            
        return super.createRecord(...arguments);        
    }
});

const cogMenuRegistry = registry.category("cogMenu");
const kanbanCogMenuReg = registry.category("kanban_header_config_items")
const spreadSheetCog = cogMenuRegistry.get("spreadsheet-cog-menu");
const archiveKanban = kanbanCogMenuReg.get("archive_group");
const unarchiveKanban = kanbanCogMenuReg.get("unarchive_group");

spreadSheetCog.isDisplayed = ({ config, isSmall }) => {
    const excludedActions = [
        "All Inquiry",
        "All Ticket",
        "All Tickets",
        "SPK",
        "Repair Orders",
    ];

    if (excludedActions.includes(config.actionName)) {
        return false;
    }

    return (
        !isSmall &&
            config.actionType === "ir.actions.act_window" &&
            config.viewType !== "form" &&
            session.can_insert_in_spreadsheet
    );
};

archiveKanban.isVisible = ({ permissions }) => {
    return false
}

unarchiveKanban.isVisible = ({ permissions }) => {
    return false
}

