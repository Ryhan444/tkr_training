from odoo import fields, models, _, api

class ApprovalRequest(models.Model):
    _inherit = "approval.request"
    
    def action_confirm(self):
        missing_field = any(not line.document_type or not line.detail or not line.reason for line in self.tks_im_31_document_type_ids)
        if self.tks_has_tks_im_waive_master_agreement != 'no' and (not self.tks_im_31_document_type_ids or missing_field):
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Proposal Line Empty'),
                    'message': _('Proposal Line must be filled.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
            return notification
        return super(ApprovalRequest, self).action_confirm()

    tks_im_31_document_type_ids = fields.One2many('opl.waive.agreement.document.type', 'request_id', string='OPL - Document Type')
    tks_im_31_risk_mitigation_waive_aggrement_ids = fields.One2many('opl.waive.agreement.risk.mitigation', 'request_id', string='OPL - Risk & Mitigation')

class OplWaiveAgreementDocumentType(models.Model):
    _name = "opl.waive.agreement.document.type"
    _rec_name = 'document_type'
    _description = "Opl Waive Aggrement Document Type"

    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')  
    document_type =  fields.Selection([('master_agreement', 'Master Agreement'), ('addendum', 'Addendum'), ('ppjb', 'PPJB')], string='Documents Type', default='master_agreement')
    detail = fields.Text(
        string="Detail",
        default="Detail Agreement\n"
                "Sending Date:\n"
                "Aging:\n"
                "Unit Returned Date:\n"
                "Invoice Already Paid:"
    )
    reason = fields.Text(string="Reason")

class OplWaiveAgreementRiskMitigation(models.Model):
    _name = 'opl.waive.agreement.risk.mitigation'
    _rec_name = 'risk_mitigation'
    _description = 'OPL Waive Aggrement Risk Mitigation'
    
    request_id = fields.Many2one('approval.request', string='Approval', ondelete='cascade')
    risk_mitigation = fields.Selection([
        ('risk', 'Risk'),
        ('mitigation', 'Mitigation'),
    ], string='Item')
    remarks = fields.Text('Remarks')


