from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_npwp_status_id = fields.Many2one('tks.npwp.status', string="NPWP Address Status")
    tks_branch_status_id = fields.Many2one('tks.branch.status', string="Branch Address Status")

class Tksnpwp_status(models.Model):
    _name = 'tks.npwp.status'
    _description = 'NPWP Address Status'

    name = fields.Char(string="NPWP Address Status")
    sequence = fields.Integer(string="Sequence")

class Tksbranch_status(models.Model):
    _name = 'tks.branch.status'
    _description = 'Branch Address Status'

    name = fields.Char(string="Branch Address Status")
    sequence = fields.Integer(string="Sequence")