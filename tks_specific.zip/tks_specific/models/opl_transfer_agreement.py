from odoo import _, api, fields, models


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    tks_im_11_business_benefit_ids = fields.One2many(
        "tks.im.11.business.benefit",
        "request_id",
        string="OPL - Business Benefit",
    )
    tks_im_11_compiliance_check_ids = fields.One2many(
        "tks.im.11.compliance.check",
        "request_id",
        string="Compiliance Check",
    )
    tks_im_11_status = fields.Selection(
        [
            ("new", "New"),
            ("exist", "Existing"),
        ],
        default="new",
        string="Status",
    )
    tks_im_11_issue = fields.Selection(
        [
            ("no", "No"),
            ("yes", "Yes"),
        ],
        default="no",
        string="Issue",
    )
    tks_im_11_issue_aml = fields.Selection(
        [
            ("no", "No"),
            ("yes", "Yes"),
        ],
        default="no",
        string="Issue AML",
    )
    tks_im_11_issue_risk_mitigation_aml = fields.Char(string=_("Risk & Mitigation"))
    tks_im_11_issue_dow = fields.Selection(
        [
            ("no", "No"),
            ("yes", "Yes"),
        ],
        default="no",
        string="Issue Dow Jones",
    )
    tks_im_11_issue_risk_mitigation_dow = fields.Char(string=_("Risk & Mitigation"))
    tks_im_11_issue_pefindo = fields.Selection(
        [
            ("no", "No"),
            ("yes", "Yes"),
        ],
        default="no",
        string="Issue Pefindo",
    )
    tks_im_11_issue_pefindo_mitigation = fields.Char(string=_("Risk & Mitigation"))
    tks_im_11_issue_ase = fields.Selection(
        [
            ("no", "No"),
            ("yes", "Yes"),
        ],
        default="no",
        string="Issue ASE",
    )
    tks_im_11_issue_risk_mitigation_ase = fields.Char(string=_("Risk & Mitigation"))
    tks_im_11_transfer = fields.Selection(
        [
            ("1", "1st"),
            ("2", "2nd"),
            ("3", "3rd"),
            ("4", "4th"),
            ("5", "5th"),
        ],
        default="1",
        string="Transfer",
    )
    tks_im_11_transfer_id = fields.Many2one(
        "tks.im.11.transfer",
        string="Transfer",
    )
    tks_im_11_customer_name_before = fields.Char("Customer Name Before")
    tks_im_11_customer_name_after = fields.Char("Customer Name After")
    tks_im_11_customer_rating_before = fields.Char("Customer Rating Before")
    tks_im_11_customer_rating_after = fields.Char("Customer Rating After")
    tks_im_11_customer_group_before = fields.Char("Group Before")
    tks_im_11_customer_group_after = fields.Char("Group After")
    tks_im_11_lease_principal_before = fields.Monetary("Lease Principal Before", currency_field="tks_currency_id")
    tks_im_11_lease_principal_after = fields.Monetary("Lease Principal Before", currency_field="tks_currency_id")
    tks_im_11_lease_term_before = fields.Integer("Lease Term Before")
    tks_im_11_lease_term_after = fields.Integer("Lease Term Before")
    tks_im_11_lease_Period_before_from = fields.Date("Lease Period Before From")
    tks_im_11_lease_Period_before_to = fields.Date("Lease Period Before To")
    tks_im_11_lease_Period_after_from = fields.Date("Lease Period After")
    tks_im_11_lease_Period_after_to = fields.Date("Lease Period After")
    tks_im_11_irr_net_spread_before_1 = fields.Float("IRR/Net Spread")
    tks_im_11_irr_net_spread_before_2 = fields.Float("IRR/Net Spread")
    tks_im_11_irr_net_spread_after_1 = fields.Float("IRR/Net Spread")
    tks_im_11_irr_net_spread_after_2 = fields.Float("IRR/Net Spread")
    tks_im_11_effective_date_after_from = fields.Date("Effective Date")
    tks_im_11_effective_date_after_to = fields.Date("Effective Date")
    tks_im_11_effective_date_before_from = fields.Date("Effective Date")
    tks_im_11_effective_date_before_to = fields.Date("Effective Date")
    tks_replacement_25 = fields.Char("Replacement Unit")
    tks_insurance_25 = fields.Selection(
        [
            ("paid", "Paid"),
            ("unpaid", "Unpaid"),
        ],
        default="paid",
        string="Insurance",
    )
    tks_im_11_contact_no = fields.Char("Contact No.")
    tks_im_11_addendum_no = fields.Char("Addendum No.")
    
    def action_confirm(self):
        missing_fields = any(
            not line.item or
            not line.issue or
            not line.risk_mitigation
            for line in self.tks_im_11_compiliance_check_ids
        )
        if self.tks_has_tks_im_transfer_agreement != 'no' and (
            not self.tks_im_11_compiliance_check_ids or missing_fields
        ):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Compliance Check Empty'),
                    'message': _('Please fill in the required fields in the Compliance Check list.'),
                    'sticky': False,
                    'type': 'warning',
                },
            }
        return super(ApprovalRequest, self).action_confirm()


class TksIm11Transfer(models.Model):
    _name = "tks.im.11.transfer"
    _description = "Transfer"

    name = fields.Char(string="Name")

class TksIm11BusinessBenefit(models.Model):
    _name = "tks.im.11.business.benefit"
    _description = "Business Benefit"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("bc", "Business Consideration"),
            ("calculation", "Calculation (if any)"),
        ],
        string="Item",
    )
    remarks = fields.Text("Remarks")


class TksIm11ComplianceCheck(models.Model):
    _name = "tks.im.11.compliance.check"
    _description = "Compliance Check"

    request_id = fields.Many2one(
        "approval.request", string="Request", ondelete="cascade"
    )
    item = fields.Selection(
        [
            ("aml_cft", "AML-CFT"),
            ("ase", "ASE (Japanese Company)"),
            ("dow", "Dow Jones"),
            ("pfd", "Pefindo"),
        ],
        string="Item",
    )
    issue = fields.Selection(
        string="Issue",
        selection=[
            ("no", "No"),
            ("yes", "Yes"),
        ],
    )
    risk_mitigation = fields.Text("Risk & Mitigation")
