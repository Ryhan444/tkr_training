from odoo import models, fields, api, _

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    tks_trans_bpkb_non_bpkb_id = fields.Many2one('tks.bpkb.non.bpkb', string="BPKB / Non BPKB")

class TksBpkbNonBpkb(models.Model):
    _name = 'tks.bpkb.non.bpkb'
    _description = 'BPKB non BPKB'

    name = fields.Char(string="BPKB / Non BPKB")

